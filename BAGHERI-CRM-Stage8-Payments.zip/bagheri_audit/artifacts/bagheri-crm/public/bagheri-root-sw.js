"use strict";

const CACHE_NAME = "bagheri-root-shell-v1";
const APP_ENTRY = "./";
const APP_FILES = ["./", "./index.html", "./manifest.json"];
const LEGACY_ENTRY = "./legacy/index.html";
const LEGACY_EXTRA_FILES = [
  "./legacy/sw.js",
  "./legacy/logo-export.png",
  "./legacy/fonts/Vazirmatn[wght].woff2",
  "./legacy/icons/apple-touch-icon.png",
  "./legacy/icons/icon-152.png",
  "./legacy/icons/icon-192.png",
  "./legacy/icons/icon-512.png",
];

async function cacheIfAvailable(cache, path) {
  try {
    const response = await fetch(path, { cache: "reload" });
    if (response.ok && response.type !== "opaque") {
      await cache.put(path, response);
    }
  } catch {
    // Individual optional resources must not prevent the app shell from installing.
  }
}

function extractAssetPaths(html, baseUrl) {
  const paths = new Set();
  const attributePattern = /(?:src|href)\s*=\s*["']([^"']+)["']/gi;
  let match;
  while ((match = attributePattern.exec(html))) {
    try {
      const url = new URL(match[1], baseUrl);
      if (url.origin === self.location.origin) {
        paths.add(url.href);
      }
    } catch {
      // Ignore malformed and external references.
    }
  }
  return [...paths];
}

self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await Promise.all(APP_FILES.map((path) => cacheIfAvailable(cache, path)));

    try {
      const response = await fetch("./index.html", { cache: "reload" });
      if (response.ok) {
        const html = await response.clone().text();
        await cache.put("./index.html", response);
        const appAssets = extractAssetPaths(html, new URL("./index.html", self.location.href));
        await Promise.all(appAssets.map((path) => cacheIfAvailable(cache, path)));
      }
    } catch {
      // Keep the install resilient; the page can refresh its cache when online.
    }

    try {
      const response = await fetch(LEGACY_ENTRY, { cache: "reload" });
      if (response.ok) {
        const html = await response.clone().text();
        await cache.put(LEGACY_ENTRY, response);
        const legacyAssets = extractAssetPaths(html, new URL(LEGACY_ENTRY, self.location.href));
        await Promise.all([
          ...legacyAssets.map((path) => cacheIfAvailable(cache, path)),
          ...LEGACY_EXTRA_FILES.map((path) => cacheIfAvailable(cache, path)),
        ]);
      }
    } catch {
      // The shell itself remains usable; the legacy app retries when online.
    }

    await self.skipWaiting();
  })());
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((key) => key.startsWith("bagheri-root-shell-") && key !== CACHE_NAME).map((key) => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET" || new URL(request.url).origin !== self.location.origin) return;

  if (request.mode === "navigate") {
    event.respondWith((async () => {
      try {
        const response = await fetch(request);
        if (response.ok) {
          const cache = await caches.open(CACHE_NAME);
          await cache.put(request, response.clone());
        }
        return response;
      } catch {
        const cached = await caches.match(request);
        return cached || (await caches.match(APP_ENTRY)) || Response.error();
      }
    })());
    return;
  }

  event.respondWith((async () => {
    const cached = await caches.match(request);
    if (cached) return cached;
    try {
      const response = await fetch(request);
      if (response.ok) {
        const cache = await caches.open(CACHE_NAME);
        await cache.put(request, response.clone());
      }
      return response;
    } catch {
      return Response.error();
    }
  })());
});
