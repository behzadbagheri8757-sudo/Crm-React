/* js/intelligence/sku_intelligence.js — Customer × SKU Intelligence V1
   ============================================================
   Deterministic pipeline per Developer Handoff Specification.
   READ-ONLY. No persistent cache (F2). No ML. No invented business rules.

   Public API:
     extractSkuSignals(customerId) -> Signal[]

   Data sources: data.invoices, data.payments, data.products
   Allowed helpers: customerInvoices, customerPayments, customerBehavior,
                    customerTotals, customerProfit, todayISO, daysAgo
   Must NOT call extractCustomerSignals (no circular dependency).
   ============================================================ */
'use strict';

(function (global) {

  /* ---------------------------------------------------------
     Parameter registry (configurable; calibrate with real data).
     F7 values are fixed by contract; all others are calibration knobs.
     --------------------------------------------------------- */
  var SKU_PARAMS = {
    recentWindowSize: 3,
    trendWindow: 3,
    basketWindowSize: 5,
    // BUGFIX (proven by runtime repro): was 2. With exactly 2 purchases
    // there is only ONE interval, so "typicalCycle" (a median) is a
    // single sample with zero measurable variance — it looks perfectly
    // "stable" and can produce a critical-severity SKU_DELAY signal from
    // essentially no pattern at all. Raised to 3 so at least 2 intervals
    // exist before a cycle is treated as "typical" (matches the existing
    // minimumPurchaseCountForFrequency=3 precedent in this same file).
    minimumPurchaseCountForTiming: 3,
    minimumPurchaseCountForQuantity: 2,
    minimumPurchaseCountForFrequency: 3,
    timingSensitivity: 0.5,
    quantityDropSensitivity: 0.3,
    spendDropSensitivity: 0.3,
    basketDropSensitivity: 0.5,
    frequencyDropSensitivity: 0.3,
    trendSensitivity: 0.25,
    minImportanceForSignal: 0.05,
    minBasketPresence: 0.15,
    minSkuCountForAccountSignal: 2,
    groupingWindowDays: 60,
    BASELINE_SHIFT_SENSITIVITY: 0.4,
    SEVERITY_IMPORTANCE_BASE: 0.5,
    SEVERITY_IMPORTANCE_FACTOR: 0.5,
    importanceWeights: { revenue: 0.4, frequency: 0.3, basket: 0.2, profit: 0.1 },
    confidenceWeights: { history: 0.35, stability: 0.25, completeness: 0.15, outliers: 0.1, shift: 0.15 },
    minPurchaseCountForHighConfidence: 6,
    frequencyWindowMultiplier: 1.5,
    minConfidenceForGrouping: 0.5,
    lowHistoryConfidenceFactor: 0.7
  };

  var SEVERITY_POINTS = {
    critical: 100,
    high: 70,
    medium: 40,
    low: 20
  };

  /* ---------------------------------------------------------
     Pure helpers
     --------------------------------------------------------- */
  function _nowISO() {
    return new Date().toISOString();
  }

  function _today() {
    if (typeof todayISO === 'function') return todayISO();
    return new Date().toISOString().slice(0, 10);
  }

  function _daysAgo(iso) {
    if (typeof daysAgo === 'function') {
      var d = daysAgo(iso);
      return (d != null && isFinite(d)) ? d : null;
    }
    if (!iso) return null;
    var t = new Date(String(iso).slice(0, 10)).getTime();
    if (isNaN(t)) return null;
    return Math.floor((Date.now() - t) / 86400000);
  }

  function _dateDiffDays(laterIso, earlierIso) {
    if (!laterIso || !earlierIso) return null;
    var a = new Date(String(laterIso).slice(0, 10)).getTime();
    var b = new Date(String(earlierIso).slice(0, 10)).getTime();
    if (isNaN(a) || isNaN(b)) return null;
    return Math.round((a - b) / 86400000);
  }

  function _median(arr) {
    if (!arr || !arr.length) return null;
    var s = arr.slice().sort(function (x, y) { return x - y; });
    var m = Math.floor(s.length / 2);
    if (s.length % 2) return s[m];
    return (s[m - 1] + s[m]) / 2;
  }

  function _mad(arr, med) {
    if (!arr || !arr.length || med == null || !isFinite(med)) return null;
    var devs = arr.map(function (v) { return Math.abs(v - med); });
    return _median(devs);
  }

  function _mean(arr) {
    if (!arr || !arr.length) return null;
    var s = 0;
    for (var i = 0; i < arr.length; i++) s += arr[i];
    return s / arr.length;
  }

  function _clamp01(x) {
    if (x == null || !isFinite(x)) return 0;
    if (x < 0) return 0;
    if (x > 1) return 1;
    return x;
  }

  function _productName(productId, ctx) {
    if (typeof data === 'undefined' || !Array.isArray(data.products)) return productId || '';
    var p = ctx && typeof ctx.productById === 'function'
      ? ctx.productById(productId)
      : data.products.find(function (x) { return x && x.id === productId; });
    return (p && p.name) ? p.name : (productId || '');
  }

  function _productActive(productId, ctx) {
    if (typeof data === 'undefined' || !Array.isArray(data.products)) return true;
    var p = ctx && typeof ctx.productById === 'function'
      ? ctx.productById(productId)
      : data.products.find(function (x) { return x && x.id === productId; });
    if (!p) return true;
    return p.active !== false;
  }

  function _productStock(productId, ctx) {
    if (typeof data === 'undefined' || !Array.isArray(data.products)) return null;
    var p = ctx && typeof ctx.productById === 'function'
      ? ctx.productById(productId)
      : data.products.find(function (x) { return x && x.id === productId; });
    if (!p) return null;
    return typeof p.stockQty === 'number' ? p.stockQty : null;
  }

  /* ---------------------------------------------------------
     Family-level product state (stock / active).
     The representative SKU (pair.productId) is display/context ONLY; whether a
     Family is active or out of stock is decided over ALL its members:
       members = SKUs seen in this customer's history for the Family
                 + catalog products with analysisGroupId === familyId.
     A product without a group is its own single-member Family, so its
     behaviour is identical to the old per-SKU check.
     No stock is summed; the decision only asks "does any usable member exist".
     --------------------------------------------------------- */
  function _familyMemberIds(familyId, memberIds, productId) {
    var seen = Object.create(null);
    var out = [];
    function add(pid) { if (pid != null && pid !== '' && !seen[pid]) { seen[pid] = true; out.push(pid); } }
    if (memberIds && memberIds.length) { for (var i = 0; i < memberIds.length; i++) add(memberIds[i]); }
    else add(productId);
    if (familyId != null && familyId !== '' && typeof data !== 'undefined' && Array.isArray(data.products)) {
      for (var j = 0; j < data.products.length; j++) {
        var p = data.products[j];
        if (p && p.id && p.analysisGroupId && p.analysisGroupId === familyId) add(p.id);
      }
    }
    return out;
  }

  // Family is active when at least one member is active.
  function _familyActive(familyId, memberIds, productId, ctx) {
    var ids = _familyMemberIds(familyId, memberIds, productId);
    if (!ids.length) return _productActive(productId, ctx);
    for (var i = 0; i < ids.length; i++) {
      if (_productActive(ids[i], ctx)) return true;
    }
    return false;
  }

  // Family is out of stock only when every ACTIVE member has a known stock <= 0.
  // Any active member with positive or unknown (null) stock => not out of stock.
  function _familyStockOut(familyId, memberIds, productId, ctx) {
    var ids = _familyMemberIds(familyId, memberIds, productId);
    var activeCount = 0;
    for (var i = 0; i < ids.length; i++) {
      if (!_productActive(ids[i], ctx)) continue;
      activeCount++;
      var q = _productStock(ids[i], ctx);
      if (q == null || q > 0) return false;
    }
    if (!activeCount) { var q0 = _productStock(productId, ctx); return (q0 != null && q0 <= 0); }
    return true;
  }

  /* ---------------------------------------------------------
     Product Family identity (runtime only — NEVER persisted).
       familyId = product.analysisGroupId || product.id
     analysisGroupId is the single source of truth: same non-null
     analysisGroupId => same Family; null/empty => the product alone.
     No inference from name / weight / SKU / type / category.
     resolveFamilyId is idempotent: passing a familyId (a group id, which
     is never a product id) returns it unchanged, so callers may pass
     either a productId or an already-resolved familyId.
     --------------------------------------------------------- */
  function _findProduct(productId, ctx) {
    if (typeof data === 'undefined' || !Array.isArray(data.products)) return null;
    if (ctx && typeof ctx.productById === 'function') return ctx.productById(productId) || null;
    for (var i = 0; i < data.products.length; i++) {
      var p = data.products[i];
      if (p && p.id === productId) return p;
    }
    return null;
  }

  function resolveFamilyId(productId, ctx) {
    if (productId == null || productId === '' || productId === 'multi') return null;
    var p = _findProduct(productId, ctx);
    return (p && p.analysisGroupId) ? p.analysisGroupId : productId;
  }

  // Per-call memoizing resolver (avoids repeated product lookups in loops).
  function makeFamilyResolver(ctx) {
    var memo = Object.create(null);
    return function (productId) {
      if (productId == null || productId === '' || productId === 'multi') return null;
      var k = String(productId);
      if (memo[k] === undefined) memo[k] = resolveFamilyId(productId, ctx);
      return memo[k];
    };
  }

  // True when productId is a member of the pair's Family (as seen in this
  // customer's own history). Falls back to plain productId equality for
  // pair objects built without a member set.
  function _pairHasProduct(pair, productId) {
    if (!productId) return false;
    if (pair.memberSet) return pair.memberSet[productId] === true;
    return productId === pair.productId;
  }

  /* ---------------------------------------------------------
     Stage 1 — Aggregation (fresh every call — F2)
     Family-level: key = customerId|familyId.
     --------------------------------------------------------- */
  function _aggregatePairMap(customerId, ctx) {
    if (ctx && ctx.aggregatePairMapCache && ctx.aggregatePairMapCache[customerId]) {
      return ctx.aggregatePairMapCache[customerId];
    }
    var map = Object.create(null);
    if (typeof data === 'undefined') return map;

    var famOf = makeFamilyResolver(ctx);

    function ensure(pid) {
      var fid = famOf(pid);
      var key = customerId + '|' + fid;
      if (!map[key]) {
        map[key] = {
          customerId: customerId,
          familyId: fid,
          productId: pid,          // representative SKU (display/context only) — finalized below
          memberProductIds: [],
          memberSet: Object.create(null),
          purchases: [],
          returns: []
        };
      }
      var pr = map[key];
      if (!pr.memberSet[pid]) {
        pr.memberSet[pid] = true;
        pr.memberProductIds.push(pid);
      }
      return pr;
    }

    var invoices = Array.isArray(data.invoices) ? data.invoices : [];
    for (var i = 0; i < invoices.length; i++) {
      var inv = invoices[i];
      if (!inv || inv.customerId !== customerId) continue;
      var items = inv.items || [];
      // Merge duplicate lines within the same invoice at FAMILY level:
      // one purchase event per invoice per Family (no frequency inflation).
      var byFam = Object.create(null);
      for (var j = 0; j < items.length; j++) {
        var it = items[j];
        if (!it || !it.productId) continue; // V1 productId-only
        if (!(it.qty > 0)) continue; // Zero Quantity
        var fidI = famOf(it.productId);
        if (!byFam[fidI]) {
          byFam[fidI] = { qty: 0, revenue: 0, members: Object.create(null) };
        }
        byFam[fidI].qty += it.qty;
        byFam[fidI].revenue += (it.qty * (it.price || 0)) - (it.discount || 0);
        byFam[fidI].members[it.productId] = (byFam[fidI].members[it.productId] || 0) + it.qty;
      }
      var fids = Object.keys(byFam);
      for (var k = 0; k < fids.length; k++) {
        var m = byFam[fids[k]];
        // Dominant member of this invoice (largest qty; id tie-break) is the
        // event's SKU — used only to pick a display representative.
        var memberIds = Object.keys(m.members);
        var domPid = memberIds[0];
        for (var mi = 1; mi < memberIds.length; mi++) {
          var cand = memberIds[mi];
          if (m.members[cand] > m.members[domPid] ||
              (m.members[cand] === m.members[domPid] && String(cand) < String(domPid))) {
            domPid = cand;
          }
        }
        var pair = ensure(domPid);
        for (var mj = 0; mj < memberIds.length; mj++) ensure(memberIds[mj]);
        pair.purchases.push({
          date: inv.date,
          qty: m.qty,
          revenue: m.revenue,
          unitPrice: m.qty > 0 ? (m.revenue / m.qty) : null,
          invoiceId: inv.id,
          productId: domPid,
          members: m.members
        });
      }
    }

    var payments = Array.isArray(data.payments) ? data.payments : [];
    for (var r = 0; r < payments.length; r++) {
      var pay = payments[r];
      if (!pay || pay.customerId !== customerId) continue;
      if (pay.method !== 'return') continue;
      var rItems = pay.returnItems || [];
      for (var ri = 0; ri < rItems.length; ri++) {
        var ret = rItems[ri];
        if (!ret || !ret.productId) continue;
        if (!(ret.qty > 0)) continue;
        var pairR = ensure(ret.productId);
        pairR.returns.push({
          date: pay.date,
          productId: ret.productId,
          qty: ret.qty,
          price: ret.price || 0,
          invoiceId: pay.invoiceId || null
        });
      }
    }

    // Sort purchases by date ascending
    var keys = Object.keys(map);
    for (var x = 0; x < keys.length; x++) {
      map[keys[x]].purchases.sort(function (a, b) {
        return String(a.date || '').localeCompare(String(b.date || ''));
      });
      map[keys[x]].returns.sort(function (a, b) {
        return String(a.date || '').localeCompare(String(b.date || ''));
      });
      // Representative SKU = SKU of the most recent purchase event (display
      // / context only; never used as Family identity).
      var pr2 = map[keys[x]];
      if (pr2.purchases.length) {
        pr2.productId = pr2.purchases[pr2.purchases.length - 1].productId;
      }
    }
    if (ctx && ctx.aggregatePairMapCache) {
      ctx.aggregatePairMapCache[customerId] = map;
    }
    return map;
  }

  /* ---------------------------------------------------------
     Stage 2 — Baseline (F1 zero-interval)
     --------------------------------------------------------- */
  function _computeBaseline(purchases, windowSize) {
    var events = purchases || [];
    if (windowSize != null && windowSize > 0 && events.length > windowSize) {
      events = events.slice(events.length - windowSize);
    }
    var count = events.length;
    var qtys = events.map(function (e) { return e.qty; });
    var revs = events.map(function (e) { return e.revenue; });
    var intervals = [];
    for (var i = 1; i < events.length; i++) {
      var diff = _dateDiffDays(events[i].date, events[i - 1].date);
      if (diff != null && diff > 0) intervals.push(diff); // F1: only > 0
    }
    var typicalCycle = intervals.length ? _median(intervals) : null;
    var typicalQuantity = qtys.length ? _median(qtys) : null;
    var typicalSpend = revs.length ? _median(revs) : null;

    var cycleMad = (typicalCycle != null) ? _mad(intervals, typicalCycle) : null;
    var qtyMad = (typicalQuantity != null) ? _mad(qtys, typicalQuantity) : null;
    var intervalStab = (typicalCycle > 0 && cycleMad != null) ? (1 - _clamp01(cycleMad / typicalCycle)) : 0.5;
    var qtyStab = (typicalQuantity > 0 && qtyMad != null) ? (1 - _clamp01(qtyMad / typicalQuantity)) : 0.5;
    var patternStability = (intervalStab + qtyStab) / 2;

    var firstDate = events.length ? events[0].date : null;
    var lastDate = events.length ? events[events.length - 1].date : null;
    var spanDays = (firstDate && lastDate) ? _dateDiffDays(lastDate, firstDate) : null;
    var typicalFrequency = (spanDays != null && spanDays > 0) ? (count / spanDays) : null;

    return {
      purchaseCount: count,
      intervals: intervals,
      typicalCycle: typicalCycle,
      typicalQuantity: typicalQuantity,
      typicalSpend: typicalSpend,
      patternStability: patternStability,
      typicalFrequency: typicalFrequency,
      firstDate: firstDate,
      lastDate: lastDate
    };
  }

  /* ---------------------------------------------------------
     Stage 3 — Current state (F3 event-based recent window)
     --------------------------------------------------------- */
  function _computeCurrent(pair, historical, recent, customerInvoicesList) {
    var purchases = pair.purchases;
    var last = purchases.length ? purchases[purchases.length - 1] : null;
    var daysSinceLast = last ? _daysAgo(last.date) : null;
    var currentGap = null;
    if (historical.typicalCycle != null && historical.typicalCycle > 0 && daysSinceLast != null) {
      currentGap = daysSinceLast - historical.typicalCycle;
    }

    var recentQty = recent.typicalQuantity;
    var recentSp = recent.typicalSpend;

    var freqWindowDays = null;
    if (historical.typicalCycle != null && historical.typicalCycle > 0) {
      freqWindowDays = historical.typicalCycle * SKU_PARAMS.frequencyWindowMultiplier;
      freqWindowDays = Math.max(30, freqWindowDays);
    } else {
      freqWindowDays = 30;
    }
    var recentFrequency = 0;
    if (freqWindowDays != null) {
      for (var i = 0; i < purchases.length; i++) {
        var d = _daysAgo(purchases[i].date);
        if (d != null && d <= freqWindowDays) recentFrequency++;
      }
    }

    var invs = customerInvoicesList || [];

    // Compute historicalPresenceRate first (needed below to size the
    // basket window adaptively).
    var histPresenceCount = 0;
    for (var h = 0; h < invs.length; h++) {
      var its = invs[h].items || [];
      for (var jj = 0; jj < its.length; jj++) {
        if (its[jj] && _pairHasProduct(pair, its[jj].productId) && its[jj].qty > 0) {
          histPresenceCount++;
          break;
        }
      }
    }
    var historicalPresenceRate = invs.length ? (histPresenceCount / invs.length) : null;

    // BUGFIX (proven by runtime repro): basketWindowSize is a fixed
    // lookback (5 invoices). For any SKU whose natural purchase cadence
    // is longer than that window (e.g. bought roughly every 6+ invoices —
    // a perfectly normal, healthy slow-moving SKU), currentBasketPresence
    // reads 0% almost every time it's checked, purely because the window
    // is shorter than the SKU's own cycle — not because anything changed.
    // Widen the window just enough that, at this SKU's own historical
    // rate, at least one occurrence would normally be expected. Never
    // shrinks the window below the configured basketWindowSize, so normal-
    // cadence SKUs (the common case) are completely unaffected.
    var basketWindow = SKU_PARAMS.basketWindowSize;
    if (historicalPresenceRate != null && historicalPresenceRate > 0) {
      var neededForOneExpected = Math.ceil(1 / historicalPresenceRate);
      if (neededForOneExpected > basketWindow) basketWindow = neededForOneExpected;
    }

    var sortedInvs = invs.slice().sort(function (a, b) {
      return String(b.date || '').localeCompare(String(a.date || ''));
    });
    var windowInvs = sortedInvs.slice(0, basketWindow);
    var presenceCount = 0;
    for (var w = 0; w < windowInvs.length; w++) {
      var items = windowInvs[w].items || [];
      for (var ii = 0; ii < items.length; ii++) {
        if (items[ii] && _pairHasProduct(pair, items[ii].productId) && items[ii].qty > 0) {
          presenceCount++;
          break;
        }
      }
    }
    var currentBasketPresence = windowInvs.length ? (presenceCount / windowInvs.length) : 0;

    return {
      daysSinceLastPurchase: daysSinceLast,
      currentGap: currentGap,
      recentQuantity: recentQty,
      recentSpend: recentSp,
      recentFrequency: recentFrequency,
      currentBasketPresence: currentBasketPresence,
      historicalPresenceRate: historicalPresenceRate,
      lastPurchaseDate: last ? last.date : null
    };
  }

  /* ---------------------------------------------------------
     Stage 6 — Importance (F5 profit weight redistribution)
     --------------------------------------------------------- */
  function _computeImportance(pair, historical, customerId, totalCustomerRevenue, totalCustomerProfit, totalInvoices, ctx) {
    var skuRevenue = 0;
    for (var i = 0; i < pair.purchases.length; i++) skuRevenue += pair.purchases[i].revenue || 0;

    var revenueShare = (totalCustomerRevenue > 0) ? _clamp01(skuRevenue / totalCustomerRevenue) : 0;
    var frequencyShare = (totalInvoices > 0) ? _clamp01(pair.purchases.length / totalInvoices) : 0;
    var basketShare = 0;
    if (totalInvoices > 0) {
      var present = 0;
       var invs = (typeof customerInvoices === 'function') ? customerInvoices(customerId, ctx) : [];
      for (var j = 0; j < invs.length; j++) {
        var items = invs[j].items || [];
        for (var k = 0; k < items.length; k++) {
          if (items[k] && _pairHasProduct(pair, items[k].productId) && items[k].qty > 0) {
            present++;
            break;
          }
        }
      }
      basketShare = _clamp01(present / totalInvoices);
    }

    var profitShare = null;
    var profitAvailable = false;
    if (totalCustomerProfit != null && isFinite(totalCustomerProfit) && totalCustomerProfit > 0) {
      // Approximate SKU profit from purchase events if buyPrice present on products
      // Family-level: cost is computed per member SKU (each member has its
      // own buy price). If ANY member lacks a buy price, profit is treated
      // as unavailable (same F5 fallback as a single SKU without buy price)
      // instead of silently counting that member's cost as zero.
      var skuProfit = 0;
      var anyBuy = false;
      var allBuy = true;
      var memberBuy = Object.create(null);
      function buyOf(pid) {
        if (memberBuy[pid] === undefined) {
          var pr = _findProduct(pid, ctx);
          memberBuy[pid] = pr ? (pr.buy || pr.buyPrice || 0) : 0;
        }
        return memberBuy[pid];
      }
      for (var p = 0; p < pair.purchases.length && allBuy; p++) {
        var ev = pair.purchases[p];
        var evCost = 0;
        var mem = ev.members;
        if (!mem) {
          mem = Object.create(null);
          mem[ev.productId || pair.productId] = ev.qty || 0;
        }
        var mids = Object.keys(mem);
        for (var mq = 0; mq < mids.length; mq++) {
          var b = buyOf(mids[mq]);
          if (!(b > 0)) { allBuy = false; break; }
          evCost += b * (mem[mids[mq]] || 0);
        }
        if (allBuy) skuProfit += (ev.revenue || 0) - evCost;
      }
      anyBuy = allBuy && pair.purchases.length > 0;
      if (anyBuy) {
        profitShare = _clamp01(Math.max(0, skuProfit) / totalCustomerProfit);
        profitAvailable = true;
      }
    }

    var w = SKU_PARAMS.importanceWeights;
    var wr = w.revenue, wf = w.frequency, wb = w.basket, wp = w.profit;
    if (!profitAvailable) {
      // F5: drop profit weight and renormalize remaining
      var remaining = wr + wf + wb;
      if (remaining > 0) {
        wr = wr / remaining;
        wf = wf / remaining;
        wb = wb / remaining;
      }
      wp = 0;
      profitShare = 0;
    }

    var importance = _clamp01(
      wr * revenueShare +
      wf * frequencyShare +
      wb * basketShare +
      wp * (profitShare || 0)
    );
    return importance;
  }

  /* ---------------------------------------------------------
     Stage 4/5/8 — Deviations, trend, confidence
     --------------------------------------------------------- */
  function _baselineShiftPenalty(historical, recent) {
    var penalty = 0;
    var sens = SKU_PARAMS.BASELINE_SHIFT_SENSITIVITY;
    function rel(h, r) {
      if (h == null || !(h > 0) || r == null || !isFinite(r)) return null;
      return Math.abs(r - h) / h;
    }
    var cShift = rel(historical.typicalCycle, recent.typicalCycle);
    var qShift = rel(historical.typicalQuantity, recent.typicalQuantity);
    if (cShift != null && cShift > sens) penalty = Math.max(penalty, _clamp01(cShift));
    if (qShift != null && qShift > sens) penalty = Math.max(penalty, _clamp01(qShift));
    return penalty;
  }

  function _computeConfidence(historical, recent, pair) {
    var cw = SKU_PARAMS.confidenceWeights;
    var historyScore = _clamp01(historical.purchaseCount / SKU_PARAMS.minPurchaseCountForHighConfidence);
    if (historical.purchaseCount < 4) {
      historyScore *= SKU_PARAMS.lowHistoryConfidenceFactor;
    }
    var stabilityScore = _clamp01(historical.patternStability);
    var complete = 0;
    var total = pair.purchases.length || 1;
    var withRev = 0;
    for (var i = 0; i < pair.purchases.length; i++) {
      if (pair.purchases[i].revenue != null) withRev++;
    }
    complete = withRev / total;
    var outlierScore = 1; // simplified: no heavy outlier analysis in V1
    var shiftPen = _baselineShiftPenalty(historical, recent);
    var shiftScore = 1 - shiftPen;

    return _clamp01(
      cw.history * historyScore +
      cw.stability * stabilityScore +
      cw.completeness * complete +
      cw.outliers * outlierScore +
      cw.shift * shiftScore
    );
  }

  function _trendClass(historical, recent) {
    var sens = SKU_PARAMS.trendSensitivity;
    var worsening = false;
    var improving = false;
    if (historical.typicalQuantity > 0 && recent.typicalQuantity != null) {
      var qRatio = recent.typicalQuantity / historical.typicalQuantity;
      if (qRatio < 1 - sens) worsening = true;
      if (qRatio > 1 + sens) improving = true;
    }
    if (historical.typicalCycle > 0 && recent.typicalCycle != null && recent.typicalCycle > 0) {
      var cRatio = recent.typicalCycle / historical.typicalCycle;
      if (cRatio > 1 + sens) worsening = true; // lengthening cycle
      if (cRatio < 1 - sens) improving = true;
    }
    if (worsening && !improving) return 'worsening';
    if (improving && !worsening) return 'improving';
    return 'stable';
  }

  /* ---------------------------------------------------------
     Stage 7 — Context
     --------------------------------------------------------- */
  function _netRecentQty(pair, recentWindowSize) {
    var purchases = pair.purchases;
    var startIdx = Math.max(0, purchases.length - recentWindowSize);
    var windowPurchases = purchases.slice(startIdx);
    var gross = 0;
    var earliest = null;
    for (var i = 0; i < windowPurchases.length; i++) {
      gross += windowPurchases[i].qty || 0;
      if (!earliest || String(windowPurchases[i].date) < String(earliest)) {
        earliest = windowPurchases[i].date;
      }
    }
    var returned = 0;
    if (earliest) {
      for (var r = 0; r < pair.returns.length; r++) {
        var ret = pair.returns[r];
        if (String(ret.date || '') >= String(earliest)) returned += ret.qty || 0;
      }
    }
    return Math.max(0, gross - returned);
  }

  // BUGFIX (Audit #12): mirrors _netRecentQty's own recent-window/earliest
  // computation, but exposes whether any return actually falls inside that
  // window. Kept separate from _netRecentQty (rather than changing its
  // return shape) so its one existing call site is untouched.
  function _hasReturnsInWindow(pair, recentWindowSize) {
    var purchases = pair.purchases;
    var startIdx = Math.max(0, purchases.length - recentWindowSize);
    var windowPurchases = purchases.slice(startIdx);
    var earliest = null;
    for (var i = 0; i < windowPurchases.length; i++) {
      if (!earliest || String(windowPurchases[i].date) < String(earliest)) {
        earliest = windowPurchases[i].date;
      }
    }
    if (!earliest || !pair.returns) return false;
    for (var r = 0; r < pair.returns.length; r++) {
      var ret = pair.returns[r];
      if (String(ret.date || '') >= String(earliest)) return true;
    }
    return false;
  }

  // familyId -> { productId: true } for products bought (qty>0) in the late
  // half of the customer's invoice history. Same split calc.js uses for
  // decliningProducts (date, then invoice number; mid = floor(count/2)).
  function _lateFamilyMembers(customerId, ctx, famOf) {
    var out = Object.create(null);
    if (typeof customerInvoices !== 'function') return out;
    var invs = customerInvoices(customerId, ctx).slice().sort(function (a, b) {
      return String(a.date || '').localeCompare(String(b.date || ''))
        || String(a.number || '').localeCompare(String(b.number || ''));
    });
    var late = invs.slice(Math.floor(invs.length / 2));
    for (var i = 0; i < late.length; i++) {
      var items = late[i].items || [];
      for (var j = 0; j < items.length; j++) {
        var it = items[j];
        if (!it || !it.productId || !(it.qty > 0)) continue;
        var fid = famOf(it.productId);
        if (!out[fid]) out[fid] = Object.create(null);
        out[fid][it.productId] = true;
      }
    }
    return out;
  }

  function _accountWideDecline(customerId, ctx) {
    if (typeof customerBehavior !== 'function') return false;
    try {
      var b = customerBehavior(customerId, ctx);
      if (!b) return false;
      if (b.amountTrend === 'down') return true;
      var declining = Array.isArray(b.decliningProducts) ? b.decliningProducts : [];
      // calc.js decliningProducts is SKU-level (untouched). Normalize to
      // Family-level here, in the Intelligence layer only: (a) a declining
      // SKU whose Family is retained by another member bought in the late
      // half is a same-family switch, not a decline; (b) several declining
      // SKUs of one Family count once.
      var famOf = makeFamilyResolver(ctx);
      var lateFamilies = _lateFamilyMembers(customerId, ctx, famOf);
      var seenFam = Object.create(null);
      var famCount = 0;
      for (var di = 0; di < declining.length; di++) {
        var dp = declining[di];
        if (!dp || !dp.productId) continue;
        var dfid = famOf(dp.productId);
        var lateMembers = lateFamilies[dfid];
        if (lateMembers) {
          var retained = false;
          for (var lm in lateMembers) {
            if (lm !== dp.productId) { retained = true; break; }
          }
          if (retained) continue;
        }
        if (seenFam[dfid]) continue;
        seenFam[dfid] = true;
        famCount++;
      }
      if (famCount >= SKU_PARAMS.minSkuCountForAccountSignal) return true;
      return false;
    } catch (e) {
      return false;
    }
  }

  /* ---------------------------------------------------------
     Severity + points (F7)
     --------------------------------------------------------- */
  function _severityFromDeviation(strength, importance) {
    // strength roughly [0,1+]; map to severity bands (deterministic, no extra business invention)
    if (strength >= 1.0) return 'critical';
    if (strength >= 0.6) return 'high';
    if (strength >= 0.3) return 'medium';
    return 'low';
  }

  function _severityPoints(severity, importance) {
    var base = SEVERITY_POINTS[severity] || 0;
    var b = SKU_PARAMS.SEVERITY_IMPORTANCE_BASE;
    var f = SKU_PARAMS.SEVERITY_IMPORTANCE_FACTOR;
    var imp = (importance != null && isFinite(importance)) ? _clamp01(importance) : 0;
    return base * (b + f * imp);
  }

  function _mkSkuSignal(opts) {
    var severity = opts.severity || 'medium';
    var importance = opts.importance != null ? opts.importance : 0;
    var conf = opts.confidence != null ? opts.confidence : 0.5;
    return {
      id: 'sig_' + opts.customerId + '_sku_' + (opts.familyId != null ? opts.familyId : opts.productId) + '_' + opts.category,
      customerId: opts.customerId,
      productId: opts.productId,
      familyId: opts.familyId != null ? opts.familyId : null, // runtime only — never persisted
      productName: opts.productName || _productName(opts.productId),
      type: opts.type || 'risk',
      category: opts.category,
      severity: severity,
      importance: importance,
      confidence: conf,
      severityPoints: _severityPoints(severity, importance),
      value: opts.value,
      unit: opts.unit,
      reason: opts.reason,
      detectedAt: _nowISO(),
      actionable: opts.actionable !== false,
      actionHint: opts.actionHint || null,
      contextFlags: opts.contextFlags || {},
      evidence: opts.evidence || {},
      source: 'sku_intelligence'
    };
  }

  /* ---------------------------------------------------------
     Stage 9–11 — Eligibility, combination, signal build
     --------------------------------------------------------- */
  function _analyzePair(pair, customerId, custInvs, totalRev, totalProfit, accountDecline, ctx) {
    var historical = _computeBaseline(pair.purchases, null);
    if (historical.purchaseCount < 1) return null;

    // P-05: maintained baseline via baseline_manager (persistent shift detection).
    // Signal-generation semantics otherwise unchanged — only the source of
    // typicalCycle / typicalQuantity for the established baseline is managed.
    if (typeof updateBaselineIfShifted === 'function') {
      try {
        updateBaselineIfShifted(customerId, pair.familyId, pair.purchases, pair.productId);
      } catch (eBaseUp) { /* fail-open */ }
    }
    if (typeof getBaseline === 'function') {
      try {
        var managed = getBaseline(customerId, pair.familyId);
        if (managed) {
          if (managed.typicalCycle != null && isFinite(managed.typicalCycle) && managed.typicalCycle > 0) {
            historical.typicalCycle = managed.typicalCycle;
          }
          if (managed.typicalQuantity != null && isFinite(managed.typicalQuantity) && managed.typicalQuantity > 0) {
            historical.typicalQuantity = managed.typicalQuantity;
          }
        }
      } catch (eBaseGet) { /* fail-open */ }
    }

    var recent = _computeBaseline(pair.purchases, SKU_PARAMS.recentWindowSize);
    var current = _computeCurrent(pair, historical, recent, custInvs);
    var importance = _computeImportance(pair, historical, customerId, totalRev, totalProfit, custInvs.length, ctx);
    var confidence = _computeConfidence(historical, recent, pair);
    var trend = _trendClass(historical, recent);
    var stockOut = _familyStockOut(pair.familyId, pair.memberProductIds, pair.productId, ctx);
    var productName = _productName(pair.productId, ctx);

    if (!_familyActive(pair.familyId, pair.memberProductIds, pair.productId, ctx)) return null;

    var candidates = [];

    // Timing deviation
    if (
      historical.purchaseCount >= SKU_PARAMS.minimumPurchaseCountForTiming &&
      historical.typicalCycle != null &&
      historical.typicalCycle > 0 &&
      current.currentGap != null &&
      current.currentGap > 0
    ) {
      var timingThresh = historical.typicalCycle * SKU_PARAMS.timingSensitivity;
      if (current.currentGap > timingThresh) {
        var timingStrength = current.currentGap / historical.typicalCycle;
        candidates.push({
          dim: 'timing',
          category: 'SKU_DELAY',
          strength: timingStrength,
          value: current.daysSinceLastPurchase,
          unit: 'days',
          reason: 'مشتری معمولاً «' + productName + '» را هر ' + Math.round(historical.typicalCycle) +
            ' روز می‌خرد؛ آخرین خرید ' + Math.round(current.daysSinceLastPurchase) + ' روز پیش بوده است',
          actionHint: 'Visit',
          evidence: {
            daysSinceLast: current.daysSinceLastPurchase,
            typicalCycle: historical.typicalCycle,
            currentGap: current.currentGap
          }
        });
      }
    }

    // Quantity deviation (F3: use actual recent events, not forced zero)
    if (
      historical.purchaseCount >= SKU_PARAMS.minimumPurchaseCountForQuantity &&
      historical.typicalQuantity != null &&
      historical.typicalQuantity > 0 &&
      recent.typicalQuantity != null
    ) {
      var netQty = _netRecentQty(pair, SKU_PARAMS.recentWindowSize);
      // BUGFIX (proven by runtime repro, prior session): netQty is a SUM
      // across up to recentWindowSize purchase events, while
      // historical.typicalQuantity is a MEDIAN SINGLE-EVENT quantity.
      // Comparing them directly (sum vs. per-event baseline) was a
      // unit/scale mismatch: qtyRatio came out >= 0.7 almost every time
      // more than one recent purchase existed, regardless of returns, so
      // returnsExplain was wrongly true and masked real quantity
      // declines. Normalize netQty to the same per-purchase-event scale
      // before comparing.
      var netQtyWindowCount = Math.min(SKU_PARAMS.recentWindowSize, pair.purchases.length);
      var netQtyPerEvent = netQtyWindowCount > 0 ? (netQty / netQtyWindowCount) : netQty;
      var compareQty = netQtyPerEvent; // prefer net (per-event) for returns context
      // If net is near baseline but gross recent is low → returns explain it
      var qtyRatio = compareQty / historical.typicalQuantity;
      // Also consider median recent event qty
      var eventRatio = recent.typicalQuantity / historical.typicalQuantity;
      // For drop detection use the lower of the two (more drop) only if returns don't neutralize.
      // BUGFIX (proven by runtime repro): "returnsExplain" never actually
      // checked whether any return exists for this SKU — it only compared
      // ratios. That meant a single large outlier order in the recent
      // window could itself push qtyRatio back above threshold and mask a
      // genuine, sustained per-order quantity decline (e.g. baseline 20,
      // recent orders 100/12/12 — a real drop to ~12 — with zero returns
      // involved at all). Require an actual recorded return before
      // "returns explain it" is allowed to suppress the signal.
      // BUGFIX (Audit #12): this previously checked pair.returns.length > 0
      // across the SKU's ENTIRE history with no date boundary — despite the
      // "InPeriod" name — so a single unrelated return from long ago (even
      // years prior) could permanently suppress genuine future quantity-
      // decline detection for that customer/SKU. Scope it to the same
      // recent window _netRecentQty already uses just above.
      var hasReturnsInPeriod = _hasReturnsInWindow(pair, SKU_PARAMS.recentWindowSize);
      var returnsExplain = hasReturnsInPeriod &&
        (eventRatio < 1 - SKU_PARAMS.quantityDropSensitivity) &&
        (qtyRatio >= 1 - SKU_PARAMS.quantityDropSensitivity);
      if (!returnsExplain && eventRatio < 1 - SKU_PARAMS.quantityDropSensitivity) {
        var qtyStrength = 1 - eventRatio;
        candidates.push({
          dim: 'quantity',
          category: 'SKU_QUANTITY_DROP',
          strength: qtyStrength,
          value: Math.round((1 - eventRatio) * 1000) / 10,
          unit: '%',
          reason: 'مقدار خرید «' + productName + '» از حدود ' +
            (Math.round(historical.typicalQuantity * 100) / 100) + ' به حدود ' +
            (Math.round(recent.typicalQuantity * 100) / 100) + ' کاهش یافته است',
          actionHint: 'Investigate',
          evidence: {
            typicalQuantity: historical.typicalQuantity,
            recentQuantity: recent.typicalQuantity,
            netRecentQty: netQty
          }
        });
      }
    }

    // Spend deviation
    if (
      historical.purchaseCount >= SKU_PARAMS.minimumPurchaseCountForQuantity &&
      historical.typicalSpend != null &&
      historical.typicalSpend > 0 &&
      recent.typicalSpend != null
    ) {
      var spendRatio = recent.typicalSpend / historical.typicalSpend;
      if (spendRatio < 1 - SKU_PARAMS.spendDropSensitivity) {
        // Only emit separate spend if quantity drop not already covering similar magnitude
        var hasQty = candidates.some(function (c) { return c.dim === 'quantity'; });
        if (!hasQty) {
          candidates.push({
            dim: 'spend',
            category: 'SKU_QUANTITY_DROP', // fold into quantity category per handoff
            strength: 1 - spendRatio,
            value: Math.round((1 - spendRatio) * 1000) / 10,
            unit: '%',
            reason: 'مبلغ خرید «' + productName + '» نسبت به الگوی معمول کاهش یافته است',
            actionHint: 'Investigate',
            evidence: {
              typicalSpend: historical.typicalSpend,
              recentSpend: recent.typicalSpend
            }
          });
        }
      }
    }

    // Basket / line drop
    if (
      historical.purchaseCount >= SKU_PARAMS.minimumPurchaseCountForQuantity &&
      current.historicalPresenceRate != null &&
      current.historicalPresenceRate >= SKU_PARAMS.minBasketPresence &&
      current.currentBasketPresence <= (1 - SKU_PARAMS.basketDropSensitivity) * current.historicalPresenceRate
    ) {
      candidates.push({
        dim: 'basket',
        category: 'LINE_DROP',
        strength: current.historicalPresenceRate - current.currentBasketPresence,
        value: Math.round(current.currentBasketPresence * 100),
        unit: '%',
        reason: '«' + productName + '» دیگر در سبد خریدهای اخیر مشتری دیده نمی‌شود',
        actionHint: 'Visit',
        evidence: {
          historicalPresenceRate: current.historicalPresenceRate,
          currentBasketPresence: current.currentBasketPresence
        }
      });
    }

    // Frequency deviation
    if (
      historical.purchaseCount >= SKU_PARAMS.minimumPurchaseCountForFrequency &&
      historical.typicalFrequency != null &&
      historical.typicalFrequency > 0 &&
      historical.typicalCycle != null &&
      historical.typicalCycle > 0
    ) {
      var expectedInWindow = historical.typicalFrequency *
        (historical.typicalCycle * SKU_PARAMS.frequencyWindowMultiplier);
      if (expectedInWindow > 0) {
        var freqRatio = current.recentFrequency / expectedInWindow;
        if (freqRatio < 1 - SKU_PARAMS.frequencyDropSensitivity) {
          candidates.push({
            dim: 'frequency',
            category: 'SKU_FREQUENCY_DROP',
            strength: 1 - freqRatio,
            value: current.recentFrequency,
            unit: 'count',
            reason: 'تعداد خرید «' + productName + '» در بازه اخیر کمتر از الگوی معمول است',
            actionHint: 'Call Today',
            evidence: {
              recentFrequency: current.recentFrequency,
              expectedFrequency: expectedInWindow
            }
          });
        }
      }
    }

    // Stock suppression (context)
    if (stockOut) {
      candidates = candidates.filter(function (c) {
        return c.dim !== 'timing' && c.dim !== 'quantity' && c.dim !== 'spend';
      });
    }

    // Importance gate
    if (importance < SKU_PARAMS.minImportanceForSignal) {
      return null;
    }

    if (!candidates.length) return null;

    // Combine multiple dimensions on same SKU
    var category;
    var dims = candidates.map(function (c) { return c.dim; });
    var uniqueDims = dims.filter(function (d, i) { return dims.indexOf(d) === i; });
    if (uniqueDims.length >= 2) {
      category = 'COMBINED_SKU_DETERIORATION';
    } else {
      category = candidates[0].category;
    }

    var maxStrength = 0;
    var reasons = [];
    var evidence = {};
    var actionHint = candidates[0].actionHint;
    var value = candidates[0].value;
    var unit = candidates[0].unit;
    for (var c = 0; c < candidates.length; c++) {
      if (candidates[c].strength > maxStrength) maxStrength = candidates[c].strength;
      reasons.push(candidates[c].reason);
      for (var ek in candidates[c].evidence) {
        if (Object.prototype.hasOwnProperty.call(candidates[c].evidence, ek)) {
          evidence[ek] = candidates[c].evidence[ek];
        }
      }
    }
    if (category === 'COMBINED_SKU_DETERIORATION') {
      actionHint = 'Manager Review';
    }

    var severity = _severityFromDeviation(maxStrength, importance);
    if (trend === 'worsening' && severity === 'low') severity = 'medium';
    if (trend === 'worsening' && severity === 'medium') severity = 'high';

    return {
      signal: _mkSkuSignal({
        customerId: customerId,
        productId: pair.productId,
        familyId: pair.familyId,
        productName: productName,
        category: category,
        severity: severity,
        importance: importance,
        confidence: confidence,
        value: value,
        unit: unit,
        reason: reasons.join('؛ '),
        actionHint: actionHint,
        contextFlags: {
          stock: stockOut,
          accountDecline: !!accountDecline,
          returns: pair.returns.length > 0
        },
        evidence: (function () {
          evidence.memberProductIds = pair.memberProductIds ? pair.memberProductIds.slice() : [pair.productId];
          return evidence;
        })()
      }),
      productId: pair.productId,
      familyId: pair.familyId,
      dims: uniqueDims,
      strength: maxStrength
    };
  }

  /* ---------------------------------------------------------
     Public entry: extractSkuSignals (F2 freshness)
     --------------------------------------------------------- */
  function extractSkuSignals(customerId, ctx, skipMemo) {
    if (ctx && typeof ctx.memo === 'function' && !skipMemo) {
      return ctx.memo('skuSignals', customerId, function () {
        return extractSkuSignals(customerId, ctx, true);
      });
    }
    var out = [];
    if (!customerId) return out;
    if (typeof data === 'undefined') return out;

    // F2: rebuild aggregation from current data every call, unless a caller
    // in the same execution cycle already computed it (see ctx.aggregatePairMapCache).
    var map = _aggregatePairMap(customerId, ctx);
    var keys = Object.keys(map);
    if (!keys.length) return out;

    var custInvs = (typeof customerInvoices === 'function') ? customerInvoices(customerId, ctx) : [];
    var totalRev = 0;
    try {
      if (typeof customerTotals === 'function') {
        var t = customerTotals(customerId, ctx);
        if (t && typeof t.invTotal === 'number') totalRev = t.invTotal;
      }
    } catch (e) {}
    var totalProfit = null;
    try {
      if (typeof customerProfit === 'function') {
        totalProfit = customerProfit(customerId, ctx);
      }
    } catch (e2) {}

    var accountDecline = _accountWideDecline(customerId, ctx);
    var pairResults = [];

    for (var i = 0; i < keys.length; i++) {
      var pair = map[keys[i]];
      if (!pair.purchases.length) continue;
      var result = _analyzePair(pair, customerId, custInvs, totalRev, totalProfit, accountDecline, ctx);
      if (result && result.signal) pairResults.push(result);
    }

    // Multi-SKU Decline grouping
    if (
      accountDecline &&
      pairResults.length >= SKU_PARAMS.minSkuCountForAccountSignal
    ) {
      var qtyLike = pairResults.filter(function (r) {
        if (!(r.signal && r.signal.confidence >= SKU_PARAMS.minConfidenceForGrouping)) return false;
        return r.dims.indexOf('quantity') >= 0 ||
          r.dims.indexOf('frequency') >= 0 ||
          r.dims.indexOf('basket') >= 0 ||
          r.signal.category === 'COMBINED_SKU_DETERIORATION' ||
          r.signal.category === 'SKU_QUANTITY_DROP' ||
          r.signal.category === 'LINE_DROP' ||
          r.signal.category === 'SKU_FREQUENCY_DROP';
      });
      if (qtyLike.length >= SKU_PARAMS.minSkuCountForAccountSignal) {
        var names = qtyLike.map(function (r) { return r.signal.productName || r.productId; });
        var avgImp = 0;
        var avgConf = 0;
        var maxStr = 0;
        for (var q = 0; q < qtyLike.length; q++) {
          avgImp += qtyLike[q].signal.importance || 0;
          avgConf += qtyLike[q].signal.confidence || 0;
          if (qtyLike[q].strength > maxStr) maxStr = qtyLike[q].strength;
        }
        avgImp /= qtyLike.length;
        avgConf /= qtyLike.length;
        var multiSeverity = _severityFromDeviation(maxStr, avgImp);
        if (multiSeverity === 'low' || multiSeverity === 'medium') multiSeverity = 'high';

        var multi = _mkSkuSignal({
          customerId: customerId,
          productId: 'multi',
          productName: names.join('، '),
          category: 'MULTI_SKU_DECLINE',
          severity: multiSeverity,
          importance: avgImp,
          confidence: avgConf,
          value: qtyLike.length,
          unit: 'count',
          reason: 'کاهش خرید در چند محصول (' + names.join('، ') + ') همراه با افت کلی حساب',
          actionHint: 'Manager Review',
          contextFlags: { accountDecline: true },
          evidence: {
            // representative SKUs (legacy shape) + every member SKU of each
            // affected Family, so SKU-level account signals of any member
            // are recognised as already covered.
            affectedProductIds: (function () {
              var ids = [];
              var seenIds = Object.create(null);
              qtyLike.forEach(function (r) {
                var mem = (r.signal.evidence && r.signal.evidence.memberProductIds) || [r.productId];
                [r.productId].concat(mem).forEach(function (id) {
                  if (id != null && !seenIds[id]) { seenIds[id] = true; ids.push(id); }
                });
              });
              return ids;
            })(),
            affectedFamilyIds: qtyLike.map(function (r) { return r.familyId; })
          }
        });
        // Suppress individuals that were grouped (Family identity)
        var groupedIds = Object.create(null);
        for (var g = 0; g < qtyLike.length; g++) groupedIds[qtyLike[g].familyId] = true;
        pairResults = pairResults.filter(function (r) { return !groupedIds[r.familyId]; });
        out.push(multi);
      }
    }

    for (var o = 0; o < pairResults.length; o++) {
      out.push(pairResults[o].signal);
    }
    return out;
  }

  global.extractSkuSignals = extractSkuSignals;
  global.SKU_PARAMS = SKU_PARAMS;
  // Runtime Family identity helpers (shared by all Intelligence modules;
  // resolved at call time, so script load order does not matter).
  global.resolveFamilyId = resolveFamilyId;
  global.makeFamilyResolver = makeFamilyResolver;
  // Family-level stock decision, reused by action.js (stock context text).
  global.familyStockOut = function (familyId, memberIds, productId, ctx) {
    return _familyStockOut(familyId, memberIds, productId, ctx);
  };

  /* ============================================================
     WATCH / EARLY WARNING LAYER — SKU side (frozen spec §7-9).
     Read-only. Does NOT call extractCustomerSignals/extractSkuSignals,
     persistence, risk, or action. Does NOT call updateBaselineIfShifted/
     getBaseline (baseline_manager.js): those are Confirmed-pipeline-owned
     (P-05) and would additionally write to localStorage/IndexedDB as a
     side effect of merely computing metrics — reusing them here would
     make Watch dependent on Confirmed state and no longer strictly
     read-only, so raw historical.typicalCycle/typicalQuantity from
     _computeBaseline are used directly instead. This is a deliberate,
     reported deviation from "همان baseline منطقی که _analyzePair استفاده
     می‌کند" in the strict sense of reusing the *managed* baseline; the
     same aggregation/median baseline *algorithm* is reused exactly.
     ============================================================ */

  /* Public contract (spec §7): exact fields only, plus purchaseCount —
     added because the Watch rules in this same file need it to apply
     each rule's minimum-purchase-count gate (spec §8), and the contract
     does not forbid additional fields. Reported explicitly, not guessed
     silently. */
  function _extractSkuRawMetrics(customerId, ctx, skipMemo) {
    if (ctx && typeof ctx.memo === 'function' && !skipMemo) {
      return ctx.memo('skuRawMetrics', customerId, function () {
        return _extractSkuRawMetrics(customerId, ctx, true);
      });
    }
    var out = [];
    if (!customerId || typeof data === 'undefined') return out;
    var map = _aggregatePairMap(customerId, ctx);
    var keys = Object.keys(map);
    if (!keys.length) return out;
    var custInvs = (typeof customerInvoices === 'function') ? customerInvoices(customerId, ctx) : [];

    for (var i = 0; i < keys.length; i++) {
      var pair = map[keys[i]];
      if (!pair.purchases.length) continue;

      // W-BUG-01 fix: apply the same product eligibility gate used by
      // Confirmed SKU Intelligence (_analyzePair, line ~619). A product the
      // business no longer carries must not generate a Watch — the
      // underlying "delay"/"drop" would never be able to resolve.
      if (!_familyActive(pair.familyId, pair.memberProductIds, pair.productId, ctx)) continue;

      var historical = _computeBaseline(pair.purchases, null);
      if (historical.purchaseCount < 1) continue;
      var recent = _computeBaseline(pair.purchases, SKU_PARAMS.recentWindowSize);
      var current = _computeCurrent(pair, historical, recent, custInvs);
      // Same stock-context semantics as Confirmed: only used to suppress
      // timing/quantity-style dims below, never a full exclusion (unlike
      // the active gate above).
      var stockOut = _familyStockOut(pair.familyId, pair.memberProductIds, pair.productId, ctx);

      var eventRatio = null;
      if (historical.typicalQuantity != null && historical.typicalQuantity > 0 && recent.typicalQuantity != null) {
        eventRatio = recent.typicalQuantity / historical.typicalQuantity;
      }

      var freqRatio = null;
      if (
        historical.typicalFrequency != null && historical.typicalFrequency > 0 &&
        historical.typicalCycle != null && historical.typicalCycle > 0
      ) {
        var expectedInWindow = historical.typicalFrequency * (historical.typicalCycle * SKU_PARAMS.frequencyWindowMultiplier);
        if (expectedInWindow > 0) freqRatio = current.recentFrequency / expectedInWindow;
      }

      var presenceDrop = null;
      if (current.historicalPresenceRate != null) {
        presenceDrop = current.historicalPresenceRate - current.currentBasketPresence;
      }

      out.push({
        productId: pair.productId,
        familyId: pair.familyId,
        memberProductIds: pair.memberProductIds ? pair.memberProductIds.slice() : [pair.productId],
        productName: _productName(pair.productId, ctx),
        typicalCycle: historical.typicalCycle,
        currentGap: current.currentGap,
        typicalQuantity: historical.typicalQuantity,
        recentQuantity: recent.typicalQuantity,
        recentFrequency: current.recentFrequency,
        expectedFrequency: (historical.typicalFrequency != null && historical.typicalCycle != null)
          ? historical.typicalFrequency * (historical.typicalCycle * SKU_PARAMS.frequencyWindowMultiplier) : null,
        eventRatio: eventRatio,
        freqRatio: freqRatio,
        presenceDrop: presenceDrop,
        historicalPresenceRate: current.historicalPresenceRate,
        currentBasketPresence: current.currentBasketPresence,
        purchaseCount: historical.purchaseCount,
        // Last purchase of the whole Family (pair.purchases is date-ascending: sorted at the end of
        // _aggregatePairMap; same value _computeCurrent uses for currentGap). Same set as typicalCycle/purchaseCount.
        lastPurchaseDate: current.lastPurchaseDate,
        stockOut: stockOut
      });
    }
    return out;
  }

  var WATCH_LEVEL_RANK = { low: 1, medium: 2, high: 3 };
  function _watchLevelMax(a, b) {
    return (WATCH_LEVEL_RANK[b] || 0) > (WATCH_LEVEL_RANK[a] || 0) ? b : a;
  }

  /* SKU Watch rules (spec §8) + Combined SKU Watch collapsing (spec §9). */
  function extractSkuWatchObservations(customerId, ctx, skipMemo) {
    if (ctx && typeof ctx.memo === 'function' && !skipMemo) {
      return ctx.memo('skuWatchObservations', customerId, function () {
        return extractSkuWatchObservations(customerId, ctx, true);
      });
    }
    var out = [];
    if (!customerId) return out;
    var raw;
    try { raw = _extractSkuRawMetrics(customerId, ctx) || []; } catch (eRaw) { raw = []; }
    if (!raw.length) return out;

    for (var i = 0; i < raw.length; i++) {
      var m = raw[i];
      var components = [];

      // A) SKU_DELAY_WATCH
      // Stock-context suppression mirrors Confirmed (_analyzePair): if we
      // are out of stock ourselves, a purchase delay is explained by our
      // own stock-out, not customer churn, so timing/quantity dims are
      // skipped (frequency/basket dims are left ungated, same as Confirmed).
      if (
        !m.stockOut &&
        m.purchaseCount >= SKU_PARAMS.minimumPurchaseCountForTiming &&
        m.typicalCycle != null && m.typicalCycle > 0 &&
        m.currentGap != null && m.currentGap > 0
      ) {
        var delayRatio = m.currentGap / m.typicalCycle;
        if (delayRatio >= 0.20) {
          components.push({
            category: 'SKU_DELAY_WATCH',
            level: delayRatio >= 0.40 ? 'high' : (delayRatio >= 0.30 ? 'medium' : 'low'),
            deviationStrength: Math.min(1, m.currentGap / (0.5 * m.typicalCycle)),
            reason: 'تأخیر زودهنگام در خرید «' + m.productName + '» نسبت به الگوی معمول مشاهده می‌شود',
            evidence: { currentGap: m.currentGap, typicalCycle: m.typicalCycle, purchaseCount: m.purchaseCount, comparison: 'فاصله فعلی از خرید در برابر چرخه معمول خرید' }
          });
        }
      }

      // B) SKU_QUANTITY_DROP_WATCH
      if (!m.stockOut && m.purchaseCount >= SKU_PARAMS.minimumPurchaseCountForQuantity && m.eventRatio != null && m.eventRatio < 0.85) {
        components.push({
          category: 'SKU_QUANTITY_DROP_WATCH',
          level: m.eventRatio < 0.75 ? 'medium' : 'low',
          deviationStrength: Math.min(1, (1 - m.eventRatio) / 0.3),
          reason: 'کاهش زودهنگام در مقدار خرید «' + m.productName + '» مشاهده می‌شود',
          evidence: { recentQuantity: m.recentQuantity, typicalQuantity: m.typicalQuantity, ratio: m.eventRatio, purchaseCount: m.purchaseCount, comparison: 'مقدار خرید اخیر در برابر مقدار معمول خرید' }
        });
      }

      // C) SKU_FREQUENCY_DROP_WATCH
      if (m.purchaseCount >= SKU_PARAMS.minimumPurchaseCountForFrequency && m.freqRatio != null && m.freqRatio < 0.85) {
        components.push({
          category: 'SKU_FREQUENCY_DROP_WATCH',
          level: m.freqRatio < 0.75 ? 'medium' : 'low',
          deviationStrength: Math.min(1, (1 - m.freqRatio) / 0.3),
          reason: 'کاهش زودهنگام در تعداد دفعات خرید «' + m.productName + '» مشاهده می‌شود',
          evidence: { recentFrequency: m.recentFrequency, expectedFrequency: m.expectedFrequency, ratio: m.freqRatio, purchaseCount: m.purchaseCount, comparison: 'دفعات خرید اخیر در برابر دفعات مورد انتظار در همان پنجره' }
        });
      }

      // D) LINE_DROP_WATCH
      // W-LINE-DROP-TIMING fix: Confirmed (LINE_DROP) fires on a *relative*
      // drop of currentBasketPresence <= 0.5 * historicalPresenceRate, i.e.
      // an absolute-point drop of (0.5 * historicalPresenceRate). The old
      // fixed 0.30 gate here could exceed that for any product with
      // historicalPresenceRate < 0.60, letting Confirmed fire before Watch
      // ever did. Using min(0.30, 0.4 * historicalPresenceRate) keeps the
      // original 0.30 threshold unchanged for higher-presence products
      // (rate >= 0.75, where 0.4*rate already exceeds 0.30) while scaling
      // the gate down proportionally below that, so it is always strictly
      // below Confirmed's 0.5*rate threshold. Level bands/deviationStrength
      // are left untouched.
      var lineDropGate = 0.30;
      if (m.historicalPresenceRate != null) {
        lineDropGate = Math.min(0.30, 0.4 * m.historicalPresenceRate);
      }
      if (m.presenceDrop != null && m.presenceDrop >= lineDropGate) {
        components.push({
          category: 'LINE_DROP_WATCH',
          level: m.presenceDrop >= 0.45 ? 'medium' : 'low',
          deviationStrength: Math.min(1, m.presenceDrop / 0.5),
          reason: '«' + m.productName + '» به‌تدریج از سبد خریدهای اخیر کم‌رنگ‌تر شده است',
          evidence: { historicalPresenceRate: m.historicalPresenceRate, currentBasketPresence: m.currentBasketPresence, presenceDrop: m.presenceDrop, comparison: 'حضور تاریخی کالا در سبد در برابر حضور فعلی' }
        });
      }

      if (!components.length) continue;

      if (components.length >= 2) {
        var level = 'low';
        var deviationStrength = 0;
        var watchComponents = [];
        var reasons = [];
        for (var c = 0; c < components.length; c++) {
          level = _watchLevelMax(level, components[c].level);
          if (components[c].deviationStrength > deviationStrength) deviationStrength = components[c].deviationStrength;
          watchComponents.push(components[c].category);
          reasons.push(components[c].reason);
        }
        out.push({
          customerId: customerId,
          productId: m.productId,
          familyId: m.familyId,
          productName: m.productName,
          category: 'COMBINED_SKU_WATCH',
          level: level,
          reason: reasons.join('؛ '),
          deviationStrength: deviationStrength,
          source: 'sku',
          watchComponents: watchComponents,
          evidence: { components: components.map(function (x) { return { category: x.category, evidence: x.evidence || null }; }) }
        });
      } else {
        var comp = components[0];
        out.push({
          customerId: customerId,
          productId: m.productId,
          familyId: m.familyId,
          productName: m.productName,
          category: comp.category,
          level: comp.level,
          reason: comp.reason,
          deviationStrength: comp.deviationStrength,
          source: 'sku',
          watchComponents: null,
          evidence: comp.evidence || null
        });
      }
    }
    return out;
  }

  global._extractSkuRawMetrics = _extractSkuRawMetrics;
  global.extractSkuWatchObservations = extractSkuWatchObservations;

})(typeof window !== 'undefined' ? window : this);
