import { useMemo, useState, type ChangeEvent } from 'react';
import {
  ArrowLeft,
  ArrowUpDown,
  CalendarDays,
  CheckCircle2,
  FileText,
  Search,
  Wallet,
  X,
} from 'lucide-react';

export type InvoiceRow = {
  id: string;
  number: string;
  customerId: string;
  customer: string;
  buyerName: string;
  date: string;
  rawDate: string;
  total: number;
  paid: number;
  remain: number;
  status: 'paid' | 'debt';
  statusLabel: string;
  itemsCount: number;
};

export type InvoicesSnapshot = {
  rows: InvoiceRow[];
  totalCount: number;
  paidCount: number;
  debtCount: number;
  updatedAt: number;
};

type Filter = 'all' | 'paid' | 'debt';
type Sort = 'newest' | 'oldest' | 'amountDesc' | 'amountAsc';

const fa = (value: number) => new Intl.NumberFormat('fa-IR').format(Math.round(Number(value) || 0));
const money = (value: number) => `${fa(value)} تومان`;
const compact = (value: number) => {
  const amount = Number(value) || 0;
  const abs = Math.abs(amount);
  if (abs >= 1_000_000_000) return `${(amount / 1_000_000_000).toFixed(1).replace(/\.0$/, '')} میلیارد`;
  if (abs >= 1_000_000) return `${(amount / 1_000_000).toFixed(1).replace(/\.0$/, '')} میلیون`;
  return money(amount);
};

function normalizeSearch(value: string) {
  return value.toLocaleLowerCase('fa')
    .replace(/[۰-۹]/g, (digit) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)))
    .replace(/[٠-٩]/g, (digit) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)))
    .trim();
}

export default function Invoices({ snapshot, onNavigate }: {
  snapshot: InvoicesSnapshot | null;
  onNavigate: (path: string) => void;
}) {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<Filter>('all');
  const [sort, setSort] = useState<Sort>('newest');

  const rows = snapshot?.rows ?? [];
  const filtered = useMemo(() => {
    const q = normalizeSearch(query);
    const result = rows.filter((row) => {
      if (q) {
        const haystack = normalizeSearch([row.number, row.customer, row.buyerName].join(' '));
        if (!haystack.includes(q)) return false;
      }
      if (filter === 'paid' && row.status !== 'paid') return false;
      if (filter === 'debt' && row.status !== 'debt') return false;
      return true;
    });

    result.sort((a, b) => {
      if (sort === 'oldest') return a.rawDate.localeCompare(b.rawDate) || a.number.localeCompare(b.number);
      if (sort === 'amountDesc') return b.total - a.total || b.rawDate.localeCompare(a.rawDate);
      if (sort === 'amountAsc') return a.total - b.total || b.rawDate.localeCompare(a.rawDate);
      return b.rawDate.localeCompare(a.rawDate) || b.number.localeCompare(a.number);
    });
    return result;
  }, [rows, query, filter, sort]);

  if (!snapshot) {
    return <div className="invoices-page" dir="rtl"><div className="customers-loading"><span className="nd-spinner"/> در حال دریافت فاکتورها…</div></div>;
  }

  return (
    <div className="invoices-page" dir="rtl">
      <div className="invoices-intro">
        <div>
          <span className="invoices-eyebrow">فروش و تسویه</span>
          <h1>فاکتورها</h1>
          <p>سوابق فروش، مشتری و مانده هر فاکتور</p>
        </div>
        <span className="invoices-total-count">{fa(snapshot.totalCount)} فاکتور</span>
      </div>

      <div className="invoices-overview" aria-label="خلاصه فاکتورها">
        <div className="invoices-overview-main">
          <span className="invoices-overview-icon"><FileText size={18}/></span>
          <span><strong>{fa(snapshot.totalCount)}</strong><small>همه فاکتورها</small></span>
        </div>
        <div>
          <span className="invoices-overview-number is-debt">{fa(snapshot.debtCount)}</span>
          <small>دارای مانده</small>
        </div>
        <div>
          <span className="invoices-overview-number is-paid">{fa(snapshot.paidCount)}</span>
          <small>تسویه‌شده</small>
        </div>
      </div>

      <div className="invoices-search-wrap">
        <Search size={18}/>
        <input
          value={query}
          onChange={(event: ChangeEvent<HTMLInputElement>) => setQuery(event.target.value)}
          placeholder="شماره فاکتور یا نام مشتری را جستجو کن"
          aria-label="جستجوی فاکتورها"
        />
        {query && <button type="button" onClick={() => setQuery('')} aria-label="پاک کردن جستجو"><X size={16}/></button>}
      </div>

      <div className="invoices-toolbar">
        <div className="invoices-filters" role="group" aria-label="فیلتر وضعیت فاکتور">
          {([
            ['all', 'همه'],
            ['debt', 'دارای مانده'],
            ['paid', 'تسویه‌شده'],
          ] as Array<[Filter, string]>).map(([value, label]) => (
            <button
              key={value}
              type="button"
              className={filter === value ? 'is-selected' : ''}
              aria-pressed={filter === value}
              onClick={() => setFilter(value)}
            >
              {label}
            </button>
          ))}
        </div>
        <label className="invoices-sort">
          <ArrowUpDown size={15}/>
          <span>مرتب‌سازی</span>
          <select value={sort} onChange={(event) => setSort(event.target.value as Sort)} aria-label="مرتب‌سازی فاکتورها">
            <option value="newest">جدیدترین</option>
            <option value="oldest">قدیمی‌ترین</option>
            <option value="amountDesc">بیشترین مبلغ</option>
            <option value="amountAsc">کمترین مبلغ</option>
          </select>
        </label>
      </div>

      <div className="invoices-list-heading">
        <strong>سوابق فاکتور</strong>
        <small>{fa(filtered.length)} مورد</small>
      </div>

      <div className="invoices-list">
        {filtered.length ? filtered.map((row) => (
          <button
            className="invoice-list-row"
            type="button"
            key={row.id}
            onClick={() => onNavigate(`/invoice?id=${encodeURIComponent(row.id)}`)}
          >
            <span className="invoice-list-icon"><FileText size={17}/></span>
            <span className="invoice-list-copy">
              <strong>فاکتور #{row.number || '—'}</strong>
              <span className="invoice-list-customer">{row.customer}{row.buyerName ? ` · ${row.buyerName}` : ''}</span>
              <small><CalendarDays size={12}/>{row.date}<i>·</i><em className={row.status === 'paid' ? 'is-paid' : 'is-debt'}>{row.statusLabel}</em></small>
            </span>
            <span className="invoice-list-amount">
              <strong>{compact(row.total)}</strong>
              {row.remain > 0.5
                ? <small className="is-debt">مانده {compact(row.remain)}</small>
                : <small className="is-paid"><CheckCircle2 size={12}/> تسویه</small>}
              {row.paid > 0 && row.remain > 0.5 && <small className="invoice-list-paid">پرداخت {compact(row.paid)}</small>}
            </span>
            <ArrowLeft className="invoice-list-chevron" size={16}/>
          </button>
        )) : (
          <div className="invoices-empty">
            <span><Search size={20}/></span>
            <strong>{rows.length ? 'فاکتوری با این مشخصات پیدا نشد' : 'هنوز فاکتوری ثبت نشده است'}</strong>
            <p>{rows.length ? 'عبارت جستجو یا فیلتر وضعیت را تغییر بده.' : 'پس از ثبت اولین فاکتور، سوابق فروش در این صفحه نمایش داده می‌شود.'}</p>
            {(query || filter !== 'all') && <button type="button" onClick={() => { setQuery(''); setFilter('all'); }}>پاک کردن جستجو و فیلتر</button>}
          </div>
        )}
      </div>

      <div className="invoices-footer-note">
        <Wallet size={13}/>
        <span>وضعیت پرداخت از محاسبات رسمی فاکتور خوانده می‌شود؛ این صفحه فقط برای نمایش و جستجو است.</span>
      </div>
    </div>
  );
}
