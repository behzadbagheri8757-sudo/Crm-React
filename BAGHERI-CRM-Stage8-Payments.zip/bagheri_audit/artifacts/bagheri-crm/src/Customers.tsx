import { useMemo, useState, type ChangeEvent } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  ArrowUpDown,
  Building2,
  MapPin,
  Plus,
  Search,
  SlidersHorizontal,
  UserRound,
  UsersRound,
  Wallet,
  X,
} from 'lucide-react';

export type CustomerRow = {
  id: string;
  name: string;
  phone: string;
  ownerName: string;
  region: string;
  address: string;
  active: boolean;
  oneOff: boolean;
  balance: number;
  invoiceTotal: number;
  invoiceCount: number;
  lastPurchaseDate: string;
  lastPurchaseRaw: string;
  daysSinceLast: number | null;
  lastVisitDate: string;
  lastVisitRaw: string;
  status: string;
  badgeLabel: string;
  badgeTone: string;
  priorityScore: number;
  riskLevel: string;
  watchCount: number;
  behindPattern: boolean;
};

export type CustomersSnapshot = {
  customers: CustomerRow[];
  updatedAt: number;
};

type BalanceFilter = 'all' | 'debt' | 'settled' | 'credit';
type ActivityFilter = 'all' | 'active' | 'cold' | 'new' | 'disabled';
type SortMode = 'priority' | 'debt' | 'last_purchase' | 'name';

const fa = (value: number) => new Intl.NumberFormat('fa-IR').format(Math.round(Number(value) || 0));
const compact = (value: number) => {
  const amount = Number(value) || 0;
  const absolute = Math.abs(amount);
  if (absolute >= 1_000_000_000) return `${(amount / 1_000_000_000).toFixed(1).replace(/\.0$/, '')} میلیارد`;
  if (absolute >= 1_000_000) return `${(amount / 1_000_000).toFixed(1).replace(/\.0$/, '')} میلیون`;
  return `${fa(amount)} تومان`;
};

function balanceLabel(balance: number) {
  if (balance > 0) return 'بدهکار';
  if (balance < 0) return 'بستانکار';
  return 'تسویه';
}

function activityLabel(row: CustomerRow) {
  if (row.active === false) return 'غیرفعال';
  if (row.oneOff) return 'یک‌بارمصرف';
  if (row.status === 'lost') return 'از دست رفته';
  if (row.status === 'inactive') return 'سرد شده';
  if (row.status === 'new') return 'مشتری جدید';
  return 'فعال';
}

export default function Customers({ snapshot, onNavigate, onAddCustomer, initialBalanceFilter }: {
  snapshot: CustomersSnapshot | null;
  onNavigate: (path: string) => void;
  onAddCustomer: () => void;
  initialBalanceFilter?: BalanceFilter;
}) {
  const [query, setQuery] = useState('');
  const [balanceFilter, setBalanceFilter] = useState<BalanceFilter>(initialBalanceFilter ?? 'all');
  const [activityFilter, setActivityFilter] = useState<ActivityFilter>('all');
  const [sort, setSort] = useState<SortMode>('priority');
  const [region, setRegion] = useState('all');
  const [showFilters, setShowFilters] = useState(false);

  const rows = snapshot?.customers ?? [];
  const regions = useMemo(() => Array.from(new Set(rows.map((row) => row.region.trim()).filter(Boolean))).sort((a, b) => a.localeCompare(b, 'fa')), [rows]);

  const filtered = useMemo(() => {
    const q = query.trim().toLocaleLowerCase('fa');
    const result = rows.filter((row) => {
      if (q && ![row.name, row.phone, row.ownerName, row.region, row.address].some((value) => value.toLocaleLowerCase('fa').includes(q))) return false;
      if (balanceFilter === 'debt' && row.balance <= 0) return false;
      if (balanceFilter === 'settled' && row.balance !== 0) return false;
      if (balanceFilter === 'credit' && row.balance >= 0) return false;
      if (activityFilter === 'active' && row.status !== 'active') return false;
      if (activityFilter === 'cold' && row.status !== 'inactive' && row.status !== 'lost') return false;
      if (activityFilter === 'new' && row.status !== 'new') return false;
      if (activityFilter === 'disabled' && row.active !== false) return false;
      if (region !== 'all' && row.region !== region) return false;
      return true;
    });

    result.sort((a, b) => {
      if (sort === 'debt') return b.balance - a.balance || a.name.localeCompare(b.name, 'fa');
      if (sort === 'last_purchase') return (b.lastPurchaseRaw || '').localeCompare(a.lastPurchaseRaw || '') || a.name.localeCompare(b.name, 'fa');
      if (sort === 'name') return a.name.localeCompare(b.name, 'fa');
      return b.priorityScore - a.priorityScore || a.name.localeCompare(b.name, 'fa');
    });
    return result;
  }, [rows, query, balanceFilter, activityFilter, sort, region]);

  const debtors = rows.filter((row) => row.balance > 0).length;
  const watched = rows.filter((row) => row.watchCount > 0).length;
  const active = rows.filter((row) => row.status === 'active' && row.active !== false).length;

  const clearFilters = () => {
    setQuery('');
    setBalanceFilter('all');
    setActivityFilter('all');
    setRegion('all');
    setSort('priority');
  };

  if (!snapshot) {
    return <div className="customers-page" dir="rtl"><div className="customers-loading"><span className="nd-spinner"/> در حال دریافت فهرست مشتریان…</div></div>;
  }

  return (
    <div className="customers-page" dir="rtl">
      <div className="customers-intro">
        <div>
          <span className="customers-eyebrow">ارتباط و پیگیری</span>
          <h1>مشتریان</h1>
          <p>فهرست مشتریان و وضعیت حساب هرکدام</p>
        </div>
        <button className="customers-add" onClick={onAddCustomer} type="button"><Plus size={17}/> مشتری جدید</button>
      </div>

      <div className="customers-overview" aria-label="خلاصه مشتریان">
        <div className="customers-overview-main"><span className="customers-overview-icon"><UsersRound size={18}/></span><div><strong>{fa(rows.length)}</strong><small>همه مشتریان</small></div></div>
        <div><span className="customers-overview-number debt">{fa(debtors)}</span><small>بدهکار</small></div>
        <div><span className="customers-overview-number">{fa(active)}</span><small>فعال</small></div>
        <div><span className="customers-overview-number watch">{fa(watched)}</span><small>دارای هشدار</small></div>
      </div>

      <div className="customers-search-wrap">
        <Search size={18}/>
        <input value={query} onChange={(event: ChangeEvent<HTMLInputElement>) => setQuery(event.target.value)} placeholder="نام، تلفن، مسئول یا منطقه را جستجو کن" aria-label="جستجوی مشتریان" />
        {query && <button type="button" onClick={() => setQuery('')} aria-label="پاک کردن جستجو"><X size={16}/></button>}
      </div>

      <div className="customers-filter-head">
        <div className="customers-balance-filters" role="group" aria-label="فیلتر مانده حساب">
          {([
            ['all', 'همه'], ['debt', 'بدهکار'], ['settled', 'تسویه'], ['credit', 'بستانکار'],
          ] as Array<[BalanceFilter, string]>).map(([value, label]) => (
            <button type="button" key={value} className={balanceFilter === value ? 'is-selected' : ''} onClick={() => setBalanceFilter(value)}>{label}</button>
          ))}
        </div>
        <button type="button" className={`customers-filter-toggle${showFilters ? ' is-open' : ''}`} onClick={() => setShowFilters((value) => !value)} aria-expanded={showFilters}>
          <SlidersHorizontal size={16}/><span>فیلترها</span>
        </button>
      </div>

      {showFilters && <div className="customers-filter-panel">
        <label>وضعیت مشتری
          <select value={activityFilter} onChange={(event: ChangeEvent<HTMLSelectElement>) => setActivityFilter(event.target.value as ActivityFilter)}>
            <option value="all">همه وضعیت‌ها</option>
            <option value="active">فعال</option>
            <option value="cold">سرد شده یا از دست رفته</option>
            <option value="new">جدید و بدون خرید</option>
            <option value="disabled">غیرفعال‌شده</option>
          </select>
        </label>
        <label>منطقه
          <select value={region} onChange={(event: ChangeEvent<HTMLSelectElement>) => setRegion(event.target.value)}>
            <option value="all">همه مناطق</option>
            {regions.map((item) => <option value={item} key={item}>{item}</option>)}
          </select>
        </label>
        <label>مرتب‌سازی
          <select value={sort} onChange={(event: ChangeEvent<HTMLSelectElement>) => setSort(event.target.value as SortMode)}>
            <option value="priority">اولویت پیگیری</option>
            <option value="debt">بیشترین بدهی</option>
            <option value="last_purchase">آخرین خرید</option>
            <option value="name">نام مشتری</option>
          </select>
        </label>
        <button className="customers-clear-filters" type="button" onClick={clearFilters}>پاک کردن فیلترها</button>
      </div>}

      <div className="customers-results-heading"><strong>{fa(filtered.length)} مشتری</strong><span><ArrowUpDown size={13}/> {sort === 'priority' ? 'بر اساس اولویت' : sort === 'debt' ? 'بر اساس بدهی' : sort === 'last_purchase' ? 'بر اساس آخرین خرید' : 'بر اساس نام'}</span></div>

      {filtered.length ? <div className="customers-list">
        {filtered.map((row) => {
          const status = activityLabel(row);
          const balance = balanceLabel(row.balance);
          const initials = row.name.trim().slice(0, 1) || 'م';
          return (
            <button className="customer-card-row" type="button" key={row.id} onClick={() => onNavigate(`/customer?id=${encodeURIComponent(row.id)}`)}>
              <span className={`customer-avatar${row.status === 'lost' || row.status === 'inactive' || row.active === false ? ' is-muted' : ''}`}>{initials}</span>
              <span className="customer-card-main">
                <span className="customer-card-title"><strong>{row.name}</strong>{row.watchCount > 0 && <span className="customer-watch-indicator" title={`${fa(row.watchCount)} هشدار فعال`}><AlertTriangle size={13}/>{fa(row.watchCount)}</span>}</span>
                <span className="customer-card-meta">
                  {row.ownerName && <span><UserRound size={12}/>{row.ownerName}</span>}
                  {row.region && <span><MapPin size={12}/>{row.region}</span>}
                  {!row.ownerName && !row.region && <span><Building2 size={12}/>{row.phone || 'اطلاعات تماس ثبت نشده'}</span>}
                </span>
                <span className="customer-card-foot">
                  <span className={`customer-status-tag tone-${row.badgeTone || 'neutral'}`}>{row.badgeLabel || status}</span>
                  <span>{row.lastPurchaseDate ? `آخرین خرید: ${row.lastPurchaseDate}` : 'هنوز خریدی ثبت نشده'}</span>
                </span>
              </span>
              <span className="customer-card-balance">
                <span className={`customer-balance-tag ${row.balance > 0 ? 'is-debt' : row.balance < 0 ? 'is-credit' : 'is-settled'}`}>{balance}</span>
                <strong>{row.balance !== 0 ? compact(Math.abs(row.balance)) : '—'}</strong>
                <small>{row.invoiceCount ? `${fa(row.invoiceCount)} فاکتور` : 'بدون فاکتور'}</small>
              </span>
              <ArrowLeft className="customer-card-chevron" size={16}/>
            </button>
          );
        })}
      </div> : <div className="customers-empty">
        <span><Wallet size={22}/></span>
        <strong>مشتری‌ای با این شرایط پیدا نشد</strong>
        <p>عبارت جستجو یا فیلترها را تغییر بده.</p>
        <button type="button" onClick={clearFilters}>نمایش همه مشتریان</button>
      </div>}

      <div className="customers-bottom-note">اطلاعات حساب و اولویت از محاسبات فعلی برنامه خوانده می‌شود؛ این صفحه فقط نمایش و فیلتر می‌کند.</div>
    </div>
  );
}
