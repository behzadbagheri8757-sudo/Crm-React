if (import.meta.env.PROD && "serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    void navigator.serviceWorker.register("./bagheri-root-sw.js", {
      scope: "./",
    }).catch((error: unknown) => {
      console.error("Offline support could not be enabled.", error);
    });
  }, { once: true });
}
