import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Dashboard, { type DashboardSnapshot } from './Dashboard';
import Customers, { type CustomersSnapshot } from './Customers';
import CustomerDetail, { type CustomerDetailSnapshot } from './CustomerDetail';
import Invoices, { type InvoicesSnapshot } from './Invoices';
import InvoiceDetail, { type InvoiceDetailSnapshot } from './InvoiceDetail';
import Reports, { type ReportsSnapshot, type ReportPeriod } from './Reports';
import Payments, { type PaymentsSnapshot } from './Payments';
import {
  ArrowRight,
  ChartNoAxesCombined,
  Ellipsis,
  Home,
  Moon,
  Plus,
  ReceiptText,
  RotateCw,
  ShieldCheck,
  Sun,
  UsersRound,
  Wifi,
} from 'lucide-react';

type ThemePreference = 'system' | 'light' | 'dark';
type Tab = { path: string; label: string; icon: typeof Home };

const TABS: Tab[] = [
  { path: '/dashboard', label: 'داشبورد', icon: Home },
  { path: '/customers', label: 'مشتریان', icon: UsersRound },
  { path: '/reports', label: 'گزارش‌ها', icon: ChartNoAxesCombined },
  { path: '/invoices', label: 'فاکتورها', icon: ReceiptText },
  { path: '/more', label: 'بیشتر', icon: Ellipsis },
];

const ROUTE_NAMES: Record<string, string> = {
  '/dashboard': 'داشبورد',
  '/customers': 'مشتریان',
  '/customer': 'پرونده مشتری',
  '/reports': 'گزارش‌ها',
  '/invoices': 'فاکتورها',
  '/invoice': 'جزئیات فاکتور',
  '/more': 'همه بخش‌ها',
  '/products': 'اجناس',
  '/inventory': 'انبار',
  '/suppliers': 'تأمین‌کنندگان',
  '/supplier': 'پرونده تأمین‌کننده',
  '/payments': 'دریافت‌ها',
  '/checks': 'چک‌ها',
  '/visits': 'ویزیت مشتریان',
  '/prospects': 'ارزیابی مغازه‌ها',
  '/prospect': 'پرونده مغازه',
  '/prospect-routes': 'مسیر مغازه‌ها',
  '/locations': 'موقعیت‌های مکانی',
  '/evaluation': 'ارزیابی',
  '/watches': 'هشدارهای زودهنگام',
  '/watch': 'جزئیات هشدار',
  '/game': 'مرکز بازی فروش',
  '/settings': 'تنظیمات و پشتیبان',
};

const THEME_KEY = 'baqeri_theme_v1';
const APP_BASE = import.meta.env.BASE_URL;
const LEGACY_URL = `${APP_BASE}legacy/index.html#/dashboard`;

function routeFromHash(hash: string) {
  const raw = hash.replace(/^#/, '');
  const path = raw.split('?')[0];
  return path.startsWith('/') ? path : '/dashboard';
}

function queryFromHash(hash: string, key: string) {
  const query = hash.includes('?') ? hash.slice(hash.indexOf('?') + 1) : '';
  return new URLSearchParams(query).get(key) || '';
}

function preferenceFromStorage(): ThemePreference {
  try {
    const value = window.localStorage.getItem(THEME_KEY);
    if (value === 'dark' || value === 'light' || value === 'system') return value;
  } catch {
    // Storage may be disabled; system appearance remains a safe fallback.
  }
  return 'system';
}

function resolveTheme(preference: ThemePreference): 'light' | 'dark' {
  if (preference !== 'system') return preference;
  return window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

function setThemeColor(theme: 'light' | 'dark') {
  const themeMeta = document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');
  if (themeMeta) themeMeta.content = theme === 'dark' ? '#111a15' : '#f6f8f6';
}

function addLegacyTestIds(root: ParentNode) {
  const targets = root.querySelectorAll<HTMLElement>(
    'a[href], button, input, select, textarea, [role="button"], [tabindex="0"]',
  );
  targets.forEach((element, index) => {
    if (element.dataset.testid) return;
    const id = element.id || element.getAttribute('href') || element.getAttribute('aria-label') ||
      element.textContent?.trim().slice(0, 28) || `item-${index + 1}`;
    const slug = id.toLowerCase().replace(/[^a-z0-9\u0600-\u06ff]+/g, '-').replace(/^-|-$/g, '').slice(0, 42);
    element.dataset.testid = `legacy-${element.tagName.toLowerCase()}-${slug || `control-${index + 1}`}`;
  });
}

function App() {
  const frameRef = useRef<HTMLIFrameElement>(null);
  const testIdObserver = useRef<MutationObserver | null>(null);
  const fabObserver = useRef<MutationObserver | null>(null);
  const modalObserver = useRef<MutationObserver | null>(null);
  const hostActionPending = useRef(false);
  const hostActionModalSeen = useRef(false);
  const checkLegacyFab = useRef<() => void>(() => undefined);
  const [route, setRoute] = useState(() => {
    const initial = routeFromHash(window.location.hash);
    return ROUTE_NAMES[initial] ? initial : '/dashboard';
  });
  const [loaded, setLoaded] = useState(false);
  const [frameError, setFrameError] = useState(false);
  const [legacyActionOpen, setLegacyActionOpen] = useState(false);
  const [primaryAction, setPrimaryAction] = useState(false);
  const [online, setOnline] = useState(() => navigator.onLine);
  const [preference, setPreference] = useState<ThemePreference>(preferenceFromStorage);
  const [resolvedTheme, setResolvedTheme] = useState<'light' | 'dark'>(() => resolveTheme(preferenceFromStorage()));
  const [toast, setToast] = useState('');
  const [dashboardSnapshot, setDashboardSnapshot] = useState<DashboardSnapshot | null>(null);
  const [customersSnapshot, setCustomersSnapshot] = useState<CustomersSnapshot | null>(null);
  const [customerDetailSnapshot, setCustomerDetailSnapshot] = useState<CustomerDetailSnapshot | null>(null);
  const [invoicesSnapshot, setInvoicesSnapshot] = useState<InvoicesSnapshot | null>(null);
  const [invoiceDetailSnapshot, setInvoiceDetailSnapshot] = useState<InvoiceDetailSnapshot | null>(null);
  const [reportsSnapshot, setReportsSnapshot] = useState<ReportsSnapshot | null>(null);
  const [paymentsSnapshot, setPaymentsSnapshot] = useState<PaymentsSnapshot | null>(null);
  const [reportsPeriod, setReportsPeriod] = useState<ReportPeriod>('month');
  const [invoiceDetailSnapshotId, setInvoiceDetailSnapshotId] = useState('');
  const [customerDetailSnapshotId, setCustomerDetailSnapshotId] = useState('');
  const [showLegacyCustomers, setShowLegacyCustomers] = useState(false);
  const initialNavigation = useRef(true);
  const title = useMemo(() => ROUTE_NAMES[route] || 'باقری', [route]);
  const primary = TABS.slice(0, 4).some((tab) => tab.path === route);
  const activeTab = primary ? route : '/more';
  const useNewCustomers = route === '/customers' && !showLegacyCustomers;
  const useNewCustomerDetail = route === '/customer' && !showLegacyCustomers;
  const useNewInvoices = route === '/invoices';
  const useNewReports = route === '/reports';
  const useNewPayments = route === '/payments';
  const useNewInvoiceDetail = route === '/invoice';
  const currentCustomerId = queryFromHash(window.location.hash, 'id');
  const currentInvoiceId = queryFromHash(window.location.hash, 'id');
  const visibleInvoiceDetail = invoiceDetailSnapshotId === currentInvoiceId ? invoiceDetailSnapshot : null;
  const visibleCustomerDetail = customerDetailSnapshotId === currentCustomerId ? customerDetailSnapshot : null;
  const hideLegacyFrame = route === '/dashboard' || useNewCustomers || useNewCustomerDetail || useNewInvoices || useNewInvoiceDetail || useNewReports || useNewPayments;

  const showToast = useCallback((message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(''), 2200);
  }, []);

  const syncHostHash = useCallback((hash: string) => {
    const nextHash = hash || '#/dashboard';
    if (window.location.hash === nextHash) return;
    try {
      window.history.replaceState(window.history.state, '', `${window.location.pathname}${window.location.search}${nextHash}`);
    } catch {
      // The embedded route remains authoritative if the host history is unavailable.
    }
  }, []);

  const navigateLegacy = useCallback((path: string) => {
    const frameWindow = frameRef.current?.contentWindow as (Window & {
      AppRouter?: { navigate?: (route: string, query?: Record<string, string>) => void };
    }) | undefined;
    if (!frameWindow) return;
    try {
      if (frameWindow.AppRouter?.navigate) {
        const [routePath, queryString] = path.split('?');
        const query = Object.fromEntries(new URLSearchParams(queryString || '').entries());
        frameWindow.AppRouter.navigate(routePath, query);
      } else frameWindow.location.hash = path;
    } catch {
      frameWindow.location.hash = path;
    }
  }, []);

  const refreshDashboard = useCallback(() => {
    try {
      const child = frameRef.current?.contentWindow as (Window & { __BAGHERI_DASHBOARD_BRIDGE__?: { getSnapshot?: () => DashboardSnapshot | null } }) | undefined;
      const next = child?.__BAGHERI_DASHBOARD_BRIDGE__?.getSnapshot?.();
      if (next) setDashboardSnapshot(next);
    } catch {
      // The local data engine may still be loading; the dashboard remains in its loading state.
    }
  }, []);

  const refreshCustomers = useCallback(() => {
    try {
      const child = frameRef.current?.contentWindow as (Window & { __BAGHERI_DASHBOARD_BRIDGE__?: { getCustomersSnapshot?: () => CustomersSnapshot | null } }) | undefined;
      const next = child?.__BAGHERI_DASHBOARD_BRIDGE__?.getCustomersSnapshot?.();
      if (next) setCustomersSnapshot(next);
    } catch {
      // The existing data engine may still be loading; retain the last known list.
    }
  }, []);

  const refreshCustomerDetail = useCallback(() => {
    try {
      const child = frameRef.current?.contentWindow as (Window & { __BAGHERI_DASHBOARD_BRIDGE__?: { getCustomerDetailSnapshot?: (id: string) => CustomerDetailSnapshot | null } }) | undefined;
      const childHash = child?.location.hash || window.location.hash;
      const id = queryFromHash(childHash, 'id') || currentCustomerId;
      if (!id) return;
      const next = child?.__BAGHERI_DASHBOARD_BRIDGE__?.getCustomerDetailSnapshot?.(id);
      if (next) {
        setCustomerDetailSnapshot(next);
        setCustomerDetailSnapshotId(id);
      }
    } catch {
      // The legacy data engine may still be loading; keep the current snapshot until it is ready.
    }
  }, [currentCustomerId]);

  const refreshInvoices = useCallback(() => {
    try {
      const child = frameRef.current?.contentWindow as (Window & { __BAGHERI_DASHBOARD_BRIDGE__?: { getInvoicesSnapshot?: () => InvoicesSnapshot | null; getInvoiceDetailSnapshot?: (id: string) => InvoiceDetailSnapshot | null } }) | undefined;
      const next = child?.__BAGHERI_DASHBOARD_BRIDGE__?.getInvoicesSnapshot?.();
      if (next) setInvoicesSnapshot(next);
    } catch {
      // Invoice data is read from the existing local engine; keep the last snapshot while it loads.
    }
  }, []);

  const refreshReports = useCallback((period: ReportPeriod = reportsPeriod) => {
    try {
      const child = frameRef.current?.contentWindow as (Window & { __BAGHERI_DASHBOARD_BRIDGE__?: { getReportsSnapshot?: (value: ReportPeriod) => ReportsSnapshot | null } }) | undefined;
      const next = child?.__BAGHERI_DASHBOARD_BRIDGE__?.getReportsSnapshot?.(period);
      if (next) setReportsSnapshot(next);
    } catch {
      // The legacy calculation layer may still be initializing; retain the last valid report.
    }
  }, [reportsPeriod]);

  const refreshPayments = useCallback(() => {
    try {
      const child = frameRef.current?.contentWindow as (Window & { __BAGHERI_DASHBOARD_BRIDGE__?: { getPaymentsSnapshot?: () => PaymentsSnapshot | null } }) | undefined;
      const next = child?.__BAGHERI_DASHBOARD_BRIDGE__?.getPaymentsSnapshot?.();
      if (next) setPaymentsSnapshot(next);
    } catch {
      // The existing local payment records may still be loading; retain the last snapshot.
    }
  }, []);

  const changeReportsPeriod = useCallback((period: ReportPeriod) => {
    setReportsPeriod(period);
    refreshReports(period);
  }, [refreshReports]);

  const refreshInvoiceDetail = useCallback(() => {
    try {
      const child = frameRef.current?.contentWindow as (Window & { __BAGHERI_DASHBOARD_BRIDGE__?: { getInvoiceDetailSnapshot?: (id: string) => InvoiceDetailSnapshot | null } }) | undefined;
      const childHash = child?.location.hash || window.location.hash;
      const id = queryFromHash(childHash, 'id') || currentInvoiceId;
      if (!id) return;
      const next = child?.__BAGHERI_DASHBOARD_BRIDGE__?.getInvoiceDetailSnapshot?.(id);
      if (next) {
        setInvoiceDetailSnapshot(next);
        setInvoiceDetailSnapshotId(id);
      }
    } catch {
      // The official local data engine may still be loading.
    }
  }, [currentInvoiceId]);

  const runInvoiceAction = useCallback((action: string, invoiceId: string, visitId?: string) => {
    const frame = frameRef.current;
    const child = frame?.contentWindow as (Window & { __BAGHERI_DASHBOARD_BRIDGE__?: { runInvoiceAction?: (action: string, id: string, visitId?: string) => boolean } }) | null;
    const childDocument = frame?.contentDocument;
    const closeHostAction = () => {
      hostActionPending.current = false;
      hostActionModalSeen.current = false;
      try { childDocument?.body.classList.remove('host-action-mode'); } catch { /* iframe may have navigated */ }
      setLegacyActionOpen(false);
    };
    try {
      if (action === 'image') {
        const ok = child?.__BAGHERI_DASHBOARD_BRIDGE__?.runInvoiceAction?.(action, invoiceId, visitId);
        if (!ok) showToast('خروجی تصویر در دسترس نیست');
        else showToast('در حال آماده‌سازی تصویر فاکتور');
        window.setTimeout(refreshInvoiceDetail, 1200);
        return;
      }
      hostActionPending.current = true;
      hostActionModalSeen.current = false;
      childDocument?.body.classList.add('host-action-mode');
      setLegacyActionOpen(true);
      const ok = child?.__BAGHERI_DASHBOARD_BRIDGE__?.runInvoiceAction?.(action, invoiceId, visitId);
      if (!ok) {
        closeHostAction();
        showToast('این عملیات در نسخه فعلی در دسترس نیست');
        return;
      }
      if (action === 'print') {
        child?.addEventListener('afterprint', closeHostAction, { once: true });
        window.setTimeout(closeHostAction, 30000);
      } else {
        window.setTimeout(() => {
          if (hostActionPending.current && !hostActionModalSeen.current) closeHostAction();
        }, 1800);
      }
      window.setTimeout(refreshInvoiceDetail, 1000);
    } catch {
      closeHostAction();
      showToast('اجرای عملیات فاکتور ممکن نشد');
    }
  }, [refreshInvoiceDetail, showToast]);

  const runCustomerAction = useCallback((action: string, customerId: string) => {
    const frame = frameRef.current;
    const child = frame?.contentWindow as (Window & { __BAGHERI_DASHBOARD_BRIDGE__?: { runCustomerAction?: (action: string, id: string) => boolean } }) | null;
    const childDocument = frame?.contentDocument;
    const closeHostAction = () => {
      hostActionPending.current = false;
      hostActionModalSeen.current = false;
      try { childDocument?.body.classList.remove('host-action-mode'); } catch { /* iframe may have navigated */ }
      setLegacyActionOpen(false);
    };
    try {
      hostActionPending.current = true;
      hostActionModalSeen.current = false;
      childDocument?.body.classList.add('host-action-mode');
      setLegacyActionOpen(true);
      const ok = child?.__BAGHERI_DASHBOARD_BRIDGE__?.runCustomerAction?.(action, customerId);
      if (!ok) {
        closeHostAction();
        showToast('این عملیات در نسخه فعلی در دسترس نیست');
        return;
      }
      if (action === 'statement') {
        child?.addEventListener('afterprint', closeHostAction, { once: true });
        window.setTimeout(closeHostAction, 30000);
      } else {
        window.setTimeout(() => {
          if (hostActionPending.current && !hostActionModalSeen.current) closeHostAction();
        }, 1800);
      }
      window.setTimeout(refreshCustomerDetail, 900);
    } catch {
      closeHostAction();
      showToast('اجرای عملیات ممکن نشد');
    }
  }, [refreshCustomerDetail, showToast]);

  const openLegacyCustomerCreator = useCallback(() => {
    setShowLegacyCustomers(true);
    navigateLegacy('/customers');
  }, [navigateLegacy]);

  const returnToNewCustomers = useCallback(() => {
    refreshCustomers();
    setShowLegacyCustomers(false);
  }, [refreshCustomers]);

  const applyTheme = useCallback((nextPreference: ThemePreference) => {
    const next = resolveTheme(nextPreference);
    setPreference(nextPreference);
    setResolvedTheme(next);
    document.documentElement.classList.toggle('dark', next === 'dark');
    setThemeColor(next);
    try {
      window.localStorage.setItem(THEME_KEY, nextPreference);
    } catch {
      // Theme still applies for this session without persistent storage.
    }
    const child = frameRef.current?.contentWindow as (Window & {
      BaqeriTheme?: { setPreference?: (value: ThemePreference) => void; apply?: (value: ThemePreference) => void };
    }) | undefined;
    try {
      if (child?.BaqeriTheme?.setPreference) child.BaqeriTheme.setPreference(nextPreference);
      else child?.BaqeriTheme?.apply?.(nextPreference);
    } catch {
      // The iframe may not have finished booting yet; onLoad reapplies it.
    }
  }, []);

  const handleFrameLoad = useCallback(() => {
    const frame = frameRef.current;
    if (!frame) return;
    let childDocument: Document | null = null;
    try {
      childDocument = frame.contentDocument;
    } catch {
      setFrameError(true);
      setLoaded(false);
      setPrimaryAction(false);
      return;
    }
    if (!childDocument?.body || !childDocument.getElementById('main')) {
      setFrameError(true);
      setLoaded(false);
      setPrimaryAction(false);
      return;
    }
    const updateFabState = () => {
      const legacyFab = childDocument?.getElementById('fab') as HTMLButtonElement | null;
      setPrimaryAction(Boolean(
        legacyFab &&
        legacyFab.style.display !== 'none' &&
        !legacyFab.hidden &&
        typeof legacyFab.onclick === 'function',
      ));
    };
    checkLegacyFab.current = updateFabState;
    updateFabState();
    fabObserver.current?.disconnect();
    const legacyFab = childDocument.getElementById('fab');
    if (legacyFab) {
      fabObserver.current = new MutationObserver(updateFabState);
      fabObserver.current.observe(legacyFab, { attributes: true, attributeFilter: ['style', 'hidden', 'class'] });
    }
    addLegacyTestIds(childDocument.body);
    testIdObserver.current?.disconnect();
    testIdObserver.current = new MutationObserver((records) => {
      records.forEach((record) => {
        record.addedNodes.forEach((node) => {
          if (node.nodeType === 1) addLegacyTestIds(node as Element);
        });
      });
    });
    testIdObserver.current.observe(childDocument.body, { childList: true, subtree: true });

    const cssHref = new URL(`${APP_BASE}legacy/ios-overrides.css`, window.location.origin).toString();
    if (!childDocument.querySelector('link[data-bagheri-ios-overrides]')) {
      const styleLink = childDocument.createElement('link');
      styleLink.rel = 'stylesheet';
      styleLink.href = cssHref;
      styleLink.dataset.bagheriIosOverrides = 'true';
      childDocument.head.appendChild(styleLink);
    }
    if (!childDocument.querySelector('style[data-bagheri-host-action]')) {
      const actionStyle = childDocument.createElement('style');
      actionStyle.dataset.bagheriHostAction = 'true';
      actionStyle.textContent = 'body.host-action-mode{background:transparent;}body.host-action-mode>header,body.host-action-mode>#nav,body.host-action-mode>#main,body.host-action-mode>#fab,body.host-action-mode>#toast{visibility:hidden;}';
      childDocument.head.appendChild(actionStyle);
    }
    const modalRoot = childDocument.getElementById('modalRoot');
    modalObserver.current?.disconnect();
    if (modalRoot) {
      modalObserver.current = new MutationObserver(() => {
        if (!hostActionPending.current) return;
        const activeLayer = modalRoot.querySelector('.overlay, .confirm-overlay, .shamsi-sheet-overlay');
        if (activeLayer) hostActionModalSeen.current = true;
        else if (hostActionModalSeen.current) {
          hostActionPending.current = false;
          hostActionModalSeen.current = false;
          childDocument?.body.classList.remove('host-action-mode');
          setLegacyActionOpen(false);
        }
      });
      modalObserver.current.observe(modalRoot, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style', 'hidden'] });
    }
    const bridgeScript = childDocument.createElement('script');
    bridgeScript.dataset.bagheriDashboardBridge = 'true';
    bridgeScript.textContent = `
      (function(g){
        function safe(fn, fallback){ try { return fn(); } catch(e) { return fallback; } }
        function dateLabel(value){ return safe(function(){ return typeof faDate === 'function' ? faDate(value) : String(value || ''); }, String(value || '')); }
        g.__BAGHERI_DASHBOARD_BRIDGE__ = {
          getSnapshot: function(){
            return safe(function(){
              var source = data || {};
              var now = new Date();
              var ctx = typeof createComputationContext === 'function' ? createComputationContext({data:source}) : null;
              var metrics = typeof commandCenterMetrics === 'function' ? commandCenterMetrics(now, ctx) : {mtdSales:0,mtdProfit:0,mtdCount:0,jd:0,jm:0,jy:0};
              var totals = typeof globalTotals === 'function' ? globalTotals(ctx) : {customerDebt:0,supplierDebt:0};
              var stockValue = typeof inventoryValue === 'function' ? inventoryValue() : 0;
              var target = typeof getMonthlySalesTarget === 'function' ? getMonthlySalesTarget() : 0;
              var todaySales=0, todayInvoices=0, received=0, visits=0;
              (source.invoices||[]).forEach(function(x){ if(typeof isSameDay==='function' && isSameDay(x.date,now)){todaySales += Number(x.total)||0; todayInvoices++;} });
              (source.payments||[]).forEach(function(x){ if(typeof isSameDay==='function' && isSameDay(x.date,now) && ['cash','card','transfer'].indexOf(x.method)!==-1) received += Number(x.amount)||0; });
              (source.customers||[]).forEach(function(c){ (c.visits||[]).forEach(function(v){ if(typeof isSameDay==='function' && isSameDay(v.date,now)) visits++; }); });
              var actions = typeof calculateAllActions==='function' ? (calculateAllActions(ctx)||[]) : [];
              actions = actions.filter(function(a){return a && a.actionType!=='no_action';}).slice(0,5).map(function(a,i){
                var customer = (source.customers||[]).find(function(c){return c.id===a.customerId;});
                var name = a.name || (customer && customer.name) || '—';
                var prospect = a.type==='prospect';
                return {id:String(a.customerId||a.prospectId||i),name:name,kind:prospect?'مغازه':'مشتری',action:a.action||'',reason:a.reason||a.whyNow||'',urgency:a.urgency||'low',path:prospect?'/prospect?id='+encodeURIComponent(a.prospectId||''):'/customer?id='+encodeURIComponent(a.customerId||'')};
              });
              var watches = typeof getActiveWatchOccurrences==='function' ? (getActiveWatchOccurrences()||[]) : [];
              watches = watches.slice(0,3).map(function(w){
                var c=(source.customers||[]).find(function(x){return x.id===w.customerId;});
                var p=(source.products||[]).find(function(x){return x.id===w.productId;});
                var product=w.productName || (p&&p.name) || 'هشدار نیازمند بررسی';
                var reason=(w.generatedReason||w.reason||'یک نشانه در رفتار خرید نیازمند بررسی است.');
                return {id:String(w.id||''),name:(c&&c.name)||'مشتری',product:product,reason:reason,severity:w.severity||w.level||'medium'};
              });
              var invoices=(source.invoices||[]).slice().sort(function(a,b){return String(b.date||'').localeCompare(String(a.date||''))||String(b.number||'').localeCompare(String(a.number||''));}).slice(0,5).map(function(x){
                var c=(source.customers||[]).find(function(y){return y.id===x.customerId;});
                return {id:String(x.id||''),number:String(x.number||''),customer:(c&&c.name)||'مشتری حذف‌شده',date:dateLabel(x.date),total:Number(x.total)||0};
              });
              var visitRows=[];
              (source.customers||[]).forEach(function(c){(c.visits||[]).forEach(function(v){visitRows.push({customerId:String(c.id),name:c.name||'—',date:dateLabel(v.date),rawDate:String(v.date||''),result:v.result||''});});});
              visitRows.sort(function(a,b){return b.rawDate.localeCompare(a.rawDate);});
              var monthDays = (typeof jalaliMonthLength==='function' && metrics.jy && metrics.jm) ? jalaliMonthLength(metrics.jy,metrics.jm) : 30;
              var progress = target>0 ? Math.round((Number(metrics.mtdSales||0)/target)*100) : 0;
              return {
                today:{sales:todaySales,invoices:todayInvoices,visits:visits,received:received},
                month:{sales:Number(metrics.mtdSales)||0,profit:Number(metrics.mtdProfit)||0,count:Number(metrics.mtdCount)||0,target:Number(target)||0,progress:progress,delta:metrics.salesDeltaPct==null?null:Number(metrics.salesDeltaPct),day:Number(metrics.jd)||0,days:monthDays},
                totals:{customerDebt:Number(totals.customerDebt)||0,supplierDebt:Number(totals.supplierDebt)||0,stockValue:Number(stockValue)||0,customers:(source.customers||[]).length,products:(source.products||[]).length,checks:(source.checks||[]).length},
                actions:actions,watches:watches,invoices:invoices,visits:visitRows.slice(0,5),updatedAt:Date.now()
              };
            }, null);
          },
          getReportsSnapshot: function(period){
            return safe(function(){
              if (!g.ReportsView || typeof g.ReportsView.getSnapshot !== 'function') return null;
              return g.ReportsView.getSnapshot(period || 'month');
            }, null);
          },
          getCustomersSnapshot: function(){
            return safe(function(){
              var source = data || {};
              var ctx = typeof createComputationContext === 'function' ? createComputationContext({data:source}) : null;
              var priorities = typeof calculateAllCustomerPriorities === 'function' ? (calculateAllCustomerPriorities(ctx)||[]) : [];
              var priorityById = Object.create(null);
              priorities.forEach(function(p){ if(p && p.customerId) priorityById[p.customerId]=p; });
              var rows = (source.customers||[]).map(function(c){
                var totals = typeof customerTotals === 'function' ? customerTotals(c.id,ctx) : {balance:0,invTotal:0};
                var stats = typeof customerStats === 'function' ? customerStats(c.id,ctx) : {count:0,lastInvoiceDate:null,daysSinceLast:Infinity};
                var behavior = typeof customerBehavior === 'function' ? (customerBehavior(c.id,ctx)||{}) : {};
                var status = typeof customerStatus === 'function' ? customerStatus(c.id,ctx) : 'new';
                var priority = priorityById[c.id] || null;
                var riskLevel = priority ? priority.riskLevel || '' : '';
                var risk = typeof getRiskBadge === 'function' ? getRiskBadge(riskLevel) : {label:'',tone:''};
                var visits = Array.isArray(c.visits) ? c.visits.slice() : [];
                visits.sort(function(a,b){ return String(b.date||'').localeCompare(String(a.date||'')) || String(b.time||'').localeCompare(String(a.time||'')); });
                var lastVisit = visits[0] || null;
                var watchCount = typeof getActiveWatchOccurrences === 'function' ? (getActiveWatchOccurrences(c.id)||[]).length : 0;
                var badgeLabel = '';
                var badgeTone = 'neutral';
                if(c.active===false){ badgeLabel='غیرفعال شده'; badgeTone='muted'; }
                else if(c.oneOff){ badgeLabel='یک‌بار‌مصرف'; badgeTone='muted'; }
                else if(riskLevel==='critical' || riskLevel==='high'){ badgeLabel=risk.label||''; badgeTone=risk.tone||'neutral'; }
                else if(behavior.behindPattern===true){ badgeLabel='عقب‌افتاده'; badgeTone='warning'; }
                else if(status==='lost'){ badgeLabel='از دست رفته'; badgeTone='muted'; }
                else if(status==='inactive'){ badgeLabel='سرد شده'; badgeTone='muted'; }
                else if(status==='new'){ badgeLabel='جدید'; badgeTone='neutral'; }
                var days = Number(stats.daysSinceLast);
                return {
                  id:String(c.id||''), name:String(c.name||'مشتری'), phone:String(c.phone||''),
                  ownerName:String(c.ownerName||''), region:String(c.region||''), address:String(c.address||''),
                  active:c.active!==false, oneOff:!!c.oneOff, balance:Number(totals.balance)||0,
                  invoiceTotal:Number(totals.invTotal)||0, invoiceCount:Number(stats.count)||0,
                  lastPurchaseDate:stats.lastInvoiceDate ? dateLabel(stats.lastInvoiceDate) : '',
                  lastPurchaseRaw:String(stats.lastInvoiceDate||''),
                  daysSinceLast:Number.isFinite(days) ? days : null,
                  lastVisitDate:lastVisit && lastVisit.date ? dateLabel(lastVisit.date) : '',
                  lastVisitRaw:String(lastVisit && lastVisit.date || ''),
                  status:String(status||'new'), badgeLabel:badgeLabel, badgeTone:badgeTone,
                  priorityScore:priority ? Number(priority.priorityScore)||0 : 0,
                  riskLevel:riskLevel, watchCount:watchCount,
                  behindPattern:behavior.behindPattern===true
                };
              });
              return {customers:rows, updatedAt:Date.now()};
            }, null);
          },
          getInvoicesSnapshot: function(){
            return safe(function(){
              var source = data || {};
              var customers = source.customers || [];
              var rows = (source.invoices || []).map(function(inv,i){
                var paid = typeof invoiceEffectivePaid === 'function' ? Number(invoiceEffectivePaid(inv)) || 0 : (typeof invoiceOnRecordPaid === 'function' ? Number(invoiceOnRecordPaid(inv)) || 0 : 0);
                var remain = typeof invoiceEffectiveRemain === 'function' ? Number(invoiceEffectiveRemain(inv)) || 0 : Math.max(0, (Number(inv.total) || 0) - paid);
                var total = Number(inv.total) || 0;
                var status = total <= 0 || paid + 0.5 >= total ? 'paid' : 'debt';
                var statusLabel = total <= 0 ? '—' : paid <= 0 ? 'پرداخت‌نشده' : status === 'paid' ? 'تسویه روی فاکتور' : 'پرداخت جزئی';
                var customer = customers.find(function(c){ return c && String(c.id) === String(inv.customerId); });
                return {
                  id:String(inv.id || ('invoice-'+i)), number:String(inv.number || ''), customerId:String(inv.customerId || ''),
                  customer:String(customer && customer.name || '—'), buyerName:String(inv.buyerName || ''),
                  date:dateLabel(inv.date), rawDate:String(inv.date || ''), total:total, paid:paid, remain:remain,
                  status:status, statusLabel:statusLabel, itemsCount:Array.isArray(inv.items) ? inv.items.length : 0
                };
              });
              var paidCount = rows.filter(function(row){ return row.status === 'paid'; }).length;
              return {rows:rows,totalCount:rows.length,paidCount:paidCount,debtCount:rows.length-paidCount,updatedAt:Date.now()};
            }, null);
          },
          getPaymentsSnapshot: function(){
            return safe(function(){
              var source = data || {};
              var customers = source.customers || [];
              var invoices = source.invoices || [];
              var rows = [];
              (source.payments || []).forEach(function(p,i){
                if (!p) return;
                var customer = customers.find(function(c){ return c && String(c.id) === String(p.customerId); });
                var invoice = p.invoiceId ? invoices.find(function(inv){ return inv && String(inv.id) === String(p.invoiceId); }) : null;
                var method = String(p.method || '');
                var methodLabel = typeof paymentMethodLabel === 'function' ? paymentMethodLabel(method) : (method || 'تراکنش مشتری');
                rows.push({
                  id:String(p.id || ('payment-'+i)), kind:'customer',
                  date:dateLabel(p.date), rawDate:String(p.date || ''), amount:Number(p.amount) || 0,
                  method:method, methodLabel:String(methodLabel || '—'),
                  partyName:String(customer && customer.name || '—'), partyId:String(p.customerId || ''),
                  invoiceId:String(p.invoiceId || ''), invoiceNumber:String(invoice && invoice.number || ''),
                  note:String(p.note || ''), supplierStatus:'', checkNumber:''
                });
              });
              (source.suppliers || []).forEach(function(s){
                (s && s.payments || []).forEach(function(p,i){
                  if (!p) return;
                  var isCheck = p.method === 'check';
                  var statusLabel = p.status === 'cleared' ? 'پرداخت‌شده' : (p.status === 'bounced' ? 'برگشتی' : 'در جریان');
                  var methodLabel = isCheck ? ('چک به تأمین‌کننده · ' + statusLabel) : 'پرداخت نقدی به تأمین‌کننده';
                  rows.push({
                    id:'suppay-' + String(s.id || '') + '-' + i, kind:'supplier',
                    date:dateLabel(p.date), rawDate:String(p.date || ''), amount:Number(p.amount) || 0,
                    method:'supplier', methodLabel:methodLabel,
                    partyName:String(s.name || '—'), partyId:String(s.id || ''),
                    invoiceId:'', invoiceNumber:'', note:String(p.note || p.desc || ''),
                    supplierStatus:String(p.status || ''), checkNumber:String(p.checkNumber || '')
                  });
                });
              });
              return {rows:rows, updatedAt:Date.now()};
            }, null);
          },
          getInvoiceDetailSnapshot: function(invId){
            return safe(function(){
              var source = data || {};
              var inv = (source.invoices || []).find(function(x){ return x && String(x.id) === String(invId); });
              if (!inv) return {found:false,invoiceId:String(invId || ''),updatedAt:Date.now()};
              var customer = (source.customers || []).find(function(x){ return x && String(x.id) === String(inv.customerId); }) || null;
              var paid = typeof invoiceEffectivePaid === 'function' ? Number(invoiceEffectivePaid(inv)) || 0 : (typeof invoiceOnRecordPaid === 'function' ? Number(invoiceOnRecordPaid(inv)) || 0 : 0);
              var remain = typeof invoiceEffectiveRemain === 'function' ? Number(invoiceEffectiveRemain(inv)) || 0 : Math.max(0,(Number(inv.total)||0)-paid);
              var total = Number(inv.total) || 0;
              var statusKey = total <= 0 || paid + 0.5 >= total ? 'paid' : 'debt';
              var statusLabel = total <= 0 ? '—' : paid <= 0 ? 'پرداخت‌نشده' : statusKey === 'paid' ? 'تسویه روی فاکتور' : 'پرداخت جزئی';
              var ctx = typeof createComputationContext === 'function' ? createComputationContext({data:source}) : null;
              var currentBalance = customer && typeof customerTotals === 'function' ? safe(function(){ return Number(customerTotals(customer.id,ctx).balance) || 0; },null) : null;
              var products = source.products || [];
              var items = (inv.items || []).map(function(it,i){
                var product = products.find(function(p){ return p && String(p.id) === String(it.productId); });
                var qty = Number(it.qty) || 0;
                var price = Number(it.price) || 0;
                var discount = Number(it.discount) || 0;
                return {id:String(it.id || (inv.id+'-item-'+i)),productId:String(it.productId || ''),name:String(it.name || (product && product.name) || 'کالای نامشخص'),qty:qty,unit:product && product.packageWeight ? ('بسته '+product.packageWeight) : 'عدد',price:price,discount:discount,lineTotal:qty*price-discount};
              });
              var invItemsProfit = (inv.items || []).reduce(function(sum,it){ return sum + ((Number(it.price)||0)-(Number(it.buyPrice)||0))*(Number(it.qty)||0)-(Number(it.discount)||0); },0);
              var invoiceDiscount = typeof invoiceDiscountAmount === 'function' ? Number(invoiceDiscountAmount(inv)) || 0 : 0;
              var trace = typeof invoiceAllocationTrace === 'function' ? safe(function(){ return invoiceAllocationTrace(inv.id); },null) : null;
              var allocation = trace ? {
                onRecord:Number(trace.onRecord)||0,
                linkedEventObservedTotal:Number(trace.linkedEventObservedTotal)||0,
                legacyOnInvoice:Number(trace.legacyOnInvoice)||0,
                incoming:(trace.incoming||[]).map(function(x){ return {kind:String(x.kind||''),eventId:String(x.eventId||''),date:String(x.date||''),dateLabel:dateLabel(x.date),amount:Number(x.amount)||0,path:String(x.path||''),fromInvoiceId:String(x.fromInvoiceId||''),fromInvoiceNumber:String(x.fromInvoiceNumber||'')}; }),
                incomingTotal:Number(trace.incomingTotal)||0,
                incomingLinkedTotal:Number(trace.incomingLinkedTotal)||0,
                incomingLinkedReturnTotal:Number(trace.incomingLinkedReturnTotal)||0,
                outgoing:(trace.outgoing||[]).map(function(x){ return {kind:String(x.kind||''),eventId:String(x.eventId||''),date:String(x.date||''),dateLabel:dateLabel(x.date),amount:Number(x.amount)||0,destinations:(x.destinations||[]).map(function(d){ return {type:String(d.type||''),invoiceId:String(d.invoiceId||''),invoiceNumber:String(d.invoiceNumber||''),amount:Number(d.amount)||0}; })}; }),
                outgoingTotal:Number(trace.outgoingTotal)||0,
                effectivePaid:Number(trace.effectivePaid)||0,
                remain:Number(trace.remain)||0
              } : null;
              var visits = customer && Array.isArray(customer.visits) ? customer.visits.slice() : [];
              visits.sort(function(a,b){ return String(b.date||'').localeCompare(String(a.date||'')) || String(b.time||'').localeCompare(String(a.time||'')); });
              var linkedVisit = inv.visitId ? visits.find(function(v){ return String(v.id) === String(inv.visitId); }) : null;
              var visitOptions = visits.map(function(v){
                var label = dateLabel(v.date) + (v.time ? ' '+String(v.time) : '') + (v.result ? ' · '+String(v.result) : '');
                return {id:String(v.id||''),label:label};
              }).filter(function(v){ return !!v.id; });
              var history = (inv.editHistory || []).slice().reverse().map(function(h,i){
                return {id:String(h.id || (inv.id+'-edit-'+i)),editedAt:(h.editedAt ? dateLabel(String(h.editedAt).slice(0,10)) + (String(h.editedAt).length > 10 ? ' · ' + String(h.editedAt).slice(11,16) : '') : ''),beforeTotal:h.before && typeof h.before.total === 'number' ? Number(h.before.total) : null,afterTotal:h.after && typeof h.after.total === 'number' ? Number(h.after.total) : null,note:String(h.note || '')};
              });
              return {
                found:true,invoiceId:String(inv.id),updatedAt:Date.now(),
                invoice:{id:String(inv.id),number:String(inv.number||''),customerId:String(inv.customerId||''),buyerName:String(inv.buyerName||''),date:dateLabel(inv.date),total:total,discount:Number(inv.discount)||0,discountType:String(inv.discountType||'fixed'),discountAmount:invoiceDiscount,cashPaid:Number(inv.cashPaid)||0,cardPaid:Number(inv.cardPaid)||0,transferPaid:Number(inv.transferPaid)||0,checkPaid:Number(inv.checkPaid)||0,prevBalance:typeof inv.prevBalance==='number'?Number(inv.prevBalance):null,newBalance:typeof inv.newBalance==='number'?Number(inv.newBalance):null,visitId:String(inv.visitId||'')},
                customer:customer?{id:String(customer.id),name:String(customer.name||'مشتری'),phone:String(customer.phone||'')}:null,
                status:{key:statusKey,label:statusLabel},
                financial:{paid:paid,remain:remain,currentCustomerBalance:currentBalance,profit:invItemsProfit-invoiceDiscount},
                items:items,allocation:allocation,
                visit:{linkedId:String(inv.visitId||''),linkedLabel:linkedVisit ? (dateLabel(linkedVisit.date)+(linkedVisit.time?' '+String(linkedVisit.time):'')+(linkedVisit.result?' · '+String(linkedVisit.result):'')) : (inv.visitId?'ویزیت مرتبط (شناسه ثبت‌شده)':''),options:visitOptions},
                editHistory:history
              };
            }, null);
          },
          getCustomerDetailSnapshot: function(cid){
            return safe(function(){
              var source = data || {};
              var customer = (source.customers || []).find(function(x){ return x && String(x.id) === String(cid); });
              if (!customer) return {found:false,customerId:String(cid || ''),updatedAt:Date.now()};
              var ctx = typeof createComputationContext === 'function' ? createComputationContext({data:source}) : null;
              var totals = typeof customerTotals === 'function' ? customerTotals(customer.id,ctx) : {balance:0,invTotal:0,payTotal:0,checkTotal:0,openingBalance:0};
              var stats = typeof customerStats === 'function' ? customerStats(customer.id,ctx) : {count:0,lastInvoiceDate:null,daysSinceLast:null};
              var behavior = typeof customerBehavior === 'function' ? (customerBehavior(customer.id,ctx) || {}) : {};
              var profit = typeof customerProfit === 'function' ? customerProfit(customer.id,ctx) : Number(stats.profit) || 0;
              var priority = null;
              var action = null;
              if (!customer.oneOff && typeof calculateCustomerPriority === 'function') {
                priority = safe(function(){ return calculateCustomerPriority(customer.id,{ctx:ctx}); },null);
                if (typeof calculateCustomerAction === 'function') action = safe(function(){ return calculateCustomerAction(customer.id,priority,{ctx:ctx}); },null);
              }
              var visitSummary = typeof buildCustomerVisitSummary === 'function' ? safe(function(){ return buildCustomerVisitSummary(customer.id,ctx); },{}) : {};
              var badge = priority && typeof getRiskBadge === 'function' ? safe(function(){ return getRiskBadge(priority.riskLevel); },{}) : {};
              var location = customer.locationId && typeof getLocationDisplayString === 'function' ? safe(function(){ return getLocationDisplayString(customer.locationId); },'') : '';
              var productName = function(pid){ var p=(source.products||[]).find(function(x){ return x && String(x.id)===String(pid); }); return p ? p.name : String(pid || ''); };
              var invoices = typeof customerInvoices === 'function' ? (customerInvoices(customer.id,ctx)||[]).slice() : [];
              invoices.sort(function(a,b){ return String(b.date||'').localeCompare(String(a.date||'')) || String(b.number||'').localeCompare(String(a.number||'')); });
              invoices = invoices.map(function(inv,i){
                var paid = typeof invoiceEffectivePaid === 'function' ? Number(invoiceEffectivePaid(inv)) || 0 : null;
                var status = paid === null ? '' : (Number(inv.total) <= 0 ? '—' : paid <= 0 ? 'پرداخت‌نشده' : paid + 0.5 >= Number(inv.total) ? 'تسویه روی فاکتور' : 'پرداخت جزئی');
                return {id:String(inv.id||('invoice-'+i)),number:String(inv.number||''),date:dateLabel(inv.date),total:Number(inv.total)||0,status:status};
              });
              var payments = typeof customerPayments === 'function' ? (customerPayments(customer.id,ctx)||[]).slice() : [];
              payments.sort(function(a,b){ return String(b.date||'').localeCompare(String(a.date||'')); });
              payments = payments.map(function(p,i){ return {id:String(p.id||('payment-'+i)),date:dateLabel(p.date),amount:Number(p.amount)||0,method:typeof paymentMethodLabel==='function'?paymentMethodLabel(p.method):String(p.method||'دریافت'),note:String(p.note||''),invoiceId:String(p.invoiceId||'')}; });
              var checks = typeof customerChecks === 'function' ? (customerChecks(customer.id,ctx)||[]).slice() : [];
              checks.sort(function(a,b){ return String(b.dueDate||'').localeCompare(String(a.dueDate||'')); });
              checks = checks.map(function(ch,i){ var st=ch.status==='cleared'?'پاس‌شده':ch.status==='bounced'?'برگشتی':'در جریان'; return {id:String(ch.id||('check-'+i)),number:String(ch.checkNumber||'چک'),dueDate:dateLabel(ch.dueDate),amount:Number(ch.amount)||0,status:st,invoiceId:String(ch.invoiceId||'')}; });
              var visits = (customer.visits || []).slice();
              visits.sort(function(a,b){ return String(b.date||'').localeCompare(String(a.date||'')) || String(b.time||'').localeCompare(String(a.time||'')); });
              visits = visits.slice(0,50).map(function(v,i){
                var offered=(v.offeredProducts||[]).map(function(op){ var n=productName(op.productId); return n + (op.reaction==='rejected'?' (رد شده)':op.reaction==='deferred'?' (موکول شده)':op.reaction==='accepted'?' (پذیرفته شده)':''); });
                return {id:String(v.id||customer.id+'-visit-'+i),date:dateLabel(v.date),time:String(v.time||''),result:String(v.result||'ویزیت'),score:typeof v.score==='number'?v.score:null,ordered:!!(v.ordered || v.result==='سفارش'),nextAction:String(v.nextAction||''),note:String(v.note||''),offeredProducts:offered};
              });
              var watches = typeof getActiveWatchOccurrences === 'function' ? safe(function(){ return getActiveWatchOccurrences(customer.id)||[]; },[]) : [];
              watches = watches.map(function(w,i){ return {id:String(w.id||customer.id+'-watch-'+i),product:String(w.productName||productName(w.productId)||'موضوع نیازمند بررسی'),reason:String(w.generatedReason||w.reason||'برای بررسی بیشتر ثبت شده است'),severity:String(w.severity||w.level||'medium')}; });
              var followUps = customer.active === false ? [] : (typeof getPendingWatchFollowUps === 'function' ? safe(function(){ return getPendingWatchFollowUps(customer.id)||[]; },[]) : []);
              followUps = followUps.map(function(o,i){
                var P = g.BagheriPresent || {};
                return {id:String(o.id||customer.id+'-followup-'+i),product:String(o.productName||productName(o.productId)||'موضوع پیگیری'),text:String(typeof P.watchSentence==='function'?P.watchSentence(o):(o.generatedReason||'')),note:String(o.reason&&o.reason.comment||'')};
              });
              var topNames = Array.isArray(behavior.topProducts) ? behavior.topProducts.slice(0,5).map(function(x){ return String(x && (x.name||x.productName) || x || ''); }).filter(Boolean) : [];
              var decliningNames = Array.isArray(behavior.decliningProducts) ? behavior.decliningProducts.slice(0,5).map(function(x){ return String(x && (x.name||x.productName) || x || ''); }).filter(Boolean) : [];
              var lastVisit = visits[0] || null;
              var lastPurchase = visitSummary.lastPurchase || null;
              return {
                found:true,customerId:String(customer.id),
                customer:{id:String(customer.id),name:String(customer.name||'مشتری'),phone:String(customer.phone||''),ownerName:String(customer.ownerName||''),region:String(customer.region||''),route:String(customer.route||''),address:String(customer.address||''),note:String(customer.note||''),active:customer.active!==false,oneOff:!!customer.oneOff,status:String(typeof customerStatus==='function'?customerStatus(customer.id,ctx):'new'),location:String(location||'')},
                financial:{balance:Number(totals.balance)||0,invTotal:Number(totals.invTotal)||0,payTotal:Number(totals.payTotal)||0,checkTotal:Number(totals.checkTotal)||0,openingBalance:Number(totals.openingBalance)||0,profit:Number(profit)||0,invoiceCount:invoices.length,paymentCount:payments.length,checkCount:checks.length},
                purchase:{lastPurchase:lastPurchase?{date:dateLabel(lastPurchase.date),amount:Number(lastPurchase.amount)||0,invoiceNumber:String(lastPurchase.invoiceNumber||''),daysSince:lastPurchase.daysSince==null?null:Number(lastPurchase.daysSince)}:null,timing:visitSummary.purchaseTiming||null,suggestedProducts:(visitSummary.suggestedProducts||[]).map(function(x){return {productId:String(x.productId||''),name:String(x.name||''),reasonText:String(x.reasonText||''),lastPurchaseText:String(x.lastPurchaseText||'')};}),productsToCheck:(visitSummary.productsToCheck||[]).map(function(x){return {productId:String(x.productId||''),name:String(x.name||''),kind:String(x.kind||''),detail:String(x.detail||'')};})},
                priority:{riskLevel:String(priority&&priority.riskLevel||''),healthLabel:String(badge&&badge.label|| (customer.oneOff?'مشتری یک‌بارمصرف':'وضعیت عادی')),story:String(priority&&priority.customerStory&&priority.customerStory.summary||''),action:action&&action.actionType!=='no_action'?{actionType:String(action.actionType||''),action:String(action.action||''),reason:String(action.reason||action.whyNow||''),urgency:String(action.urgency||'low')}:null},
                alert:visitSummary.priorityAlert||null,watches:watches,followUps:followUps,invoices:invoices,payments:payments,checks:checks,visits:visits,
                behavior:{behindPattern:typeof behavior.behindPattern==='boolean'?behavior.behindPattern:null,daysSinceLast:behavior.daysSinceLast!=null && Number.isFinite(Number(behavior.daysSinceLast))?Number(behavior.daysSinceLast):null,avgIntervalDays:behavior.avgDistinctIntervalDays!=null && Number.isFinite(Number(behavior.avgDistinctIntervalDays))?Number(behavior.avgDistinctIntervalDays):behavior.avgIntervalDays!=null && Number.isFinite(Number(behavior.avgIntervalDays))?Number(behavior.avgIntervalDays):null,amountTrend:String(behavior.amountTrend||''),topProducts:topNames,decliningProducts:decliningNames,consecutiveNoOrder:Number(behavior.consecutiveNoOrder)||0,conversionRate:behavior.conversionRate==null?null:Number(behavior.conversionRate),visitCount:Number(behavior.visitCount)||visits.length,lastNextAction:String(behavior.lastNextAction||''),purchaseDayCount:Number(behavior.purchaseDayCount)||0},
                lastVisitDate:lastVisit?lastVisit.date:'',updatedAt:Date.now()
              };
            }, null);
          },
          runCustomerAction: function(action,cid){
            var names = {invoice:'openAddInvoice',payment:'openAddTransaction',visit:'openAddVisit',check:'openAddCheck',edit:'openAddCustomer',statement:'printCustomerStatement'};
            var fn = names[action] ? g[names[action]] : null;
            if (typeof fn !== 'function') return false;
            try { fn.call(g,cid); return true; } catch(e) { return false; }
          },
          runInvoiceAction: function(action,invId,visitId){
            try {
              var current = new URLSearchParams(String(g.location.hash || '').split('?')[1] || '').get('id');
              if (String(current || '') !== String(invId || '')) return false;
              var main = g.document.getElementById('main');
              if (!main) return false;
              if (action === 'link-visit') {
                var select = main.querySelector('#inv-link-visit');
                if (!select || !visitId) return false;
                select.value = String(visitId);
              }
              var button = main.querySelector('[data-inv-action="'+String(action).replace(/[^a-z-]/g,'')+'"]');
              if (!button) return false;
              button.click();
              return true;
            } catch(e) { return false; }
          }
        };
      })(window);
    `;
    if (!childDocument.querySelector('script[data-bagheri-dashboard-bridge]')) childDocument.body.appendChild(bridgeScript);

    const frameWindow = frame.contentWindow as (Window & {
      AppRouter?: { navigate?: (path: string, query?: Record<string, string>) => void };
      BaqeriTheme?: { setPreference?: (value: ThemePreference) => void };
    }) | null;
    try {
      frameWindow?.BaqeriTheme?.setPreference?.(preference);
    } catch {
      // Theme can still be controlled from the shell later.
    }

    if (initialNavigation.current) {
      const externalPath = routeFromHash(window.location.hash);
      if (externalPath !== '/dashboard' && ROUTE_NAMES[externalPath]) {
        try {
          const externalQuery = Object.fromEntries(new URLSearchParams(window.location.hash.includes('?') ? window.location.hash.slice(window.location.hash.indexOf('?') + 1) : '').entries());
          if (frameWindow?.AppRouter?.navigate) frameWindow.AppRouter.navigate(externalPath, externalQuery);
          else if (frameWindow) frameWindow.location.hash = window.location.hash || `#${externalPath}`;
        } catch {
          // Continue with the iframe's established dashboard route.
        }
      }
      initialNavigation.current = false;
    }
    const childHash = frameWindow?.location.hash || '#/dashboard';
    const nextRoute = routeFromHash(childHash);
    setRoute(ROUTE_NAMES[nextRoute] ? nextRoute : '/dashboard');
    syncHostHash(childHash);
    setFrameError(false);
    setLoaded(true);
    [300, 1200, 3000].forEach((delay) => window.setTimeout(() => {
      try {
        const child = frameRef.current?.contentWindow as (Window & { __BAGHERI_DASHBOARD_BRIDGE__?: { getSnapshot?: () => DashboardSnapshot | null; getCustomersSnapshot?: () => CustomersSnapshot | null; getCustomerDetailSnapshot?: (id: string) => CustomerDetailSnapshot | null; getInvoicesSnapshot?: () => InvoicesSnapshot | null; getInvoiceDetailSnapshot?: (id: string) => InvoiceDetailSnapshot | null } }) | undefined;
        const next = child?.__BAGHERI_DASHBOARD_BRIDGE__?.getSnapshot?.();
        const customers = child?.__BAGHERI_DASHBOARD_BRIDGE__?.getCustomersSnapshot?.();
        const invoices = child?.__BAGHERI_DASHBOARD_BRIDGE__?.getInvoicesSnapshot?.();
        const invoiceDetailId = queryFromHash(child?.location.hash || window.location.hash, 'id');
        const invoiceDetail = routeFromHash(child?.location.hash || window.location.hash) === '/invoice' && invoiceDetailId ? child?.__BAGHERI_DASHBOARD_BRIDGE__?.getInvoiceDetailSnapshot?.(invoiceDetailId) : null;
        const detailId = queryFromHash(child?.location.hash || window.location.hash, 'id');
        const detail = detailId ? child?.__BAGHERI_DASHBOARD_BRIDGE__?.getCustomerDetailSnapshot?.(detailId) : null;
        if (next) setDashboardSnapshot(next);
        if (customers) setCustomersSnapshot(customers);
        if (invoices) setInvoicesSnapshot(invoices);
        if (invoiceDetail) { setInvoiceDetailSnapshot(invoiceDetail); setInvoiceDetailSnapshotId(invoiceDetailId); }
        if (detail) { setCustomerDetailSnapshot(detail); setCustomerDetailSnapshotId(detailId); }
      } catch { /* data engine may not be ready yet */ }
    }, delay));
  }, [preference, syncHostHash]);

  const retryFrame = useCallback(() => {
    setFrameError(false);
    setLoaded(false);
    setPrimaryAction(false);
    testIdObserver.current?.disconnect();
    fabObserver.current?.disconnect();
    modalObserver.current?.disconnect();
    const frame = frameRef.current;
    if (frame) frame.src = LEGACY_URL;
  }, []);

  useEffect(() => {
    document.documentElement.lang = 'fa';
    document.documentElement.dir = 'rtl';
    document.documentElement.classList.toggle('dark', resolvedTheme === 'dark');
    setThemeColor(resolvedTheme);
    document.title = `${title} — حبوبات و خشکبار باقری`;
    const onOnline = () => setOnline(true);
    const onOffline = () => setOnline(false);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);

    const media = window.matchMedia?.('(prefers-color-scheme: dark)');
    const onSystemTheme = () => {
      if (preferenceFromStorage() === 'system') {
        const next = resolveTheme('system');
        setResolvedTheme(next);
        document.documentElement.classList.toggle('dark', next === 'dark');
        setThemeColor(next);
        try {
          const child = frameRef.current?.contentDocument?.documentElement;
          if (child) child.setAttribute('data-theme', next);
        } catch {
          // Ignore until the frame is ready.
        }
      }
    };
    media?.addEventListener?.('change', onSystemTheme);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
      media?.removeEventListener?.('change', onSystemTheme);
    };
  }, [resolvedTheme, preference, title]);

  useEffect(() => {
    const frame = frameRef.current;
    const childWindow = frame?.contentWindow;
    if (!childWindow) return;
    const onChildHash = () => {
      const nextHash = childWindow.location.hash || '#/dashboard';
      const nextRoute = routeFromHash(nextHash);
      if (ROUTE_NAMES[nextRoute]) {
        setRoute(nextRoute);
        if (nextRoute !== '/customers') setShowLegacyCustomers(false);
        syncHostHash(nextHash);
        if (nextRoute === '/invoice') window.setTimeout(refreshInvoiceDetail, 0);
        window.setTimeout(() => checkLegacyFab.current(), 0);
      }
    };
    childWindow.addEventListener('hashchange', onChildHash);
    childWindow.addEventListener('popstate', onChildHash);
    let mutation: MutationObserver | undefined;
    try {
      const root = frame?.contentDocument?.documentElement;
      if (root) {
        mutation = new MutationObserver(() => {
          const childPreference = preferenceFromStorage();
          const childTheme = root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
          setPreference(childPreference);
          setResolvedTheme(childTheme);
          document.documentElement.classList.toggle('dark', childTheme === 'dark');
        });
        mutation.observe(root, { attributes: true, attributeFilter: ['data-theme'] });
      }
    } catch {
      // Same-origin access is expected; UI still functions if browser blocks it.
    }
    return () => {
      childWindow.removeEventListener('hashchange', onChildHash);
      childWindow.removeEventListener('popstate', onChildHash);
      mutation?.disconnect();
    };
  }, [loaded, syncHostHash, refreshInvoiceDetail]);

  useEffect(() => {
    const onOuterNavigation = () => {
      if (!window.location.hash) return;
      const path = routeFromHash(window.location.hash);
      if (ROUTE_NAMES[path] && path !== route) navigateLegacy(path);
    };
    window.addEventListener('popstate', onOuterNavigation);
    window.addEventListener('hashchange', onOuterNavigation);
    return () => {
      window.removeEventListener('popstate', onOuterNavigation);
      window.removeEventListener('hashchange', onOuterNavigation);
    };
  }, [navigateLegacy, route]);

  useEffect(() => {
    if (!loaded) return;
    refreshDashboard();
    refreshCustomers();
    if (route === '/customer') refreshCustomerDetail();
    if (route === '/invoices') refreshInvoices();
    if (route === '/reports') refreshReports(reportsPeriod);
    if (route === '/payments') refreshPayments();
    if (route === '/invoice') refreshInvoiceDetail();
    const timer = window.setInterval(() => {
      refreshDashboard();
      refreshCustomers();
      if (route === '/customer') refreshCustomerDetail();
      if (route === '/invoices') refreshInvoices();
      if (route === '/reports') refreshReports(reportsPeriod);
      if (route === '/payments') refreshPayments();
      if (route === '/invoice') refreshInvoiceDetail();
    }, 15000);
    return () => window.clearInterval(timer);
  }, [loaded, route, refreshDashboard, refreshCustomers, refreshCustomerDetail, refreshInvoices, refreshReports, reportsPeriod, refreshPayments, refreshInvoiceDetail]);

  const onThemeToggle = () => {
    applyTheme(resolvedTheme === 'dark' ? 'light' : 'dark');
    showToast(resolvedTheme === 'dark' ? 'حالت روشن فعال شد' : 'حالت تیره فعال شد');
  };

  const onBack = () => {
    const child = frameRef.current?.contentWindow;
    try {
      if (child && child.history.length > 1) child.history.back();
      else navigateLegacy('/dashboard');
    } catch {
      navigateLegacy('/dashboard');
    }
  };

  const onPrimaryAction = () => {
    try {
      const frame = frameRef.current;
      const childDocument = frame?.contentDocument;
      const legacyFab = childDocument?.getElementById('fab') as HTMLButtonElement | null;
      if (!legacyFab || typeof legacyFab.onclick !== 'function') {
        showToast('این صفحه اقدام افزودن ندارد');
        return;
      }
      if (useNewInvoices || useNewPayments) {
        hostActionPending.current = true;
        hostActionModalSeen.current = false;
        childDocument?.body.classList.add('host-action-mode');
        setLegacyActionOpen(true);
        legacyFab.click();
        window.setTimeout(() => {
          if (hostActionPending.current && !hostActionModalSeen.current) {
            hostActionPending.current = false;
            childDocument?.body.classList.remove('host-action-mode');
            setLegacyActionOpen(false);
          }
        }, 1800);
      } else legacyFab.click();
    } catch {
      showToast('اقدام اصلی در دسترس نیست');
    }
  };

  return (
    <div className="app-frame" dir="rtl">
      <header className="app-header">
        <div className="brand-mark" aria-hidden="true" />
        <div className="brand-copy">
          <p className="brand-name" data-testid="text-brand-name">باقری</p>
          <p className="brand-caption">حبوبات و خشکبار · دفتر کار روزانه</p>
        </div>
        <span className="header-divider" aria-hidden="true" />
        {!primary && (
          <button
            className="icon-control"
            type="button"
            aria-label="بازگشت به صفحه قبل"
            onClick={onBack}
            data-testid="button-back"
          >
            <ArrowRight size={19} />
          </button>
        )}
        <div className="route-heading" aria-live="polite">
          <strong data-testid="text-current-route">{title}</strong>
          <span>فضای کاری باقری</span>
        </div>
        <div className="header-actions">
          {primaryAction && route !== '/dashboard' && (!useNewCustomers) && (!useNewCustomerDetail) && (!useNewInvoiceDetail) && (!useNewReports) && (
            <button
              className="primary-action"
              type="button"
              onClick={onPrimaryAction}
              aria-label={`اقدام اصلی در بخش ${title}`}
              data-testid="button-primary-action"
            >
              <Plus size={17} aria-hidden="true" />
              <span>{useNewPayments ? 'ثبت دریافت' : 'افزودن'}</span>
            </button>
          )}
          <span className={`connection-state${online ? '' : ' is-offline'}`} data-testid="status-connectivity">
            <span className="connection-dot" />
            {online ? 'آماده · داده محلی' : 'آفلاین · ذخیره محلی'}
          </span>
          <button
            className="icon-control"
            type="button"
            onClick={onThemeToggle}
            aria-label={resolvedTheme === 'dark' ? 'تغییر به حالت روشن' : 'تغییر به حالت تیره'}
            title={preference === 'system' ? 'ظاهر: هماهنگ با دستگاه' : 'تغییر ظاهر'}
            data-testid="button-theme"
          >
            {resolvedTheme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>
        </div>
      </header>

      <main className="workspace">
        <section className="workspace-inner" aria-label="فضای کاری باقری">
          {route !== '/dashboard' && !useNewCustomers && !useNewCustomerDetail && !useNewInvoices && !useNewInvoiceDetail && !useNewReports && !useNewPayments && route !== '/customers' && <div className="frame-heading">
            <strong>{title}</strong>
            <span className="sync-note"><ShieldCheck size={14} /> داده‌ها روی همین دستگاه نگهداری می‌شوند</span>
          </div>}
          {route === '/dashboard' && <Dashboard snapshot={dashboardSnapshot} onNavigate={navigateLegacy} onRefresh={refreshDashboard} />}
          {useNewCustomers && <Customers snapshot={customersSnapshot} onNavigate={navigateLegacy} onAddCustomer={openLegacyCustomerCreator} initialBalanceFilter={new URLSearchParams((window.location.hash.split('?')[1] || '')).get('filter') === 'debt' ? 'debt' : 'all'} />}
          {useNewCustomerDetail && <CustomerDetail snapshot={visibleCustomerDetail} onAction={runCustomerAction} onNavigate={navigateLegacy} onBackToCustomers={() => navigateLegacy('/customers')} />}
          {useNewInvoices && <Invoices snapshot={invoicesSnapshot} onNavigate={navigateLegacy} />}
          {useNewReports && <Reports snapshot={reportsSnapshot} period={reportsPeriod} onPeriodChange={changeReportsPeriod} onRefresh={() => refreshReports(reportsPeriod)} onNavigate={navigateLegacy} />}
          {useNewPayments && <Payments snapshot={paymentsSnapshot} onNavigate={navigateLegacy} />}
          {useNewInvoiceDetail && <InvoiceDetail key={currentInvoiceId} snapshot={visibleInvoiceDetail} onAction={runInvoiceAction} onNavigate={navigateLegacy} onBack={() => navigateLegacy('/invoices')} />}
          {route === '/customers' && showLegacyCustomers && <div className="legacy-fallback-return"><span>فرم ثبت مشتری در نسخه اصلی</span><button type="button" onClick={returnToNewCustomers}>بازگشت به فهرست جدید</button></div>}
          <iframe
            ref={frameRef}
            className={legacyActionOpen ? 'legacy-frame legacy-frame-action' : `legacy-frame${hideLegacyFrame ? ' legacy-frame-hidden' : ''}`}
            title="سامانه مدیریت حبوبات و خشکبار باقری"
            src={LEGACY_URL}
            onLoad={handleFrameLoad}
            onError={() => { setFrameError(true); setLoaded(false); setPrimaryAction(false); }}
            data-testid="frame-legacy-crm"
            allow="clipboard-read; clipboard-write"
          />
          {!loaded && !frameError && (
            <div className="loading-cover" role="status" aria-live="polite" data-testid="status-loading">
              <div className="loading-card">
                <Wifi size={22} color="hsl(var(--primary))" />
                <p>در حال آماده‌سازی دفتر کار…</p>
                <div className="loading-lines" aria-hidden="true">
                  <span className="skeleton" />
                  <span className="skeleton" />
                  <span className="skeleton" />
                </div>
              </div>
            </div>
          )}
          {frameError && (
            <div className="error-cover" role="alert" data-testid="status-frame-error">
              <div className="error-card">
                <h2>دفتر کار باز نشد</h2>
                <p>ارتباط با نسخهٔ محلی برنامه برقرار نشد. اطلاعات ذخیره‌شده تغییری نکرده است؛ دوباره تلاش کنید.</p>
                <button className="retry-button" type="button" onClick={retryFrame} data-testid="button-retry-frame">
                  <RotateCw size={15} style={{ verticalAlign: 'middle', marginInlineEnd: 6 }} />
                  تلاش دوباره
                </button>
              </div>
            </div>
          )}
        </section>
      </main>

      <nav className="bottom-tabs" aria-label="بخش‌های اصلی">
        {TABS.map(({ path, label, icon: Icon }) => {
          const isCurrent = activeTab === path;
          return (
            <button
              key={path}
              type="button"
              className="tab-button"
              aria-current={isCurrent ? 'page' : undefined}
              aria-label={label}
              onClick={() => navigateLegacy(path)}
              data-testid={`tab-${path.slice(1)}`}
            >
              <Icon aria-hidden="true" />
              <span>{label}</span>
            </button>
          );
        })}
      </nav>
      {toast && <div className="shell-toast" role="status" data-testid="status-toast">{toast}</div>}
    </div>
  );
}

export default App;
