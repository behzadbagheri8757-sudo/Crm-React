import { useMemo, useState, type ChangeEvent } from 'react';
import {
  ArrowLeft,
  ArrowLeftRight,
  ArrowUpDown,
  BadgePercent,
  Banknote,
  Building2,
  CalendarDays,
  CreditCard,
  Landmark,
  RefreshCw,
  Search,
  Wallet,
  X,
} from 'lucide-react';

export type PaymentRow = {
  id: string;
  kind: 'customer' | 'supplier';
  date: string;
  rawDate: string;
  amount: number;
  method: string;
  methodLabel: string;
  partyName: string;
  partyId: string;
  invoiceId: string;
  invoiceNumber: string;
  note: string;
  supplierStatus: string;
  checkNumber: string;
};

export type PaymentsSnapshot = {
  rows: PaymentRow[];
  updatedAt: number;
};

export type PaymentFilter = 'all' | 'cash' | 'card' | 'transfer' | 'return' | 'discount' | 'supplier';
export type PaymentSort = 'newest' | 'oldest' | 'amountDesc' | 'amountAsc';

type Direction = 'received' | 'return' | 'discount' | 'supplier' | 'other';

const FILTERS: Array<{ value: PaymentFilter; label: string }> = [
  { value: 'all', label: 'همه' },
  { value: 'cash', label: 'نقد' },
  { value: 'card', label: 'کارت' },
  { value: 'transfer', label: 'انتقال' },
  { value: 'return', label: 'برگشت' },
  { value: 'discount', label: 'تخفیف' },
  { value: 'supplier', label: 'تأمین‌کننده' },
];

const fa = (value: number) => new Intl.NumberFormat('fa-IR').format(Math.round(Number(value) || 0));
const money = (value: number) => `${fa(value)} تومان`;
const compact = (value: number) => {
  const amount = Number(value) || 0;
  const abs = Math.abs(amount);
  if (abs >= 1_000_000_000) return `${(amount / 1_000_000_000).toFixed(1).replace(/\.0$/, '')} میلیارد`;
  if (abs >= 1_000_000) return `${(amount / 1_000_000).toFixed(1).replace(/\.0$/, '')} میلیون`;
  return money(amount);
};

export function normalizePaymentSearch(value: string) {
  return value.toLocaleLowerCase('fa')
    .replace(/[۰-۹]/g, (digit) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)))
    .replace(/[٠-٩]/g, (digit) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)))
    .trim();
}

export function directionOf(row: PaymentRow): Direction {
  if (row.kind === 'supplier') return 'supplier';
  if (row.method === 'return') return 'return';
  if (row.method === 'discount') return 'discount';
  if (['cash', 'card', 'transfer'].includes(row.method)) return 'received';
  return 'other';
}

export function summarizePaymentRows(rows: PaymentRow[]) {
  return {
    received: rows.filter((row) => row.kind === 'customer' && ['cash', 'card', 'transfer'].includes(row.method))
      .reduce((sum, row) => sum + row.amount, 0),
    returned: rows.filter((row) => row.kind === 'customer' && row.method === 'return')
      .reduce((sum, row) => sum + row.amount, 0),
    discounts: rows.filter((row) => row.kind === 'customer' && row.method === 'discount')
      .reduce((sum, row) => sum + row.amount, 0),
    supplierCount: rows.filter((row) => row.kind === 'supplier').length,
  };
}

export function filterPaymentRows(rows: PaymentRow[], query: string, filter: PaymentFilter, sort: PaymentSort) {
  const q = normalizePaymentSearch(query);
  const result = rows.filter((row) => {
    if (q) {
      const haystack = normalizePaymentSearch([
        row.partyName, row.methodLabel, row.note, row.amount, row.invoiceNumber, row.checkNumber,
      ].join(' '));
      if (!haystack.includes(q)) return false;
    }
    if (filter === 'supplier') return row.kind === 'supplier';
    if (filter !== 'all') return row.kind === 'customer' && row.method === filter;
    return true;
  });

  result.sort((a, b) => {
    if (sort === 'oldest') return a.rawDate.localeCompare(b.rawDate) || a.amount - b.amount;
    if (sort === 'amountDesc') return b.amount - a.amount;
    if (sort === 'amountAsc') return a.amount - b.amount;
    return b.rawDate.localeCompare(a.rawDate) || b.amount - a.amount;
  });
  return result;
}

function iconOf(row: PaymentRow) {
  if (row.kind === 'supplier') return row.methodLabel.startsWith('چک') ? Landmark : Building2;
  if (row.method === 'cash') return Banknote;
  if (row.method === 'card') return CreditCard;
  if (row.method === 'transfer') return ArrowLeftRight;
  if (row.method === 'return') return RefreshCw;
  if (row.method === 'discount') return BadgePercent;
  return Wallet;
}

function directionLabel(direction: Direction) {
  if (direction === 'received') return 'دریافت';
  if (direction === 'return') return 'برگشت از فروش';
  if (direction === 'discount') return 'تخفیف';
  if (direction === 'supplier') return 'تأمین‌کننده';
  return 'تراکنش مشتری';
}

export default function Payments({ snapshot, onNavigate }: {
  snapshot: PaymentsSnapshot | null;
  onNavigate: (path: string) => void;
}) {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<PaymentFilter>('all');
  const [sort, setSort] = useState<PaymentSort>('newest');

  const rows = snapshot?.rows ?? [];
  const totals = useMemo(() => summarizePaymentRows(rows), [rows]);
  const filtered = useMemo(() => filterPaymentRows(rows, query, filter, sort), [rows, query, filter, sort]);

  if (!snapshot) {
    return <div className="payments-page" dir="rtl"><div className="customers-loading"><span className="nd-spinner"/> در حال دریافت گردش دریافت‌ها…</div></div>;
  }

  const filteredTotal = filtered.reduce((sum, row) => sum + row.amount, 0);
  const updatedAt = snapshot.updatedAt ? new Date(snapshot.updatedAt).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }) : '—';

  const openRow = (row: PaymentRow) => {
    if (row.kind === 'supplier') {
      onNavigate(`/supplier?id=${encodeURIComponent(row.partyId)}`);
      return;
    }
    if (row.invoiceId) {
      onNavigate(`/invoice?id=${encodeURIComponent(row.invoiceId)}`);
      return;
    }
    onNavigate(`/customer?id=${encodeURIComponent(row.partyId)}`);
  };

  return (
    <div className="payments-page" dir="rtl">
      <div className="payments-intro">
        <div>
          <span className="payments-eyebrow">گردش وجوه و ثبت‌های حساب</span>
          <h1>دریافت‌ها و پرداخت‌ها</h1>
          <p>هر ردیف را به پرونده مشتری، فاکتور یا تأمین‌کننده دنبال کن</p>
        </div>
        <span className="payments-total-count">{fa(rows.length)} ردیف</span>
      </div>

      <section className="payments-overview" aria-label="خلاصه گردش مالی">
        <div className="payments-stat is-received">
          <span className="payments-stat-icon"><Wallet size={17}/></span>
          <span className="payments-stat-copy"><small>دریافت نقد، کارت و انتقال</small><strong>{compact(totals.received)}</strong></span>
        </div>
        <div className="payments-stat is-return">
          <span className="payments-stat-icon"><RefreshCw size={17}/></span>
          <span className="payments-stat-copy"><small>برگشت از فروش</small><strong>{compact(totals.returned)}</strong></span>
        </div>
        <div className="payments-stat is-discount">
          <span className="payments-stat-icon"><BadgePercent size={17}/></span>
          <span className="payments-stat-copy"><small>تخفیف ثبت‌شده</small><strong>{compact(totals.discounts)}</strong></span>
        </div>
        <div className="payments-stat is-supplier">
          <span className="payments-stat-icon"><Building2 size={17}/></span>
          <span className="payments-stat-copy"><small>ردیف‌های تأمین‌کننده</small><strong>{fa(totals.supplierCount)} مورد</strong></span>
        </div>
      </section>

      <div className="payments-search-wrap">
        <Search size={18}/>
        <input
          value={query}
          onChange={(event: ChangeEvent<HTMLInputElement>) => setQuery(event.target.value)}
          placeholder="مشتری، تأمین‌کننده، مبلغ، فاکتور یا توضیح"
          aria-label="جستجوی گردش دریافت‌ها و پرداخت‌ها"
        />
        {query && <button type="button" onClick={() => setQuery('')} aria-label="پاک کردن جستجو"><X size={16}/></button>}
      </div>

      <div className="payments-filters" role="group" aria-label="فیلتر نوع تراکنش">
        {FILTERS.map((item) => (
          <button
            key={item.value}
            type="button"
            className={filter === item.value ? 'is-selected' : ''}
            aria-pressed={filter === item.value}
            onClick={() => setFilter(item.value)}
          >
            {item.label}
          </button>
        ))}
      </div>

      <div className="payments-toolbar">
        <div className="payments-result-summary">
          <strong>{fa(filtered.length)} ردیف</strong>
          <small>جمع مبالغ ردیف‌های فیلترشده: {compact(filteredTotal)}</small>
        </div>
        <label className="payments-sort">
          <ArrowUpDown size={15}/>
          <span>مرتب‌سازی</span>
          <select value={sort} onChange={(event) => setSort(event.target.value as PaymentSort)} aria-label="مرتب‌سازی تراکنش‌ها">
            <option value="newest">جدیدترین</option>
            <option value="oldest">قدیمی‌ترین</option>
            <option value="amountDesc">بیشترین مبلغ</option>
            <option value="amountAsc">کمترین مبلغ</option>
          </select>
        </label>
      </div>

      <div className="payments-list-heading">
        <strong>دفتر گردش</strong>
        <small>آخرین همگام‌سازی {updatedAt}</small>
      </div>

      <div className="payments-list">
        {filtered.length ? filtered.map((row) => {
          const direction = directionOf(row);
          const Icon = iconOf(row);
          const invoiceLabel = row.invoiceNumber ? `فاکتور #${row.invoiceNumber}` : row.kind === 'customer' ? 'بدون اتصال به فاکتور' : '';
          const meta = [row.methodLabel, row.date, invoiceLabel].filter(Boolean).join(' · ');
          return (
            <button className="payments-row" type="button" key={`${row.kind}-${row.id}`} onClick={() => openRow(row)}>
              <span className={`payments-row-icon is-${direction}`}><Icon size={18}/></span>
              <span className="payments-row-copy">
                <strong>{row.partyName}</strong>
                <small><CalendarDays size={12}/>{meta}</small>
                {row.note && <em>{row.note}</em>}
                {row.kind === 'supplier' && row.checkNumber && <em>شماره چک: {row.checkNumber}</em>}
              </span>
              <span className="payments-row-amount">
                <strong>{compact(row.amount)}</strong>
                <small className={`is-${direction}`}>{directionLabel(direction)}</small>
              </span>
              <ArrowLeft className="payments-row-chevron" size={16}/>
            </button>
          );
        }) : (
          <div className="payments-empty">
            <span><Search size={20}/></span>
            <strong>{rows.length ? 'تراکنشی با این مشخصات پیدا نشد' : 'هنوز گردش مالی ثبت نشده است'}</strong>
            <p>{rows.length ? 'عبارت جستجو یا فیلتر را تغییر بده.' : 'پس از ثبت دریافت، برگشت یا پرداخت تأمین‌کننده، سوابق در این صفحه نمایش داده می‌شود.'}</p>
            {(query || filter !== 'all') && <button type="button" onClick={() => { setQuery(''); setFilter('all'); }}>پاک کردن جستجو و فیلتر</button>}
          </div>
        )}
      </div>

      <footer className="payments-footer-note">
        <span><Wallet size={14}/></span>
        <p>برگشت از فروش و تخفیف، دریافت نقدی نیستند. پرداخت‌های تأمین‌کننده نیز ممکن است شامل چک در جریان یا برگشتی باشند؛ وضعیت آن‌ها در عنوان هر ردیف مشخص شده است.</p>
      </footer>
    </div>
  );
}
