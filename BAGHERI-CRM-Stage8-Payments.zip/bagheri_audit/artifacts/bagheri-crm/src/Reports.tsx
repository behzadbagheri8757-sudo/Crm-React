import { useMemo, useState, type PointerEvent } from 'react';
import {
  ArrowLeft,
  Banknote,
  CalendarDays,
  ChartNoAxesCombined,
  CheckCircle2,
  ClipboardList,
  Package,
  RefreshCw,
  ShoppingBag,
  TrendingDown,
  TrendingUp,
  UsersRound,
  Wallet,
} from 'lucide-react';

export type ReportPeriod = 'today' | 'week' | 'month' | 'all';

type ReportTrendPoint = { label: string; title: string; value: number; previous: number | null };
export type ReportsSnapshot = {
  period: ReportPeriod;
  periodLabel: string;
  context: string;
  range: {
    start: string;
    end: string;
    startLabel: string;
    endLabel: string;
    compareStart: string | null;
    compareEnd: string | null;
    compareStartLabel: string;
    compareEndLabel: string;
  };
  sales: number;
  count: number;
  average: number;
  grossProfit: number;
  returnsTotal: number;
  returnsCount: number;
  netSales: number;
  comparison: { percent: number; text: string } | null;
  trend: { points: ReportTrendPoint[]; hasPrevious: boolean; previousLabel: string };
  topProducts: Array<{ productId: string; name: string; revenue: number }>;
  returnProductCoverage: { applied: number; withoutItems: number };
  topCustomers: Array<{ id: string; name: string; net: number; share: number | null }>;
  collections: {
    received: number;
    byMethod: { cash: number; card: number; transfer: number };
    debtorCount: number;
    customerDebt: number;
    topDebtors: Array<{ id: string; name: string; balance: number }>;
  };
  inventory: { value: number; negative: number; zero: number; low: number; productCount: number };
  field: { visits: number; linked: number; linkedEver: number };
  financial: {
    totalProfit: number;
    outstandingChecks: number;
    supplierDebt: number;
    topSuppliers: Array<{ id: string; name: string; balance: number }>;
  };
  updatedAt: number;
};

const PERIODS: Array<{ value: ReportPeriod; label: string }> = [
  { value: 'today', label: 'امروز' },
  { value: 'week', label: 'این هفته' },
  { value: 'month', label: 'این ماه' },
  { value: 'all', label: 'همه' },
];

const fa = (value: number) => new Intl.NumberFormat('fa-IR').format(Math.round(Number(value) || 0));
const faDecimal = (value: number) => new Intl.NumberFormat('fa-IR', { maximumFractionDigits: 1 }).format(Number(value) || 0);
const money = (value: number) => `${fa(value)} تومان`;
const compact = (value: number) => {
  const amount = Number(value) || 0;
  const abs = Math.abs(amount);
  if (abs >= 1_000_000_000) return `${(amount / 1_000_000_000).toFixed(1).replace(/\.0$/, '')} میلیارد`;
  if (abs >= 1_000_000) return `${(amount / 1_000_000).toFixed(1).replace(/\.0$/, '')} میلیون`;
  return money(amount);
};

function TrendChart({ trend }: { trend: ReportsSnapshot['trend'] }) {
  const [activeIndex, setActiveIndex] = useState(Math.max(0, trend.points.length - 1));
  const points = trend.points;
  const max = Math.max(1, ...points.map((point) => Math.max(point.value, point.previous ?? 0)));
  const coords = points.map((point, index) => ({
    x: points.length <= 1 ? 50 : 96 - (index * 92) / (points.length - 1),
    y: 88 - (point.value / max) * 72,
    previousY: point.previous == null ? null : 88 - (point.previous / max) * 72,
  }));
  const currentPath = coords.map((point, index) => `${index === 0 ? 'M' : 'L'} ${point.x.toFixed(2)} ${point.y.toFixed(2)}`).join(' ');
  const areaPath = points.length ? `${currentPath} L ${coords[coords.length - 1].x} 90 L ${coords[0].x} 90 Z` : '';
  const previousCoords = coords.filter((point) => point.previousY != null);
  const previousPath = previousCoords.map((point, index) => `${index === 0 ? 'M' : 'L'} ${point.x.toFixed(2)} ${(point.previousY ?? 88).toFixed(2)}`).join(' ');
  const active = points[Math.min(activeIndex, Math.max(0, points.length - 1))];

  const selectFromPointer = (event: PointerEvent<HTMLDivElement>) => {
    if (points.length < 2) return;
    const rect = event.currentTarget.getBoundingClientRect();
    if (!rect.width) return;
    const fromRight = ((rect.right - event.clientX) / rect.width) * 100;
    const index = Math.round(((96 - fromRight) / 92) * (points.length - 1));
    setActiveIndex(Math.max(0, Math.min(points.length - 1, index)));
  };

  if (points.length < 2 || max <= 1) {
    return <div className="rp-chart-empty">برای این بازه هنوز داده کافی جهت نمایش روند وجود ندارد.</div>;
  }

  const labelIndices = points.length <= 7
    ? points.map((_, index) => index)
    : [0, Math.round((points.length - 1) / 2), points.length - 1];

  return (
    <div className="rp-trend-wrap">
      <div className="rp-chart-readout" aria-live="polite">
        <span>{active?.title ?? ''}</span>
        <strong>{money(active?.value ?? 0)}</strong>
      </div>
      <div className="rp-chart-canvas" onPointerDown={selectFromPointer} onPointerMove={selectFromPointer} role="img" aria-label="نمودار روند فروش؛ برای دیدن مقدار هر روز روی نمودار لمس کنید">
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
          <defs>
            <linearGradient id="reports-area-fill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="currentColor" stopOpacity=".20" />
              <stop offset="100%" stopColor="currentColor" stopOpacity="0" />
            </linearGradient>
          </defs>
          {[16, 52, 88].map((y) => <line key={y} x1="2" x2="98" y1={y} y2={y} className="rp-grid-line" />)}
          {trend.hasPrevious && previousCoords.length > 1 && <path d={previousPath} className="rp-chart-previous" />}
          <path d={areaPath} className="rp-chart-area" />
          <path d={currentPath} className="rp-chart-current" />
          {coords.map((point, index) => index === activeIndex ? (
            <g key={index}>
              <line x1={point.x} x2={point.x} y1="10" y2="90" className="rp-chart-guide" />
              <circle cx={point.x} cy={point.y} r="2.6" className="rp-chart-active-dot" />
            </g>
          ) : null)}
        </svg>
      </div>
      <div className="rp-chart-axis" dir="ltr">
        {labelIndices.map((index) => <span key={index}>{points[index].label}</span>)}
      </div>
      {trend.hasPrevious && <div className="rp-chart-legend"><span><i className="is-current"/> این دوره</span><span><i className="is-previous"/> {trend.previousLabel || 'دوره قبل'}</span></div>}
    </div>
  );
}

function SectionHeading({ title, note, action }: { title: string; note?: string; action?: { label: string; onClick: () => void } }) {
  return (
    <div className="rp-section-heading">
      <div><h2>{title}</h2>{note && <small>{note}</small>}</div>
      {action && <button type="button" onClick={action.onClick}>{action.label}<ArrowLeft size={14}/></button>}
    </div>
  );
}

function Metric({ label, value, tone }: { label: string; value: string; tone?: 'positive' | 'negative' }) {
  return <div className={`rp-metric${tone ? ` is-${tone}` : ''}`}><strong>{value}</strong><span>{label}</span></div>;
}

export default function Reports({
  snapshot,
  period,
  onPeriodChange,
  onRefresh,
  onNavigate,
}: {
  snapshot: ReportsSnapshot | null;
  period: ReportPeriod;
  onPeriodChange: (period: ReportPeriod) => void;
  onRefresh: () => void;
  onNavigate: (path: string) => void;
}) {
  const lastUpdated = useMemo(() => snapshot ? new Intl.DateTimeFormat('fa-IR', { hour: '2-digit', minute: '2-digit' }).format(new Date(snapshot.updatedAt)) : '', [snapshot?.updatedAt]);

  return (
    <div className="reports-page" dir="rtl">
      <header className="rp-page-heading">
        <div><span>مرکز تحلیل کسب‌وکار</span><h1>گزارش‌ها</h1><p>عملکرد فروش، مشتریان، وصول و موجودی</p></div>
        <button type="button" className="rp-refresh" onClick={onRefresh} aria-label="به‌روزرسانی گزارش‌ها"><RefreshCw size={17}/></button>
      </header>

      <div className="rp-period-control" role="group" aria-label="انتخاب بازه گزارش">
        {PERIODS.map((item) => <button key={item.value} type="button" className={period === item.value ? 'is-active' : ''} aria-pressed={period === item.value} onClick={() => onPeriodChange(item.value)}>{item.label}</button>)}
      </div>

      {!snapshot ? (
        <div className="rp-loading"><span className="nd-spinner"/> در حال محاسبه گزارش‌ها…</div>
      ) : <>
        <section className="rp-period-context">
          <div className="rp-period-context-icon"><CalendarDays size={17}/></div>
          <div><strong>{snapshot.context}</strong><span>از {snapshot.range.startLabel} تا {snapshot.range.endLabel}</span></div>
          {snapshot.comparison && snapshot.range.compareStartLabel && snapshot.range.compareEndLabel && (
            <small>مقایسه با {snapshot.range.compareStartLabel} تا {snapshot.range.compareEndLabel}</small>
          )}
        </section>

        <section className="rp-sales-hero">
          <div className="rp-sales-hero-top"><span>فروش {snapshot.periodLabel}</span><span><ChartNoAxesCombined size={15}/> {fa(snapshot.count)} فاکتور</span></div>
          <strong className="rp-sales-value">{compact(snapshot.sales)}</strong>
          <div className="rp-sales-bottom">
            <span>میانگین هر فاکتور: {compact(snapshot.average)}</span>
            {snapshot.comparison && <span className={`rp-change${snapshot.comparison.percent > 0 ? ' is-up' : snapshot.comparison.percent < 0 ? ' is-down' : ''}`}>
              {snapshot.comparison.percent > 0 ? <TrendingUp size={14}/> : snapshot.comparison.percent < 0 ? <TrendingDown size={14}/> : <CheckCircle2 size={14}/>}
              {snapshot.comparison.percent > 0 ? '+' : snapshot.comparison.percent < 0 ? '−' : ''}{faDecimal(Math.round(Math.abs(snapshot.comparison.percent) * 10) / 10)}٪
            </span>}
          </div>
          {snapshot.comparison && <small className="rp-comparison-caption">{snapshot.comparison.text}</small>}
        </section>

        <section className="rp-metrics-grid" aria-label="خلاصه عملکرد">
          <Metric label="تعداد فاکتور" value={fa(snapshot.count)} />
          <Metric label="میانگین فاکتور" value={compact(snapshot.average)} />
          <Metric label="سود ناخالص" value={compact(snapshot.grossProfit)} tone={snapshot.grossProfit < 0 ? 'negative' : 'positive'} />
        </section>
        <p className="rp-footnote rp-profit-note">سود ناخالص بر اساس قیمت فروش، بهای خرید ثبت‌شده در ردیف فاکتور و تخفیف‌هاست؛ برگشت از فروش جداگانه نمایش داده می‌شود.</p>

        <section className="rp-panel">
          <SectionHeading title="روند فروش" note={snapshot.trend.hasPrevious ? 'مقایسه با بازه مشابه قبلی' : 'بر اساس مبلغ فاکتورهای ثبت‌شده'} />
          <TrendChart trend={snapshot.trend}/>
        </section>

        {snapshot.returnsTotal > 0 && <section className="rp-returns-note">
          <TrendingDown size={16}/><span>برگشت از فروش این بازه</span><strong>{compact(snapshot.returnsTotal)}</strong>
          <small>{fa(snapshot.returnsCount)} ثبت برگشت؛ در فروش ناخالص نمودار کسر نشده است.</small>
        </section>}

        <section className="rp-panel">
          <SectionHeading title="پرفروش‌ترین کالاها" note="بر اساس مبلغ فروش خالصِ برگشتی‌های دارای ردیف کالا" action={{ label: 'همه کالاها', onClick: () => onNavigate('/products') }}/>
          {snapshot.topProducts.length ? <div className="rp-ranking-list">
            {snapshot.topProducts.map((product, index) => <div className="rp-ranking-row" key={`${product.productId}-${index}`}>
              <span className="rp-rank-number">{fa(index + 1)}</span>
              <div className="rp-ranking-main"><strong>{product.name}</strong><div className="rp-ranking-track"><i style={{ width: `${Math.max(3, (product.revenue / Math.max(1, snapshot.topProducts[0].revenue)) * 100)}%` }}/></div></div>
              <b>{compact(product.revenue)}</b>
            </div>)}
          </div> : <div className="rp-empty">در این بازه فروش کالایی ثبت نشده است.</div>}
          {(snapshot.returnProductCoverage.applied > 0 || snapshot.returnProductCoverage.withoutItems > 0) && <p className="rp-footnote">{snapshot.returnProductCoverage.applied ? 'برگشت‌های دارای ردیف کالا در رتبه‌بندی اعمال شده‌اند. ' : ''}{snapshot.returnProductCoverage.withoutItems ? `${fa(snapshot.returnProductCoverage.withoutItems)} برگشت بدون ردیف کالا در رتبه‌بندی کالاها قابل تخصیص نبوده است.` : ''}</p>}
        </section>

        <section className="rp-panel">
          <SectionHeading title="مشتریان برتر" note="فروش خالص در بازه انتخاب‌شده" action={{ label: 'فهرست مشتریان', onClick: () => onNavigate('/customers') }}/>
          <div className="rp-current-debt"><span><Wallet size={15}/> مطالبات فعلی مشتریان</span><strong>{compact(snapshot.collections.customerDebt)}</strong><small>{fa(snapshot.collections.debtorCount)} مشتری بدهکار</small></div>
          {snapshot.topCustomers.length ? <div className="rp-simple-list">
            {snapshot.topCustomers.map((customer, index) => <button type="button" key={customer.id} onClick={() => onNavigate(`/customer?id=${encodeURIComponent(customer.id)}`)}>
              <span className="rp-rank-number">{fa(index + 1)}</span><span className="rp-simple-copy"><strong>{customer.name}</strong>{customer.share != null && <small>{fa(customer.share)}٪ از فروش خالص این بازه</small>}</span><b>{compact(customer.net)}</b><ArrowLeft size={15}/>
            </button>)}
          </div> : <div className="rp-empty">در این بازه فروش مشتری ثبت نشده است.</div>}
        </section>

        <section className="rp-panel">
          <SectionHeading title="وصول و مطالبات" note="دریافت نقد، کارت و انتقال در بازه انتخاب‌شده" action={{ label: 'دریافت‌ها', onClick: () => onNavigate('/payments') }}/>
          <div className="rp-collection-total"><span>مجموع دریافتی دوره</span><strong>{compact(snapshot.collections.received)}</strong></div>
          <div className="rp-method-grid">
            <Metric label="نقد" value={compact(snapshot.collections.byMethod.cash)}/>
            <Metric label="کارت" value={compact(snapshot.collections.byMethod.card)}/>
            <Metric label="انتقال" value={compact(snapshot.collections.byMethod.transfer)}/>
          </div>
          {snapshot.collections.topDebtors.length > 0 && <>
            <div className="rp-subheading">بیشترین مطالبات فعلی</div>
            <div className="rp-simple-list">
              {snapshot.collections.topDebtors.map((customer) => <button type="button" key={customer.id} onClick={() => onNavigate(`/customer?id=${encodeURIComponent(customer.id)}`)}>
                <span className="rp-simple-copy"><strong>{customer.name}</strong></span><b className="is-negative">{compact(customer.balance)}</b><ArrowLeft size={15}/>
              </button>)}
            </div>
          </>}
        </section>

        <section className="rp-panel">
          <SectionHeading title="وضعیت موجودی" note="ارزش موجودی و استثناهای فعلی" action={{ label: 'جزئیات انبار', onClick: () => onNavigate('/inventory') }}/>
          <div className="rp-inventory-value"><Package size={18}/><span>ارزش موجودی</span><strong>{compact(snapshot.inventory.value)}</strong></div>
          <div className="rp-inventory-states">
            <button type="button" onClick={() => onNavigate('/inventory')}><strong className={snapshot.inventory.negative ? 'is-negative' : ''}>{fa(snapshot.inventory.negative)}</strong><span>موجودی منفی</span></button>
            <button type="button" onClick={() => onNavigate('/inventory')}><strong>{fa(snapshot.inventory.zero)}</strong><span>ناموجود</span></button>
            <button type="button" onClick={() => onNavigate('/inventory')}><strong className={snapshot.inventory.low ? 'is-warning' : ''}>{fa(snapshot.inventory.low)}</strong><span>کم‌موجود</span></button>
          </div>
          <p className="rp-footnote">موجودی منفی، صفر و کم‌موجود به‌صورت دسته‌های جداگانه از اطلاعات فعلی کالاها خوانده شده‌اند.</p>
        </section>

        {snapshot.field.visits > 0 && <section className="rp-panel">
          <SectionHeading title="عملکرد ویزیت" note="فقط اتصال صریح فاکتور به ویزیت محاسبه می‌شود" action={{ label: 'ویزیت‌ها', onClick: () => onNavigate('/visits') }}/>
          <div className="rp-field-metrics">
            <Metric label="ویزیت" value={fa(snapshot.field.visits)}/>
            {snapshot.field.linkedEver > 0 ? <>
              <Metric label="منجر به فاکتور" value={fa(snapshot.field.linked)}/>
              <Metric label="نرخ تبدیل" value={`${fa(Math.round((snapshot.field.linked / snapshot.field.visits) * 100))}٪`}/>
            </> : <p>هنوز فاکتوری به ویزیت متصل نشده است؛ نرخ تبدیل قابل محاسبه نیست.</p>}
          </div>
        </section>}

        <section className="rp-panel">
          <SectionHeading title="مالی و تأمین" note="مانده‌ها و شاخص‌های کلی کسب‌وکار" />
          <div className="rp-finance-list">
            <div><span><ChartNoAxesCombined size={16}/> سود کل از ابتدا</span><strong>{compact(snapshot.financial.totalProfit)}</strong></div>
            <button type="button" onClick={() => onNavigate('/checks')}><span><ClipboardList size={16}/> چک‌های در جریان</span><strong>{compact(snapshot.financial.outstandingChecks)}</strong><ArrowLeft size={15}/></button>
            <button type="button" onClick={() => onNavigate('/suppliers')}><span><Banknote size={16}/> بدهی تأمین‌کنندگان</span><strong>{compact(snapshot.financial.supplierDebt)}</strong><ArrowLeft size={15}/></button>
          </div>
          {snapshot.financial.topSuppliers.length > 0 && <>
            <div className="rp-subheading">بیشترین بدهی تأمین‌کننده</div>
            <div className="rp-simple-list">
              {snapshot.financial.topSuppliers.map((supplier) => <button type="button" key={supplier.id} onClick={() => onNavigate(`/supplier?id=${encodeURIComponent(supplier.id)}`)}>
                <span className="rp-simple-copy"><strong>{supplier.name}</strong></span><b className="is-negative">{compact(supplier.balance)}</b><ArrowLeft size={15}/>
              </button>)}
            </div>
          </>}
        </section>

        <section className="rp-panel rp-shortcuts">
          <SectionHeading title="دسترسی به جزئیات" note="رفتن به فهرست‌های عملیاتی" />
          <button type="button" onClick={() => onNavigate('/invoices')}><ReceiptIcon/><span>فاکتورها</span><ArrowLeft size={15}/></button>
          <button type="button" onClick={() => onNavigate('/customers')}><UsersRound size={17}/><span>مشتریان</span><ArrowLeft size={15}/></button>
          <button type="button" onClick={() => onNavigate('/products')}><ShoppingBag size={17}/><span>کالاها</span><ArrowLeft size={15}/></button>
          <button type="button" onClick={() => onNavigate('/payments')}><Wallet size={17}/><span>دریافت‌ها</span><ArrowLeft size={15}/></button>
        </section>

        <footer className="rp-report-footer">آخرین دریافت اطلاعات: {lastUpdated} · گزارش فقط‌خواندنی است و داده‌های مالی را تغییر نمی‌دهد.</footer>
      </>}
    </div>
  );
}

function ReceiptIcon() {
  return <ClipboardList size={17}/>;
}
