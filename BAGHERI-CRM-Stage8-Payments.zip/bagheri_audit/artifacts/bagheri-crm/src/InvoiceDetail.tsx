import { useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  CalendarDays,
  CheckCircle2,
  ChevronLeft,
  Clock3,
  FileClock,
  Image,
  Link2,
  Package,
  Printer,
  ReceiptText,
  Trash2,
  UserRound,
  Wallet,
  Wrench,
} from 'lucide-react';

export type InvoiceDetailSnapshot = {
  found: boolean;
  invoiceId: string;
  updatedAt: number;
  invoice?: {
    id: string;
    number: string;
    customerId: string;
    buyerName: string;
    date: string;
    total: number;
    discount: number;
    discountType: string;
    discountAmount: number;
    cashPaid: number;
    cardPaid: number;
    transferPaid: number;
    checkPaid: number;
    prevBalance: number | null;
    newBalance: number | null;
    visitId: string;
  };
  customer?: { id: string; name: string; phone: string } | null;
  status?: { key: 'paid' | 'debt'; label: string };
  financial?: {
    paid: number;
    remain: number;
    currentCustomerBalance: number | null;
    profit: number;
  };
  items?: Array<{
    id: string;
    productId: string;
    name: string;
    qty: number;
    unit: string;
    price: number;
    discount: number;
    lineTotal: number;
  }>;
  allocation?: {
    onRecord: number;
    linkedEventObservedTotal: number;
    legacyOnInvoice: number;
    incoming: Array<{
      kind: string;
      eventId: string;
      date: string;
      dateLabel: string;
      amount: number;
      path: string;
      fromInvoiceId: string;
      fromInvoiceNumber: string;
    }>;
    incomingTotal: number;
    incomingLinkedTotal: number;
    incomingLinkedReturnTotal: number;
    outgoing: Array<{
      kind: string;
      eventId: string;
      date: string;
      dateLabel: string;
      amount: number;
      destinations: Array<{ type: string; invoiceId: string; invoiceNumber: string; amount: number }>;
    }>;
    outgoingTotal: number;
    effectivePaid: number;
    remain: number;
  } | null;
  visit?: {
    linkedId: string;
    linkedLabel: string;
    options: Array<{ id: string; label: string }>;
  };
  editHistory?: Array<{
    id: string;
    editedAt: string;
    beforeTotal: number | null;
    afterTotal: number | null;
    note: string;
  }>;
};

type ActionName = 'print' | 'edit' | 'image' | 'delete' | 'link-visit' | 'unlink-visit';

const fa = (value: number) => new Intl.NumberFormat('fa-IR').format(Math.round(Number(value) || 0));
const money = (value: number) => `${fa(value)} تومان`;
const compact = (value: number) => {
  const amount = Number(value) || 0;
  const abs = Math.abs(amount);
  if (abs >= 1_000_000_000) return `${(amount / 1_000_000_000).toFixed(1).replace(/\.0$/, '')} میلیارد`;
  if (abs >= 1_000_000) return `${(amount / 1_000_000).toFixed(1).replace(/\.0$/, '')} میلیون`;
  return money(amount);
};

function methodLabel(kind: string) {
  const labels: Record<string, string> = {
    cash: 'نقد', card: 'کارت', transfer: 'انتقال', check: 'چک',
    return: 'برگشت از فروش', discount: 'تخفیف',
  };
  return labels[kind] || kind || 'سند مالی';
}

function pathLabel(path: string, fromNumber: string) {
  if (path === 'linked') return 'پرداخت ثبت‌شده برای همین فاکتور';
  if (path === 'overflow') return `مازاد پرداخت فاکتور ${fromNumber ? `#${fromNumber}` : 'دیگر'}`;
  if (path === 'unlinked') return 'دریافت بدون مقصد مشتری';
  if (path === 'linkedReturn') return 'برگشت از فروش متصل';
  return 'تخصیص ثبت‌شده';
}

function destinationLabel(type: string, number: string) {
  if (type === 'invoice') return `فاکتور ${number ? `#${number}` : 'دیگر'}`;
  if (type === 'opening') return 'مانده افتتاحیه';
  return 'اعتبار مشتری';
}

function Metric({ label, value, tone }: { label: string; value: string; tone?: 'positive' | 'warning' }) {
  return <div className={`id-metric${tone ? ` is-${tone}` : ''}`}><small>{label}</small><strong>{value}</strong></div>;
}

export default function InvoiceDetail({ snapshot, onAction, onNavigate, onBack }: {
  snapshot: InvoiceDetailSnapshot | null;
  onAction: (action: ActionName, invoiceId: string, visitId?: string) => void;
  onNavigate: (path: string) => void;
  onBack: () => void;
}) {
  const [selectedVisitId, setSelectedVisitId] = useState('');

  if (!snapshot) {
    return <div className="invoice-detail-page" dir="rtl"><div className="customers-loading"><span className="nd-spinner"/> در حال دریافت جزئیات فاکتور…</div></div>;
  }
  if (!snapshot.found || !snapshot.invoice || !snapshot.financial || !snapshot.status) {
    return <div className="invoice-detail-page" dir="rtl"><div className="id-not-found"><strong>فاکتور پیدا نشد</strong><p>ممکن است فاکتور حذف شده باشد یا اطلاعات هنوز بارگذاری نشده باشد.</p><button type="button" onClick={onBack}>بازگشت به فاکتورها</button></div></div>;
  }

  const invoice = snapshot.invoice;
  const customer = snapshot.customer;
  const financial = snapshot.financial;
  const items = snapshot.items ?? [];
  const allocation = snapshot.allocation;
  const visit = snapshot.visit;
  const history = snapshot.editHistory ?? [];
  const hasPaymentBreakdown = invoice.discountAmount > 0 || invoice.cashPaid > 0 || invoice.cardPaid > 0 || invoice.transferPaid > 0 || invoice.checkPaid > 0 || invoice.prevBalance !== null || invoice.newBalance !== null;
  const paymentRows = [
    { label: 'نقد', amount: invoice.cashPaid },
    { label: 'کارت', amount: invoice.cardPaid },
    { label: 'انتقال', amount: invoice.transferPaid },
    { label: 'چک', amount: invoice.checkPaid },
  ].filter((row) => row.amount > 0);

  return (
    <div className="invoice-detail-page" dir="rtl">
      <section className="id-identity">
        <div className="id-identity-icon"><ReceiptText size={21}/></div>
        <div className="id-identity-copy">
          <span>فاکتور فروش</span>
          <h1>#{invoice.number || '—'}</h1>
          <small><CalendarDays size={13}/>{invoice.date || 'تاریخ نامشخص'}</small>
        </div>
        <span className={`id-status ${snapshot.status.key === 'paid' ? 'is-paid' : 'is-debt'}`}>
          {snapshot.status.key === 'paid' ? <CheckCircle2 size={13}/> : <Clock3 size={13}/>}
          {snapshot.status.label}
        </span>
      </section>

      {customer && <button type="button" className="id-customer-link" onClick={() => onNavigate(`/customer?id=${encodeURIComponent(customer.id)}&fromInv=${encodeURIComponent(invoice.id)}`)}>
        <span className="id-customer-avatar"><UserRound size={17}/></span>
        <span><strong>{customer.name}</strong><small>{invoice.buyerName ? `خریدار: ${invoice.buyerName}` : (customer.phone || 'مشاهده پرونده مشتری')}</small></span>
        <ChevronLeft size={17}/>
      </button>}

      <section className="id-finance-panel" aria-label="خلاصه مالی فاکتور">
        <div className="id-finance-total"><span>مبلغ کل فاکتور</span><strong>{compact(invoice.total)}</strong></div>
        <div className="id-finance-grid">
          <Metric label="پرداخت مؤثر" value={compact(financial.paid)} tone="positive"/>
          <Metric label="مانده فاکتور" value={compact(Math.max(0, financial.remain))} tone={financial.remain > 0.5 ? 'warning' : 'positive'}/>
        </div>
      </section>

      {financial.currentCustomerBalance !== null && <section className="id-live-balance">
        <span><Wallet size={15}/> مانده فعلی حساب مشتری</span>
        <strong className={financial.currentCustomerBalance > 0.5 ? 'is-debt' : financial.currentCustomerBalance < -0.5 ? 'is-credit' : ''}>
          {compact(Math.abs(financial.currentCustomerBalance))} {financial.currentCustomerBalance > 0.5 ? 'بدهکار' : financial.currentCustomerBalance < -0.5 ? 'بستانکار' : 'تسویه'}
        </strong>
        <small>این عدد مانده کل حساب مشتری است و با مانده همین فاکتور تفاوت دارد.</small>
      </section>}

      <section className="id-section">
        <div className="id-section-heading"><div><span>اقلام فاکتور</span><small>{fa(items.length)} ردیف ثبت‌شده</small></div><Package size={17}/></div>
        {items.length ? <div className="id-items-list">
          {items.map((item, index) => <div className="id-item-row" key={item.id || `${item.productId}-${index}`}>
            <span className="id-item-index">{fa(index + 1)}</span>
            <span className="id-item-copy"><strong>{item.name || 'کالای نامشخص'}</strong><small>{fa(item.qty)} {item.unit} × {compact(item.price)}{item.discount > 0 ? ` · تخفیف ردیف ${compact(item.discount)}` : ''}</small></span>
            <b>{compact(item.lineTotal)}</b>
          </div>)}
        </div> : <div className="id-empty">برای این فاکتور ردیفی ثبت نشده است.</div>}
      </section>

      <section className="id-section">
        <div className="id-section-heading"><div><span>پرداخت و مانده هنگام ثبت</span><small>اطلاعات ثبت‌شده روی خود فاکتور</small></div><Wallet size={17}/></div>
        {hasPaymentBreakdown ? <div className="id-detail-list">
          {invoice.discountAmount > 0 && <div className="id-detail-row"><span>تخفیف فاکتور{invoice.discountType === 'percent' ? ` · ${fa(invoice.discount)}٪` : ''}</span><b>{compact(invoice.discountAmount)}</b></div>}
          {paymentRows.map((row) => <div className="id-detail-row" key={row.label}><span>{row.label}</span><b>{compact(row.amount)}</b></div>)}
          {invoice.prevBalance !== null && <div className="id-detail-row"><span>مانده مشتری پیش از این فاکتور</span><b>{compact(Math.abs(invoice.prevBalance))} {invoice.prevBalance > 0 ? 'بدهکار' : invoice.prevBalance < 0 ? 'بستانکار' : 'تسویه'}</b></div>}
          {invoice.newBalance !== null && <div className="id-detail-row"><span>مانده ثبت‌شده پس از این فاکتور</span><b>{compact(Math.abs(invoice.newBalance))} {invoice.newBalance > 0 ? 'بدهکار' : invoice.newBalance < 0 ? 'بستانکار' : 'تسویه'}</b></div>}
        </div> : <div className="id-empty">جزئیات پرداخت جداگانه‌ای روی این فاکتور ثبت نشده است.</div>}
      </section>

      <section className="id-section">
        <div className="id-section-heading"><div><span>ریز تخصیص تسویه</span><small>ردیابی خواندنی بر اساس موتور FIFO فعلی</small></div><FileClock size={17}/></div>
        {allocation ? <>
          <div className="id-allocation-summary">
            <div><small>ثبت‌شده روی فاکتور</small><strong>{compact(allocation.onRecord)}</strong></div>
            <div><small>رسیده به این فاکتور</small><strong>{compact(allocation.incomingTotal)}</strong></div>
            <div><small>منتقل‌شده به بدهی دیگر</small><strong>{compact(allocation.outgoingTotal)}</strong></div>
          </div>
          {allocation.incoming.length > 0 && <div className="id-allocation-group">
            <strong>مبالغ مؤثر در تسویه این فاکتور</strong>
            {allocation.incoming.map((row, index) => <div className="id-allocation-row" key={`${row.eventId}-${row.path}-${index}`}>
              <span className={`id-allocation-dot ${row.path === 'linkedReturn' ? 'is-return' : ''}`}/>
              <span><b>{pathLabel(row.path, row.fromInvoiceNumber)}</b><small>{row.dateLabel || row.date || 'تاریخ نامشخص'} · {methodLabel(row.kind)}{row.eventId ? ` · ${row.eventId}` : ''}</small></span>
              <strong>{compact(row.amount)}</strong>
            </div>)}
          </div>}
          {allocation.outgoing.length > 0 && <div className="id-allocation-group is-outgoing">
            <strong>مبالغی که به بدهی‌های دیگر رفته‌اند</strong>
            {allocation.outgoing.map((row, index) => <div className="id-allocation-row" key={`${row.eventId}-${index}`}>
              <span className="id-allocation-dot is-outgoing"/>
              <span><b>{methodLabel(row.kind)} · {row.dateLabel || row.date || 'تاریخ نامشخص'}</b><small>{row.destinations.map((destination) => `${destinationLabel(destination.type, destination.invoiceNumber)}${destination.amount ? ` (${compact(destination.amount)})` : ''}`).join('، ') || 'مقصد ثبت نشده'}</small></span>
              <strong>{compact(row.amount)}</strong>
            </div>)}
          </div>}
          {allocation.legacyOnInvoice > 0.5 && <div className="id-allocation-note is-info"><AlertTriangle size={15}/><span>{compact(allocation.legacyOnInvoice)} از پرداخت‌های قدیمی روی فاکتور ثبت شده، اما ریزتراکنش متناظر برای آن در داده‌های فعلی وجود ندارد.</span></div>}
          {allocation.incomingLinkedReturnTotal > 0.5 && <div className="id-allocation-note is-warning"><AlertTriangle size={15}/><span>مبلغ برگشت از فروش در ردیابی دیده می‌شود؛ این مبلغ دریافت نقدی نیست.</span></div>}
          {allocation.incoming.length === 0 && allocation.outgoing.length === 0 && allocation.legacyOnInvoice <= 0.5 && <div className="id-empty">هنوز تخصیصی برای این فاکتور ثبت نشده است.</div>}
          <div className="id-allocation-final"><span>مبلغ مؤثر تسویه‌شده</span><b>{compact(allocation.effectivePaid)}</b><span>مانده فاکتور</span><b>{compact(allocation.remain)}</b></div>
          <p className="id-footnote">این ردیابی فقط‌خواندنی است و از قواعد تخصیص فعلی برنامه استفاده می‌کند. با تغییر اسناد گذشته ممکن است نتیجه ردیابی تغییر کند.</p>
        </> : <div className="id-empty">ردیابی تخصیص برای این فاکتور در دسترس نیست؛ ارقام خلاصه مالی همچنان از محاسبات رسمی خوانده می‌شوند.</div>}
      </section>

      <section className="id-section">
        <div className="id-section-heading"><div><span>ارتباط با ویزیت</span><small>اختیاری؛ ویزیت و فاکتور مستقل هستند</small></div><Link2 size={17}/></div>
        {visit?.linkedId ? <div className="id-visit-linked"><CheckCircle2 size={16}/><span><strong>ویزیت متصل</strong><small>{visit.linkedLabel || 'ویزیت ثبت‌شده'}</small></span><button type="button" onClick={() => onAction('unlink-visit', invoice.id)}>قطع ارتباط</button></div> : <>
          <div className="id-empty id-visit-empty">این فاکتور به ویزیتی متصل نیست.</div>
          {visit?.options.length ? <div className="id-visit-picker">
            <label htmlFor="id-visit-select">انتخاب ویزیت همین مشتری</label>
            <select id="id-visit-select" value={selectedVisitId} onChange={(event) => setSelectedVisitId(event.target.value)}>
              <option value="">انتخاب ویزیت…</option>
              {visit.options.map((option) => <option key={option.id} value={option.id}>{option.label}</option>)}
            </select>
            <button type="button" disabled={!selectedVisitId} onClick={() => onAction('link-visit', invoice.id, selectedVisitId)}><Link2 size={15}/> اتصال ویزیت</button>
          </div> : <div className="id-footnote">برای این مشتری ویزیتی ثبت نشده است.</div>}
        </>}
      </section>

      {history.length > 0 && <section className="id-section">
        <div className="id-section-heading"><div><span>تاریخچه ویرایش</span><small>{fa(history.length)} تغییر ثبت‌شده</small></div><Wrench size={17}/></div>
        <div className="id-history-list">{history.map((entry) => <div className="id-history-row" key={entry.id}>
          <span className="id-history-mark"><Clock3 size={14}/></span>
          <span><strong>{entry.note || 'ویرایش فاکتور'}</strong><small>{entry.editedAt}</small></span>
          {(entry.beforeTotal !== null || entry.afterTotal !== null) && <b>{entry.beforeTotal !== null ? compact(entry.beforeTotal) : '—'} ← {entry.afterTotal !== null ? compact(entry.afterTotal) : '—'}</b>}
        </div>)}</div>
      </section>}

      <section className="id-private-profit">
        <span>اطلاعات داخلی · فقط برای مدیریت</span>
        <small>سود محاسبه‌شده این فاکتور</small>
        <strong>{compact(financial.profit)}</strong>
        <p>این مقدار برای مشتری نمایش داده نمی‌شود و فقط از محاسبات موجود خوانده شده است.</p>
      </section>

      <section className="id-actions" aria-label="عملیات فاکتور">
        <button type="button" onClick={() => onAction('print', invoice.id)}><Printer size={17}/> چاپ فاکتور</button>
        <button type="button" onClick={() => onAction('image', invoice.id)}><Image size={17}/> خروجی تصویر</button>
        <button type="button" onClick={() => onAction('edit', invoice.id)}><Wrench size={17}/> ویرایش فاکتور</button>
      </section>

      <section className="id-danger-zone">
        <div><strong>حذف فاکتور</strong><small>حذف ممکن است مانده حساب و موجودی را طبق منطق رسمی برنامه اصلاح کند.</small></div>
        <button type="button" onClick={() => onAction('delete', invoice.id)}><Trash2 size={16}/> حذف</button>
      </section>

      <button className="id-back-bottom" type="button" onClick={onBack}><ArrowLeft size={15}/> بازگشت به فهرست فاکتورها</button>
    </div>
  );
}
