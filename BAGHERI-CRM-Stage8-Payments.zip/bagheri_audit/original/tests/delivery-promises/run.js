// node tests/delivery-promises/run.js — logic + html tests for «قول تحویل» (no DOM, no IndexedDB)
const fs=require('fs'),vm=require('vm'),path=require('path');
const ROOT=path.join(__dirname,'..','..');
const RD=Date, FIXED=new RD('2026-11-10T10:00:00').getTime();
class FD extends RD{constructor(...a){a.length?super(...a):super(FIXED);} static now(){return FIXED;}}
const noop=()=>{};
const ctx={console,JSON,Math,Set,Map,Object,Array,String,Number,Boolean,RegExp,Error,Promise,isFinite,isNaN,parseInt,parseFloat,Symbol,Intl,Date:FD,
  setTimeout:noop,clearTimeout:noop,setInterval:noop,localStorage:{getItem:()=>null,setItem:noop,removeItem:noop},
  document:{getElementById:()=>null,createElement:()=>({}),addEventListener:noop,body:{},readyState:'complete'},navigator:{},location:{hash:''},addEventListener:noop,requestAnimationFrame:noop,
  indexedDB:{},MutationObserver:undefined};
ctx.window=ctx;ctx.self=ctx;ctx.globalThis=ctx;vm.createContext(ctx);
const run=(f,src)=>vm.runInContext(src,ctx,{filename:f});
['js/models.js','js/ui.js','js/db.js','js/calc.js','js/computation-bank.js','js/payment-promises.js','js/delivery-promises.js','js/views/payment-promises.js','js/views/delivery-promises.js','js/backup.js']
  .forEach(f=>run(f,fs.readFileSync(path.join(ROOT,f),'utf8')));
run('stubs','var __saves=0; saveData=async function(){__saves++;}; restoreDataInPlace=function(s){ reconcileRestoreGraph(data,s); };');

let pass=0,fail=0;
function t(name,cond){ if(cond){pass++;console.log('ok   '+name);}else{fail++;console.log('FAIL '+name);} }
const day=n=>{const d=new RD(FIXED);d.setDate(d.getDate()+n);return d.toISOString().slice(0,10);};
const TODAY=day(0);
function seed(extra){
  ctx.__d=Object.assign({
    customers:[{id:'c1',name:'نور',active:true,visits:[]},{id:'c2',name:'رضایی',active:true,visits:[]}],
    products:[{id:'p1',name:'نخود',active:true,stockQty:10,retail:100,sell:90},{id:'p2',name:'عدس',active:true,stockQty:3,retail:200,sell:180},{id:'p3',name:'لوبیا',active:true,stockQty:50,retail:300,sell:280}],
    invoices:[],payments:[],checks:[],suppliers:[],inventoryLayers:[],analysisGroups:[],paymentPromises:[],deliveryPromises:[]},extra||{});
  run('seed','data = Object.assign(emptyData(), __d);');
  return vm.runInContext('data',ctx);
}
const DP=()=>ctx.DeliveryPromises;
const bk=()=>({products:[],customers:[{id:'c1',name:'a'}],invoices:[],payments:[],checks:[],suppliers:[],schemaVersion:3,inventoryLayers:[],regions:[],routes:[],neighborhoods:[]});
(async()=>{
  // ---- 1. register ----
  let d=seed();
  let r=DP().add(d,'c1',{deliveryDate:day(1),items:[{productId:'p1',qty:2},{productId:'p2'}]},TODAY);
  t('1a promise registered (pending, date=today, name snapshot, qty default 0)',r.ok&&r.promise.status==='pending'&&r.promise.date===TODAY&&r.promise.items[0].name==='نخود'&&r.promise.items[1].qty===0);
  t('1b past date rejected',!DP().add(d,'c1',{deliveryDate:day(-1),items:[{productId:'p1',qty:1}]},TODAY).ok);
  t('1c today allowed',DP().add(d,'c2',{deliveryDate:TODAY,items:[{productId:'p1',qty:1}]},TODAY).ok);
  t('1d no items and no note rejected; note-only accepted',!DP().add(d,'c1',{deliveryDate:day(2),items:[]},TODAY).ok&&DP().add(d,'c1',{deliveryDate:day(2),items:[],note:'چیزی سفارش داد'},TODAY).ok);
  t('1e unknown product ignored (→ empty → rejected)',!DP().add(d,'c1',{deliveryDate:day(2),items:[{productId:'zzz',qty:1}]},TODAY).ok);
  t('1f negative / NaN qty rejected',!DP().add(d,'c1',{deliveryDate:day(2),items:[{productId:'p1',qty:-1}]},TODAY).ok&&!DP().add(d,'c1',{deliveryDate:day(2),items:[{productId:'p1',qty:'x'}]},TODAY).ok);
  t('1g unknown customer rejected',!DP().add(d,'nope',{deliveryDate:day(2),items:[{productId:'p1',qty:1}]},TODAY).ok);
  t('1h duplicate product lines collapse; several promises per customer allowed',(()=>{const x=DP().add(d,'c1',{deliveryDate:day(3),items:[{productId:'p1',qty:1},{productId:'p1',qty:5}]},TODAY);return x.ok&&x.promise.items.length===1&&DP().pending('c1',d).length>=2;})());
  const saves0=vm.runInContext('__saves',ctx);
  const ro=await DP().commit(dd=>DP().add(dd,'c2',{deliveryDate:day(2),items:[{productId:'p3',qty:4}]}));
  t('1i commit() saves through saveData',ro.ok&&vm.runInContext('__saves',ctx)===saves0+1);
  const rb=await DP().commit(dd=>DP().add(dd,'c2',{deliveryDate:day(-3),items:[{productId:'p3',qty:4}]}));
  t('1j rejected mutation does not save',!rb.ok&&vm.runInContext('__saves',ctx)===saves0+1);

  // ---- 2. normalizeData ----
  d=seed(); DP().add(d,'c1',{deliveryDate:day(1),items:[{productId:'p1',qty:2}],note:'x'},TODAY);
  let n=ctx.normalizeData(JSON.parse(JSON.stringify(d)));
  t('2a normalizeData keeps the promise intact',n.deliveryPromises.length===1&&n.deliveryPromises[0].items[0].qty===2&&n.deliveryPromises[0].items[0].name==='نخود'&&n.deliveryPromises[0].invoiceId===null&&n.deliveryPromises[0].doneAt===null);
  const old=JSON.parse(JSON.stringify(d)); delete old.deliveryPromises;
  t('2b old data without the field → []',Array.isArray(ctx.normalizeData(old).deliveryPromises)&&ctx.normalizeData(old).deliveryPromises.length===0);
  const dirty=JSON.parse(JSON.stringify(d)); dirty.deliveryPromises.push({id:'b1',customerId:'c1',deliveryDate:'nonsense'},{id:'b2',deliveryDate:day(1)});
  t('2c corrupt rows dropped, valid kept',ctx.normalizeData(dirty).deliveryPromises.length===1);
  const odd=JSON.parse(JSON.stringify(d)); odd.deliveryPromises[0].status='weird'; odd.deliveryPromises[0].items.push({qty:3},{productId:'p2',qty:'7'});
  n=ctx.normalizeData(odd).deliveryPromises[0];
  t('2d unknown status → pending; item without productId dropped; qty string → number',n.status==='pending'&&n.items.length===2&&n.items[1].qty===7);

  // ---- 3. backup ----
  let b=bk(); t('3a OLD backup (no deliveryPromises) accepted',ctx.validateBackupShape(b)===true);
  const P=o=>Object.assign({id:'d1',customerId:'c1',date:TODAY,deliveryDate:day(1),items:[{productId:'p1',name:'نخود',qty:2}],note:'',status:'pending',doneAt:null,invoiceId:null,createdAt:new RD(FIXED).toISOString()},o||{});
  b=bk(); b.deliveryPromises=[P()]; t('3b valid accepted',ctx.validateBackupShape(b)===true);
  b=bk(); b.deliveryPromises=[P({customerId:'zzz'})]; t('3c unknown customer rejected',ctx.validateBackupShape(b)===false);
  b=bk(); b.deliveryPromises=[P({deliveryDate:'1405/01/01'})]; t('3d bad date rejected',ctx.validateBackupShape(b)===false);
  b=bk(); b.deliveryPromises=[P({status:'lost'})]; t('3e unknown status rejected',ctx.validateBackupShape(b)===false);
  b=bk(); b.deliveryPromises=[P({items:[{productId:'p1',name:'x',qty:-1}]})]; t('3f negative qty rejected',ctx.validateBackupShape(b)===false);
  b=bk(); b.deliveryPromises=[P({items:'nope'})]; t('3g non-array items rejected',ctx.validateBackupShape(b)===false);
  b=bk(); b.deliveryPromises=[P({status:'done',invoiceId:'deleted-invoice',doneAt:'2026-11-10T10:00:00.000Z'})]; t('3h dangling invoiceId / deleted product are accepted (metadata only)',ctx.validateBackupShape(b)===true);
  b=bk(); b.deliveryPromises=[P(),P()]; t('3i duplicate ids rejected',ctx.validateBackupShape(b)===false);
  b=bk(); b.deliveryPromises=[P({doneAt:'yesterday'})]; t('3j non-ISO doneAt rejected',ctx.validateBackupShape(b)===false);

  // ---- 4. phases / badges / dueList ----
  d=seed();
  const mk=(c,off,items)=>{const x=DP().add(d,c,{deliveryDate:day(Math.max(0,off)),items:items||[{productId:'p1',qty:1}]},TODAY).promise; x.deliveryDate=day(off); return x;};
  const pOver=mk('c1',-2), pToday=mk('c2',0), pTom=mk('c1',1), pLater=mk('c2',5);
  t('4a phase kinds',DP().phase(pOver,TODAY).kind==='overdue'&&DP().phase(pOver,TODAY).days===2&&DP().phase(pToday,TODAY).kind==='today'&&DP().phase(pTom,TODAY).kind==='tomorrow'&&DP().phase(pLater,TODAY).kind==='upcoming'&&DP().phase(pLater,TODAY).days===5);
  t('4b badges',/تأخیر/.test(DP().badge(pOver,TODAY).text)&&DP().badge(pToday,TODAY).text==='امروز'&&DP().badge(pTom,TODAY).text==='فردا'&&/روز دیگر/.test(DP().badge(pLater,TODAY).text)&&DP().badge(pOver,TODAY).tone==='danger');
  const due=DP().dueList(d,TODAY);
  t('4c dueList = overdue + today + tomorrow, earliest first; later excluded',due.length===3&&due[0].id===pOver.id&&due[2].id===pTom.id);
  t('4d itemsLabel uses names and quantities',DP().itemsLabel({items:[{name:'نخود',qty:2},{name:'عدس',qty:0}],note:''})==='نخود ۲ · عدس'&&DP().itemsLabel({items:[],note:'سلام'})==='سلام');

  // ---- 5. loading summary ----
  d=seed();
  DP().add(d,'c1',{deliveryDate:day(1),items:[{productId:'p1',qty:4},{productId:'p2',qty:2}]},TODAY);
  DP().add(d,'c2',{deliveryDate:day(1),items:[{productId:'p1',qty:3},{productId:'p2',qty:0}]},TODAY);
  const ov=DP().add(d,'c2',{deliveryDate:TODAY,items:[{productId:'p3',qty:6}]},TODAY).promise; ov.deliveryDate=day(-1);
  let tom=DP().loadSummary(d,day(1),day(1)), tod=DP().loadSummary(d,TODAY,null);
  const rp1=tom.find(x=>x.productId==='p1'), rp2=tom.find(x=>x.productId==='p2');
  t('5a tomorrow: totals per product across customers',rp1.qty===7&&rp1.customers.length===2&&!tom.some(x=>x.productId==='p3'));
  t('5b unknown quantity is flagged, not silently zero',rp2.qty===2&&rp2.unknown===true);
  t('5c stock shortage flagged (p2 stock 3 < ... only when qty > stock)',rp1.short===false&&(()=>{DP().add(d,'c1',{deliveryDate:day(1),items:[{productId:'p2',qty:5}]},TODAY);return DP().loadSummary(d,day(1),day(1)).find(x=>x.productId==='p2').short===true;})());
  t('5d «today» window includes overdue goods but not tomorrow',tod.some(x=>x.productId==='p3'&&x.qty===6)&&!tod.some(x=>x.productId==='p1'));
  t('5e done/cancelled promises are not loaded',(()=>{const x=DP().pendingAll(d)[0];DP().cancel(d,x.id);return DP().pendingAll(d).every(y=>y.id!==x.id);})());

  // ---- 6. transitions ----
  d=seed(); const p6=DP().add(d,'c1',{deliveryDate:day(2),items:[{productId:'p1',qty:1}]},TODAY).promise;
  t('6a complete() needs a real invoice of the same customer',!DP().complete(d,p6.id,null).ok&&!DP().complete(d,p6.id,{id:'i9',customerId:'c2'}).ok&&p6.status==='pending');
  t('6b reschedule: future ok, past rejected, same promise',DP().reschedule(d,p6.id,day(4),TODAY).ok&&p6.deliveryDate===day(4)&&!DP().reschedule(d,p6.id,day(-1),TODAY).ok);
  const inv={id:'i1',customerId:'c1',items:[{productId:'p1',qty:1}]};
  t('6c complete(): pending → done with invoiceId/doneAt',DP().complete(d,p6.id,inv).ok&&p6.status==='done'&&p6.invoiceId==='i1'&&!!p6.doneAt);
  t('6d done promise cannot be completed/cancelled/rescheduled again',!DP().complete(d,p6.id,inv).ok&&!DP().cancel(d,p6.id).ok&&!DP().reschedule(d,p6.id,day(5),TODAY).ok&&!DP().closeManually(d,p6.id).ok);
  const p6b=DP().add(d,'c1',{deliveryDate:day(2),items:[{productId:'p2',qty:1}]},TODAY).promise;
  t('6e closeManually: done without invoice',DP().closeManually(d,p6b.id).ok&&p6b.status==='done'&&p6b.invoiceId===null);
  const p6c=DP().add(d,'c1',{deliveryDate:day(2),items:[{productId:'p2',qty:1}]},TODAY).promise;
  t('6f cancel + remove',DP().cancel(d,p6c.id).ok&&p6c.status==='cancelled'&&DP().remove(d,p6c.id).ok&&!DP().byId(p6c.id,d));

  // ---- 7. auto-complete by invoice ----
  d=seed();
  const full=DP().add(d,'c1',{deliveryDate:day(1),items:[{productId:'p1',qty:2},{productId:'p2',qty:1}]},TODAY).promise;
  const part=DP().add(d,'c1',{deliveryDate:day(1),items:[{productId:'p1',qty:1},{productId:'p3',qty:1}]},TODAY).promise;
  const noteOnly=DP().add(d,'c1',{deliveryDate:day(1),items:[],note:'یادم باشه'},TODAY).promise;
  const other=DP().add(d,'c2',{deliveryDate:day(1),items:[{productId:'p1',qty:1}]},TODAY).promise;
  const done=DP().autoCompleteForInvoice(d,{id:'i2',customerId:'c1',items:[{productId:'p1',qty:5},{productId:'p2',qty:1}]});
  t('7a invoice covering every promised product completes that promise',done.length===1&&full.status==='done'&&full.invoiceId==='i2');
  t('7b partial coverage / note-only / other customer stay pending',part.status==='pending'&&noteOnly.status==='pending'&&other.status==='pending');
  const z=DP().add(d,'c1',{deliveryDate:day(2),items:[{productId:'p3',qty:1}]},TODAY).promise;
  t('7c a zero-quantity invoice line does not count',DP().autoCompleteForInvoice(d,{id:'i3',customerId:'c1',items:[{productId:'p3',qty:0}]}).length===0&&z.status==='pending');

  // ---- 8. money / stock invariants ----
  d=seed({invoices:[{id:'i0',number:1001,customerId:'c1',date:day(-3),total:9000000,items:[]}]});
  const snap=()=>JSON.stringify([ctx.customerTotals('c1',ctx.createComputationContext({data:d})),d.products.map(p=>p.stockQty),d.invoices.length,d.payments.length]);
  const before=snap();
  DP().add(d,'c1',{deliveryDate:day(1),items:[{productId:'p1',qty:9}]},TODAY);
  DP().closeManually(d,DP().pending('c1',d)[0].id);
  t('8a promises never touch totals, stock, invoices or payments',snap()===before);

  // ---- 9. html ----
  d=seed();
  let slot=ctx.DeliveryUI.slotHtml('c1',5000000);
  t('9a nothing yet + debt → both add buttons side by side',/pp-add-pair/.test(slot)&&/data-pp-add/.test(slot)&&/data-dp-add/.test(slot));
  t('9b nothing yet + no debt → only the delivery button',!/data-pp-add/.test(ctx.DeliveryUI.slotHtml('c1',0))&&/data-dp-add/.test(ctx.DeliveryUI.slotHtml('c1',0)));
  DP().add(d,'c1',{deliveryDate:day(1),items:[{productId:'p1',qty:2}]},TODAY);
  slot=ctx.DeliveryUI.slotHtml('c1',5000000);
  t('9c with a delivery promise: card shown, delivery add button replaced by «+ جدید»; payment add still offered',/dp-card/.test(slot)&&/نخود ۲/.test(slot)&&!/class="pp-add-row" data-dp-add/.test(slot)&&/data-pp-add/.test(slot));
  ctx.PaymentPromises.add(d,'c1',{amount:1000,promiseDate:day(2)},TODAY);
  slot=ctx.DeliveryUI.slotHtml('c1',5000000);
  t('9d with both active: two cards, no add pair',/pp-card-main/.test(slot)&&/dp-card/.test(slot)&&!/pp-add-pair/.test(slot));
  t('9e dashboard: groups + one «تحویل شد» per row + header actions',(()=>{const x=DP().add(d,'c2',{deliveryDate:TODAY,items:[{productId:'p3',qty:1}]},TODAY).promise;const o=DP().add(d,'c2',{deliveryDate:TODAY,items:[{productId:'p2',qty:1}]},TODAY).promise;o.deliveryDate=day(-2);const h=ctx.DeliveryUI.dashboardHtml();return /عقب‌افتاده/.test(h)&&/امروز/.test(h)&&/فردا/.test(h)&&(h.match(/data-dp-deliver-quick/g)||[]).length===3&&/data-dp-open-load/.test(h)&&h.indexOf('عقب‌افتاده')<h.indexOf('امروز');})());
  d.deliveryPromises.length=0; for(let i=0;i<7;i++) DP().add(d,i%2?'c1':'c2',{deliveryDate:day(1),items:[{productId:'p1',qty:1}]},TODAY);
  t('9f at most 5 dashboard rows',(ctx.DeliveryUI.dashboardHtml().match(/data-dp-deliver-quick/g)||[]).length===5);
  d.deliveryPromises.length=0; DP().add(d,'c1',{deliveryDate:day(4),items:[{productId:'p1',qty:1}]},TODAY);
  t('9g only far-future promises → no dashboard block',ctx.DeliveryUI.dashboardHtml()==='');
  d.deliveryPromises.length=0; const hp=DP().add(d,'c1',{deliveryDate:day(1),items:[{productId:'p1',qty:1}]},TODAY).promise; DP().closeManually(d,hp.id);
  t('9h history lists closed promises',/تاریخچهٔ قول‌های تحویل/.test(ctx.DeliveryUI.historyHtml('c1'))&&ctx.DeliveryUI.historyHtml('c2')==='');

  console.log('\n'+pass+' passed, '+fail+' failed');process.exit(fail?1:0);
})().catch(e=>{console.error(e);process.exit(1);});
