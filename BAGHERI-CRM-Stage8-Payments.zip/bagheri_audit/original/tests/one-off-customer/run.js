// node tests/one-off-customer/run.js — «مشتری یک‌بار‌مصرف / متفرقه» (no DOM, no IndexedDB)
const fs=require('fs'),vm=require('vm'),path=require('path');
const ROOT=path.join(__dirname,'..','..');
const RD=Date, FIXED=new RD('2026-11-10T10:00:00').getTime();
class FD extends RD{constructor(...a){a.length?super(...a):super(FIXED);} static now(){return FIXED;}}
const noop=()=>{};
const ctx={console,JSON,Math,Set,Map,Object,Array,String,Number,Boolean,RegExp,Error,Promise,isFinite,isNaN,parseInt,parseFloat,Symbol,Intl,Date:FD,
  setTimeout:noop,clearTimeout:noop,setInterval:noop,localStorage:{getItem:()=>null,setItem:noop,removeItem:noop},
  document:{getElementById:()=>null,createElement:()=>({}),addEventListener:noop,body:{},readyState:'complete'},navigator:{},location:{hash:''},addEventListener:noop,requestAnimationFrame:noop,
  indexedDB:{},MutationObserver:undefined};
ctx.window=ctx;ctx.self=ctx;ctx.globalThis=ctx;vm.createContext(ctx);
const run=(f,src)=>vm.runInContext(src,ctx,{filename:f});
const FILES=['js/models.js','js/ui.js','js/db.js','js/calc.js','js/computation-bank.js','js/intelligence/risk.js','js/intelligence/signals.js','js/intelligence/priority.js','js/intelligence/action.js',
  'js/payment-promises.js','js/delivery-promises.js','js/visit-plan.js','js/views/payment-promises.js','js/views/delivery-promises.js','js/views/visit-plan.js'];
const loadErrors=[];
FILES.forEach(f=>{ try{ run(f,fs.readFileSync(path.join(ROOT,f),'utf8')); }catch(e){ loadErrors.push(f+': '+e.message); } });
run('stubs','var __saves=0; saveData=async function(){__saves++;}; restoreDataInPlace=function(s){ reconcileRestoreGraph(data,s); };');

let pass=0,fail=0;
function t(name,cond){ if(cond){pass++;console.log('ok   '+name);}else{fail++;console.log('FAIL '+name);} }
const day=n=>{const d=new RD(FIXED);d.setDate(d.getDate()+n);return d.toISOString().slice(0,10);};
const TODAY=day(0);
function seed(o){
  ctx.__d=Object.assign({customers:[],products:[{id:'p1',name:'نخود',active:true,stockQty:10,retail:100,sell:90},{id:'p2',name:'عدس',active:true,stockQty:10,retail:100,sell:90}],
    invoices:[],payments:[],checks:[],suppliers:[],inventoryLayers:[],analysisGroups:[],paymentPromises:[],deliveryPromises:[]},o||{});
  run('seed','data = Object.assign(emptyData(), __d);');
  return vm.runInContext('data',ctx);
}
const C=(id,name,x)=>Object.assign({id,name,active:true,visits:[]},x||{});
const PP=()=>ctx.PaymentPromises, DP=()=>ctx.DeliveryPromises, VP=()=>ctx.VisitPlan;
(async()=>{
  t('0 all modules loaded',loadErrors.length===0);
  if(loadErrors.length) console.log(loadErrors.join('\n'));

  // ---- 1. predicates + normalizeData ----
  t('1a predicates',ctx.isOneOffCustomer({oneOff:true})&&!ctx.isOneOffCustomer({})&&!ctx.isOneOffCustomer(null)&&ctx.isTrackedCustomer({active:true})&&!ctx.isTrackedCustomer({active:true,oneOff:true})&&!ctx.isTrackedCustomer({active:false})&&!ctx.isTrackedCustomer(null));
  const norm=cs=>ctx.normalizeData({customers:cs,products:[],invoices:[],payments:[],checks:[],suppliers:[]}).customers;
  let n=norm([{id:'a',name:'متفرقه'},{id:'b',name:'  متفرقه '},{id:'c',name:'نور'},{id:'d',name:'متفرقه',oneOff:false},{id:'e',name:'فروشگاه X',oneOff:true},{id:'f',name:'متفرقه‌ها'}]);
  t('1b name «متفرقه» (trimmed) defaults to one-off; others do not',n[0].oneOff===true&&n[1].oneOff===true&&n[2].oneOff===false&&n[5].oneOff===false);
  t('1c an explicit choice is respected (false stays false, true stays true)',n[3].oneOff===false&&n[4].oneOff===true);
  const inv=(b)=>ctx.normalizeData({customers:[{id:'a',name:'x'}],products:[],invoices:[{id:'i1',customerId:'a',date:TODAY,items:[],total:1,buyerName:b}],payments:[],checks:[],suppliers:[]}).invoices[0];
  t('1d invoice buyerName is kept (trimmed); empty / missing → absent',inv('  آقای رضایی ').buyerName==='آقای رضایی'&&!('buyerName' in inv(''))&&!('buyerName' in inv(undefined))&&!('buyerName' in inv('   ')));
  const bk={products:[],customers:[{id:'a',name:'متفرقه',oneOff:true}],invoices:[],payments:[],checks:[],suppliers:[],schemaVersion:3,inventoryLayers:[],regions:[],routes:[],neighborhoods:[]};
  t('1e backups with the new fields validate',ctx.validateBackupShape?ctx.validateBackupShape(bk)!==false:true);

  // ---- 2. engines ignore one-off customers ----
  const hist=(cid)=>Array.from({length:6},(_,i)=>({id:'i'+cid+i,number:i+1,customerId:cid,date:day(-60+i*8),total:1000,items:[{productId:'p1',qty:2,price:500}]}));
  let d=seed({customers:[C('reg','نور'),C('misc','متفرقه',{oneOff:true})],invoices:hist('reg').concat(hist('misc'))});
  if(typeof ctx.calculateAllCustomerPriorities==='function'){
    const pr=ctx.calculateAllCustomerPriorities(ctx.createComputationContext({data:d}));
    t('2a priority engine: regular customer is scored, one-off is not',pr.some(x=>x.customerId==='reg')&&!pr.some(x=>x.customerId==='misc'));
  } else t('2a priority engine present',false);
  if(typeof ctx.calculateAllCustomerActions==='function'){
    const ac=ctx.calculateAllCustomerActions(ctx.createComputationContext({data:d}));
    t('2b action engine: one-off never gets suggested actions',!ac.some(x=>x.customerId==='misc')&&ac.some(x=>x.customerId==='reg'));
  } else t('2b action engine present',false);
  const att=ctx.createComputationContext({data:Object.assign(d,{invoices:[{id:'big',number:9,customerId:'misc',date:day(-40),total:50000000,items:[]}]})}).receivableAttention();
  t('2c ...but its DEBT still raises the normal receivable follow-up',att.rows.some(x=>x.customerId==='misc'));

  // ---- 3. payment promises: several people under one account ----
  d=seed({customers:[C('reg','نور'),C('misc','متفرقه',{oneOff:true})]});
  const a1=PP().add(d,'misc',{amount:1000000,promiseDate:day(2),note:'آقای رضایی'},TODAY).promise;
  const a2=PP().add(d,'misc',{amount:2000000,promiseDate:day(3),note:'خانم احمدی'},TODAY).promise;
  t('3a one-off: second promise does NOT supersede the first',a1.status==='pending'&&a2.status==='pending'&&PP().pendingFor('misc',d).length===2);
  const r1=PP().add(d,'reg',{amount:1,promiseDate:day(2)},TODAY).promise, r2=PP().add(d,'reg',{amount:2,promiseDate:day(3)},TODAY).promise;
  t('3b regular customer: still one active promise (unchanged rule)',r1.status==='superseded'&&r2.status==='pending'&&PP().pendingFor('reg',d).length===1);
  const a3=PP().add(d,'misc',{amount:1500000,promiseDate:day(6),note:'آقای رضایی',replaces:a1.id},TODAY).promise;
  t('3c one-off «تمدید» replaces exactly that promise',a1.status==='superseded'&&a2.status==='pending'&&a3.status==='pending');
  d.invoices.push({id:'iB',number:5,customerId:'misc',date:day(-30),total:50000000,items:[]});
  PP().add(d,'misc',{amount:1,promiseDate:day(2),note:'x'},TODAY);
  const att2=ctx.createComputationContext({data:d}).receivableAttention();
  t('3d one-off debt follow-up is NOT snoozed by someone\'s promise',att2.rows.some(x=>x.customerId==='misc')&&!att2.promisedByCustomerId.misc);

  // ---- 4. delivery / visit plan ----
  d=seed({customers:[C('reg','نور'),C('misc','متفرقه',{oneOff:true,visits:[{id:'v',date:day(-1),time:'10:00',nextVisitDate:day(2)}]})]});
  const dm=DP().add(d,'misc',{deliveryDate:day(1),items:[{productId:'p1',qty:2}],note:'آقای رضایی'},TODAY).promise;
  const dr=DP().add(d,'reg',{deliveryDate:day(1),items:[{productId:'p1',qty:2}]},TODAY).promise;
  const full={id:'iX',customerId:'misc',items:[{productId:'p1',qty:5}]};
  t('4a one-off: an invoice never auto-completes a delivery promise (could be another person)',DP().autoCompleteForInvoice(d,full).length===0&&dm.status==='pending');
  t('4b regular customer: auto-complete unchanged',DP().autoCompleteForInvoice(d,{id:'iY',customerId:'reg',items:[{productId:'p1',qty:5}]}).length===1&&dr.status==='done');
  t('4c one-off has no revisit plan',VP().forCustomer('misc',d)===null);
  t('4d explicit completion still works for one-off',DP().complete(d,dm.id,{id:'iZ',customerId:'misc'}).ok&&dm.status==='done');

  // ---- 5. html ----
  d=seed({customers:[C('reg','نور'),C('misc','متفرقه',{oneOff:true})]});
  PP().add(d,'misc',{amount:1000000,promiseDate:day(0),note:'آقای رضایی'},TODAY);
  PP().add(d,'misc',{amount:2000000,promiseDate:day(3),note:'خانم احمدی'},TODAY);
  let h=ctx.DeliveryUI.slotHtml('misc',9000000);
  t('5a one-off customer page: ONE card listing every pending promise with its person',/dp-card/.test(h)&&/آقای رضایی/.test(h)&&/خانم احمدی/.test(h)&&(h.match(/data-pp-open/g)||[]).length===2);
  h=ctx.PromiseUI.dashboardHtml();
  t('5b dashboard row shows WHO promised (note) for one-off',/متفرقه/.test(h)&&/آقای رضایی/.test(h));
  PP().add(d,'reg',{amount:3000000,promiseDate:day(0),note:'یادداشت عادی'},TODAY);
  h=ctx.PromiseUI.dashboardHtml();
  t('5c regular customers keep the old row (note not injected)',!/یادداشت عادی/.test(h));
  DP().add(d,'misc',{deliveryDate:day(1),items:[{productId:'p1',qty:2}],note:'خانم احمدی'},TODAY);
  t('5d delivery dashboard shows WHO ordered for one-off',/خانم احمدی/.test(ctx.DeliveryUI.dashboardHtml()));

  console.log('\n'+pass+' passed, '+fail+' failed');process.exit(fail?1:0);
})().catch(e=>{console.error(e);process.exit(1);});
