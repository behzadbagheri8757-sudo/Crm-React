// Loads the real app engine files into a vm with browser stubs and the REAL backup (read-only).
const fs=require('fs'),vm=require('vm'),path=require('path');
const ROOT=process.env.CRM_ROOT||path.join(__dirname,'..','..');
const BACKUP=process.env.BAGHERI_BACKUP||path.join(__dirname,'baqeri-backup-2026-10-27_2.json');
function makeEnv(opts){
  opts=opts||{};
  const ls={};
  const noop=function(){};
  const fakeEl=new Proxy(function(){}, {get:(t,k)=>k==='style'||k==='classList'||k==='dataset'?new Proxy({}, {get:()=>noop,set:()=>true}):noop, set:()=>true, apply:()=>fakeEl});
  const RealDate=Date;
  const fixed=opts.now?new RealDate(opts.now).getTime():null;
  class FDate extends RealDate{
    constructor(...a){ if(a.length===0&&fixed!=null){super(fixed);} else super(...a); }
    static now(){ return fixed!=null?fixed:RealDate.now(); }
  }
  const ctx={console,JSON,Math,Set,Map,WeakMap,Object,Array,String,Number,Boolean,RegExp,Error,Promise,isFinite,isNaN,parseInt,parseFloat,Symbol,
    setTimeout:noop,clearTimeout:noop,setInterval:noop,Date:FDate,Intl,
    localStorage:{getItem:k=>(k in ls)?ls[k]:null,setItem:(k,v)=>{ls[k]=String(v)},removeItem:k=>{delete ls[k]},_ls:ls},
    document:{getElementById:()=>null,querySelector:()=>null,querySelectorAll:()=>[],createElement:()=>fakeEl,addEventListener:noop,body:fakeEl,documentElement:fakeEl},
    navigator:{userAgent:'node'},location:{hash:''},addEventListener:noop,requestAnimationFrame:noop};
  ctx.window=ctx; ctx.self=ctx; ctx.globalThis=ctx;
  vm.createContext(ctx);
  return ctx;
}
const FILES=['js/models.js','js/ui.js','js/calc.js','js/computation-bank.js','js/intelligence/ack.js','js/intelligence/persistence.js','js/intelligence/feedback.js','js/intelligence/baseline_manager.js','js/intelligence/seasonality.js','js/intelligence/interpretation.js','js/intelligence/signals.js','js/intelligence/sku_intelligence.js','js/intelligence/risk.js','js/intelligence/priority.js','js/intelligence/action.js','js/intelligence/watch_lifecycle.js'];
function load(opts){
  opts=opts||{};
  const ctx=makeEnv(opts);
  const errs=[];
  const bk0=JSON.parse(fs.readFileSync(BACKUP,'utf8'));
  const I=bk0.intelligence||{}, L=ctx.localStorage._ls;
  // Seed browser storage from the (read-only) real backup BEFORE the engine files bootstrap from it.
  const occ={}; (I.occurrences||[]).forEach(o=>{occ[o.key]=o.dates;});
  L['bagheri_intelligence_occurrences']=JSON.stringify(occ);
  L['bagheri_intelligence_seller_feedback']=JSON.stringify(I.seller_feedback||[]);
  const bl={}; (I.baseline_cache||[]).forEach(b=>{bl[b.key]=b;});
  L['bagheri_intelligence_baseline_cache']=JSON.stringify(bl);
  L['bagheri_seller_acks_v1']=JSON.stringify(I.seller_acks||[]);
  L['bagheri_acks_migrated_v1']='1';
  const wl={}; ((bk0.watchLifecycle||{}).occurrences||[]).forEach(w=>{wl[w.id]=w;});
  L['bagheri_watch_occurrences_v1']=JSON.stringify(wl);
  FILES.forEach(f=>{
    try{ vm.runInContext(fs.readFileSync(path.join(opts.root||ROOT,f),'utf8'),ctx,{filename:f}); }
    catch(e){ errs.push(f+': '+e.message); }
  });
  const bk=JSON.parse(fs.readFileSync(BACKUP,'utf8'));
  ctx.__bk=bk;
  try{
    vm.runInContext(`data = Object.assign(emptyData(), {products:__bk.products,customers:__bk.customers,invoices:__bk.invoices,payments:__bk.payments,checks:__bk.checks,suppliers:__bk.suppliers,inventoryLayers:__bk.inventoryLayers,analysisGroups:__bk.analysisGroups||[],regions:__bk.regions||[],routes:__bk.routes||[],neighborhoods:__bk.neighborhoods||[]});`,ctx);
  }catch(e){ errs.push('data: '+e.message); }
  return {ctx,bk,errs};
}
module.exports={load,makeEnv,FILES,ROOT,BACKUP};
