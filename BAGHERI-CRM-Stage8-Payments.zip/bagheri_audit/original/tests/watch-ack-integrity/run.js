/* Watch <-> ACK integrity audit (synthetic data, no real backup needed).
   usage: node tests/watch-ack-integrity/run.js            (CRM root = this project)
          CRM_ROOT=/other/build node tests/watch-ack-integrity/run.js */
const path=require('path');
process.env.BAGHERI_BACKUP=path.join(__dirname,'synthetic-backup.json');
const H=require('../audit-v7_8/harness.js');
const vm=require('vm');
const root=process.env.CRM_ROOT||H.ROOT;
const NOW='2026-10-30T09:00:00Z';
let pass=0, fail=0; const fails=[];
function ok(name,c,extra){ if(c){pass++;} else {fail++; fails.push(name+(extra!==undefined?' -> '+extra:''));} }
function fresh(){ return H.load({now:NOW,root}); }
function setNow(ctx,iso){ vm.runInContext(`(function(){var R=Date.prototype.constructor; var fx=new R('${iso}').getTime(); globalThis.Date=class extends R{constructor(...a){ if(a.length===0){super(fx);} else super(...a);} static now(){return fx;} static parse(s){return R.parse(s);} static UTC(...a){return R.UTC(...a);} };})()`,ctx); }
function mkOcc(ctx,id,pid,cat){ ctx.restoreWatchLifecycleBundle({version:1,occurrences:[{id:id,customerId:'C1',watchCategory:cat||'LINE_DROP_WATCH',productId:pid,level:'medium',status:'active',firstDetectedAt:NOW,lastEvaluatedAt:NOW,reason:null,resolution:null,suppression:null}]}); }
const acksOf=(ctx,o)=>ctx.getActiveAcksForCustomer('C1',o||{});

// ---- T1: every seller decision on Watch → Watch closed + exactly ONE mirrored ACK of the same decision
['still_stock','not_wanted','follow_up_later','no_need'].forEach(code=>{
  const {ctx,errs}=fresh(); ok('load clean '+code, errs.length===0, errs.join('|'));
  mkOcc(ctx,'W1','P1');
  const r=ctx.recordWatchReason('W1',code,'c',code==='follow_up_later'?'2026-11-04':undefined);
  const a=acksOf(ctx);
  ok('T1 '+code+': watch closed', r&&r.status==='dismissed'&&r.suppression&&r.suppression.type===code);
  ok('T1 '+code+': one active ACK, same decision', a.length===1&&a[0].decision===code&&a[0].source==='watch', JSON.stringify(a.map(x=>x.decision)));
});
{ // manual dismiss
  const {ctx}=fresh(); mkOcc(ctx,'W1','P1');
  const r=ctx.dismissWatchOccurrence('W1','n'); const a=acksOf(ctx);
  ok('T1 dismiss: closed + one ACK(dismiss)', r&&r.status==='dismissed'&&a.length===1&&a[0].decision==='dismiss');
}
// ---- T1b: data-capture reasons (price etc.) must NOT close the watch
['price','competitor','quality','other'].forEach(code=>{
  const {ctx}=fresh(); mkOcc(ctx,'W1','P1'); const r=ctx.recordWatchReason('W1',code,'x');
  ok('T1b '+code+': watch stays active', r&&r.status==='active');
});
// ---- T3: reversing on the Watch side reverses the mirrored ACK (no loop)
{
  const {ctx}=fresh(); mkOcc(ctx,'W1','P1'); ctx.recordWatchReason('W1','still_stock','');
  ctx.reverseWatchDecision('W1');
  ok('T3 reverse: no active ACK left', acksOf(ctx).length===0, JSON.stringify(acksOf(ctx).map(x=>x.decision)));
  const rec=ctx.getWatchOccurrence?ctx.getWatchOccurrence('W1'):null;
}
// ---- T4: ACK expiry releases the watch suppression in step
{
  const {ctx}=fresh(); mkOcc(ctx,'W1','P1'); ctx.recordWatchReason('W1','still_stock','');
  setNow(ctx,'2026-11-10T09:00:00Z');              // +11 days (> 7d still_stock life)
  const n=ctx.expireAcks();
  const all=acksOf(ctx,{includeExpired:true});
  ok('T4 expiry: ACK expired', n===1&&all.length&&all[0].status==='expired', n+':'+JSON.stringify(all.map(x=>x.status)));
}
// ---- T5: visit-originated ACK closes the Watch through ONE path, no duplicate mirror
{
  const {ctx}=fresh(); mkOcc(ctx,'W1','P1');
  const a=ctx.createAck({customerId:'C1',productId:'P1',decision:'still_stock',source:'visit',sourceId:'V1',stockSource:'ours'});
  const list=acksOf(ctx);
  ok('T5 visit ACK created', !!a);
  ok('T5 exactly one ACK (no duplicate from Watch mirror)', list.length===1, JSON.stringify(list.map(x=>x.decision+':'+x.source)));
}
// ---- T6: newer decision supersedes older one of same scope (single live truth)
{
  const {ctx}=fresh(); mkOcc(ctx,'W1','P1'); ctx.recordWatchReason('W1','still_stock','');
  ctx.createAck({customerId:'C1',productId:'P1',decision:'no_need',source:'invoice',sourceId:'I1'});
  const list=acksOf(ctx); ok('T6 one live ACK per family', list.length===1&&list[0].decision==='no_need', JSON.stringify(list.map(x=>x.decision)));
}
// ---- T7: purchase of the product ends a suppress/defer ACK
{
  const {ctx}=fresh(); mkOcc(ctx,'W1','P1'); ctx.recordWatchReason('W1','still_stock','');
  const rr=ctx.reconcileAcksAfterInvoice('C1',[{productId:'P1',qty:3}]);
  ok('T7 purchase supersedes ACK', rr.superseded&&rr.superseded.length===1, JSON.stringify(rr));
}
// ---- T8: follow-up completion (the fixed path) – one live ACK, watch hold kept
['price','dismiss','other','no_need','still_stock','not_wanted','competitor','quality'].forEach(code=>{
  const {ctx}=fresh(); mkOcc(ctx,'W1','P1'); ctx.recordWatchReason('W1','follow_up_later','','2026-11-04');
  const r=ctx.completeWatchFollowUp('W1',code,'res');
  const live=acksOf(ctx);
  ok('T8 '+code+': completed', !!r);
  ok('T8 '+code+': no stale follow_up_later ACK', !live.some(x=>x.decision==='follow_up_later'), JSON.stringify(live.map(x=>x.decision)));
  ok('T8 '+code+': result ACK exists', live.some(x=>x.decision===code), JSON.stringify(live.map(x=>x.decision)));
  ok('T8 '+code+': watch still held (not active)', r&&r.status!=='active'&&r.suppression&&!r.suppression.releasedAt);
});
// ---- T9: stale ACK must not release the NEW hold when it expires (the real-world symptom)
{
  const {ctx}=fresh(); mkOcc(ctx,'W1','P1'); ctx.recordWatchReason('W1','follow_up_later','','2026-11-02');
  ctx.completeWatchFollowUp('W1','price','res');
  setNow(ctx,'2026-11-04T09:00:00Z');          // follow-up date passed, price ACK (5d) still alive
  ctx.expireAcks();
  const sup=ctx.getWatchHistory? null : null;
  const pend=ctx.getPendingWatchFollowUps?ctx.getPendingWatchFollowUps('C1'):[];
  ok('T9 no pending follow-up resurfaces after completion', pend.length===0, JSON.stringify(pend.map(x=>x.id)));
}
console.log('Watch<->ACK integrity: PASS '+pass+'  FAIL '+fail);
fails.forEach(f=>console.log('   FAIL:',f));

process.exit(fail?1:0);
