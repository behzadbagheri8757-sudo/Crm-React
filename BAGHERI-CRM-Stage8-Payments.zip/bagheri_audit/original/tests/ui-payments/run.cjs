'use strict';
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const ts = require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript/lib/typescript.js');

const root = path.resolve(__dirname, '../../..');
const appPath = path.join(root, 'artifacts/bagheri-crm/src/App.tsx');
const componentPath = path.join(root, 'artifacts/bagheri-crm/src/Payments.tsx');
const legacyPath = path.join(root, 'original/js/views/payments.js');
const legacyArtifactPath = path.join(root, 'artifacts/bagheri-crm/public/legacy/js/views/payments.js');
const app = fs.readFileSync(appPath, 'utf8');
const componentSource = fs.readFileSync(componentPath, 'utf8');
const legacySource = fs.readFileSync(legacyPath, 'utf8');
const legacyArtifactSource = fs.readFileSync(legacyArtifactPath, 'utf8');

let passed = 0;
let failed = 0;
function assert(name, condition, detail) {
  if (condition) { passed++; console.log('ok  ' + name); }
  else { failed++; console.error('FAIL ' + name + (detail ? ' — ' + detail : '')); }
}

// Execute the exact read-only bridge installed by App.tsx against a controlled dataset.
const marker = '    bridgeScript.textContent = `';
const markerAt = app.indexOf(marker);
const bodyStart = markerAt < 0 ? -1 : markerAt + marker.length;
const end = bodyStart < 0 ? -1 : app.indexOf('\n    `;', bodyStart);
assert('payments bridge is installed from the host app', markerAt >= 0 && end > bodyStart);

const fixture = {
  customers: [{ id: 'c1', name: 'فروشگاه آفتاب' }, { id: 'c2', name: 'سوپر شمال' }],
  invoices: [{ id: 'i1', number: '۱۰۴۲', customerId: 'c1' }],
  payments: [
    { id: 'p-cash', customerId: 'c1', date: '2026-11-18', amount: 1250000, method: 'cash', note: 'نقدی', invoiceId: 'i1' },
    { id: 'p-card', customerId: 'c2', date: '2026-11-17', amount: 2250000, method: 'card', note: 'کارت‌خوان' },
    { id: 'p-return', customerId: 'c1', date: '2026-11-16', amount: 300000, method: 'return', note: 'برگشت یک قلم', invoiceId: 'i1', returnItems: [{ productId: 'x', qty: 1 }] },
    { id: 'p-discount', customerId: 'c1', date: '2026-11-15', amount: 50000, method: 'discount', note: 'تخفیف توافقی' }
  ],
  suppliers: [{ id: 's1', name: 'تأمین‌کننده شمال', payments: [
    { id: 'sp1', date: '2026-11-14', amount: 800000, method: 'cash', note: 'تسویه خرید' },
    { id: 'sp2', date: '2026-11-13', amount: 1500000, method: 'check', status: 'pending', checkNumber: 'چک ۱۲۳' },
    { id: 'sp3', date: '2026-11-12', amount: 200000, method: 'check', status: 'bounced', checkNumber: 'چک ۱۲۴' }
  ] }]
};
const fixtureBefore = JSON.stringify(fixture);
const context = {
  data: fixture,
  Date, Number, String, Array, Object, JSON, Math,
  window: null,
  faDate: (value) => 'تاریخ ' + String(value || ''),
  paymentMethodLabel: (method) => ({ cash: 'نقد', card: 'کارت', transfer: 'انتقال', return: 'برگشت', discount: 'تخفیف' }[method] || method || '—')
};
context.window = context;
vm.createContext(context);
if (end > bodyStart) vm.runInContext(app.slice(bodyStart, end), context, { timeout: 1000 });
const bridge = context.__BAGHERI_DASHBOARD_BRIDGE__;
const snapshot = bridge && bridge.getPaymentsSnapshot ? bridge.getPaymentsSnapshot() : null;
assert('bridge returns a snapshot', !!snapshot && Array.isArray(snapshot.rows));
assert('customer payment records are included', snapshot && snapshot.rows.filter((row) => row.kind === 'customer').length === 4);
assert('supplier payment records are included', snapshot && snapshot.rows.filter((row) => row.kind === 'supplier').length === 3);
assert('linked customer payment retains invoice destination metadata', snapshot && snapshot.rows.find((row) => row.id === 'p-cash').invoiceId === 'i1' && snapshot.rows.find((row) => row.id === 'p-cash').invoiceNumber === '۱۰۴۲');
assert('return remains a return row, not cash receipt', snapshot && snapshot.rows.find((row) => row.id === 'p-return').method === 'return');
assert('supplier check pending status remains visible', snapshot && snapshot.rows.find((row) => row.checkNumber === 'چک ۱۲۳').methodLabel.includes('در جریان'));
assert('supplier bounced check status remains visible', snapshot && snapshot.rows.find((row) => row.checkNumber === 'چک ۱۲۴').methodLabel.includes('برگشتی'));
assert('bridge snapshot does not mutate source records', JSON.stringify(fixture) === fixtureBefore);

// Transpile only for pure helper tests; UI hooks and icon rendering are intentionally not executed.
const transpiled = ts.transpileModule(componentSource, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020, jsx: ts.JsxEmit.ReactJSX, esModuleInterop: true }
}).outputText;
const componentModule = { exports: {} };
const iconNames = ['ArrowLeft','ArrowLeftRight','ArrowUpDown','BadgePercent','Banknote','Building2','CalendarDays','CreditCard','Landmark','RefreshCw','Search','Wallet','X'];
const iconStub = Object.fromEntries(iconNames.map((name) => [name, function IconStub() {}]));
const requireStub = (name) => {
  if (name === 'react') return { useMemo: (fn) => fn(), useState: (value) => [value, () => {}] };
  if (name === 'lucide-react') return iconStub;
  if (name === 'react/jsx-runtime') return { jsx: () => null, jsxs: () => null, Fragment: 'fragment' };
  throw new Error('unexpected import: ' + name);
};
const componentContext = { module: componentModule, exports: componentModule.exports, require: requireStub, Intl, Number, String, Array, Object, Math };
vm.createContext(componentContext);
vm.runInContext(transpiled, componentContext, { timeout: 1000 });
const api = componentModule.exports;
const rows = snapshot ? snapshot.rows : [];
const totals = api.summarizePaymentRows(rows);
assert('summary counts only cash/card/transfer as received', totals.received === 3500000);
assert('summary keeps returns separate from received', totals.received === 3500000 && totals.returned === 300000);
assert('summary keeps discount separate from received', totals.discounts === 50000);
assert('supplier summary reports row count rather than mislabeling all checks as paid cash', totals.supplierCount === 3);
assert('supplier filter returns supplier rows only', api.filterPaymentRows(rows, '', 'supplier', 'newest').length === 3);
assert('return filter returns only customer return records', api.filterPaymentRows(rows, '', 'return', 'newest').map((row) => row.id).join(',') === 'p-return');
assert('cash filter returns only cash receipts', api.filterPaymentRows(rows, '', 'cash', 'newest').map((row) => row.id).join(',') === 'p-cash');
assert('card filter returns only card receipts', api.filterPaymentRows(rows, '', 'card', 'newest').map((row) => row.id).join(',') === 'p-card');
assert('transfer filter returns only bank transfers', api.filterPaymentRows(rows, '', 'transfer', 'newest').length === 0);
assert('discount filter returns only discounts', api.filterPaymentRows(rows, '', 'discount', 'newest').map((row) => row.id).join(',') === 'p-discount');
assert('all filter retains all customer and supplier rows', api.filterPaymentRows(rows, '', 'all', 'newest').length === 7);
assert('Persian invoice digits are searchable with Arabic numerals', api.filterPaymentRows(rows, '1042', 'all', 'newest').some((row) => row.id === 'p-cash'));
assert('supplier check number is searchable', api.filterPaymentRows(rows, '123', 'supplier', 'newest').some((row) => row.checkNumber === 'چک ۱۲۳'));
assert('newest sort orders by raw date descending', api.filterPaymentRows(rows, '', 'all', 'newest')[0].rawDate === '2026-11-18');
assert('oldest sort orders by raw date ascending', api.filterPaymentRows(rows, '', 'all', 'oldest')[0].rawDate === '2026-11-12');
assert('amount sort orders by amount descending', api.filterPaymentRows(rows, '', 'all', 'amountDesc')[0].amount === 2250000);
assert('amount sort orders by amount ascending', api.filterPaymentRows(rows, '', 'all', 'amountAsc')[0].amount === 50000);
assert('filter and sort do not mutate source row order', rows[0].id === 'p-cash');
assert('return rows have distinct presentation classification', api.directionOf(rows.find((row) => row.id === 'p-return')) === 'return');
assert('supplier rows have outgoing supplier classification', api.directionOf(rows.find((row) => row.kind === 'supplier')) === 'supplier');
assert('discount rows remain distinct from cash receipts', api.directionOf(rows.find((row) => row.id === 'p-discount')) === 'discount');

// Integration and scope guards.
assert('payments route activates the new React page', app.includes("const useNewPayments = route === '/payments'") && app.includes('useNewPayments && <Payments'));
assert('legacy payments iframe is hidden on the new page', app.includes('|| useNewPayments'));
assert('legacy payment picker remains the source of the add action', app.includes('if (useNewInvoices || useNewPayments)') && app.includes('legacyFab.click()'));
assert('linked rows route to invoice detail', componentSource.includes('onNavigate(`/invoice?id=${encodeURIComponent(row.invoiceId)}`)'));
assert('unlinked customer rows route to customer detail', componentSource.includes('onNavigate(`/customer?id=${encodeURIComponent(row.partyId)}`)'));
assert('supplier rows route to supplier detail', componentSource.includes('onNavigate(`/supplier?id=${encodeURIComponent(row.partyId)}`)'));
assert('legacy payment renderer remains unchanged in the bundle', legacySource === legacyArtifactSource);
assert('new page has no disclosure accordion markup', !/<details|<summary|<Accordion/i.test(componentSource));
assert('payment view is read-only and does not call saveData or mutate storage', !/saveData\(|data\.payments\s*=|\.push\(/.test(componentSource));

console.log(`\n${passed} passed, ${failed} failed`);
process.exitCode = failed ? 1 : 0;
