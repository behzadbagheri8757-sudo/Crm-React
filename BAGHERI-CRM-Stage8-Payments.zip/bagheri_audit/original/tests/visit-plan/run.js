// node tests/visit-plan/run.js — «ویزیت بعدی» derived reminders (no DOM, no IndexedDB)
const fs=require('fs'),vm=require('vm'),path=require('path');
const ROOT=path.join(__dirname,'..','..');
const RD=Date, FIXED=new RD('2026-11-10T10:00:00').getTime();
class FD extends RD{constructor(...a){a.length?super(...a):super(FIXED);} static now(){return FIXED;}}
const noop=()=>{};
const ctx={console,JSON,Math,Set,Map,Object,Array,String,Number,Boolean,RegExp,Error,Promise,isFinite,isNaN,parseInt,parseFloat,Symbol,Intl,Date:FD,
  setTimeout:noop,clearTimeout:noop,setInterval:noop,localStorage:{getItem:()=>null,setItem:noop,removeItem:noop},
  document:{getElementById:()=>null,createElement:()=>({}),addEventListener:noop,body:{},readyState:'complete'},navigator:{},location:{hash:''},addEventListener:noop,requestAnimationFrame:noop,
  indexedDB:{},MutationObserver:undefined};
ctx.window=ctx;ctx.self=ctx;ctx.globalThis=ctx;vm.createContext(ctx);
const run=(f,src)=>vm.runInContext(src,ctx,{filename:f});
['js/models.js','js/ui.js','js/db.js','js/calc.js','js/computation-bank.js','js/payment-promises.js','js/delivery-promises.js','js/visit-plan.js','js/views/payment-promises.js','js/views/delivery-promises.js','js/views/visit-plan.js','js/backup.js']
  .forEach(f=>run(f,fs.readFileSync(path.join(ROOT,f),'utf8')));
run('stubs','var __saves=0; saveData=async function(){__saves++;}; restoreDataInPlace=function(s){ reconcileRestoreGraph(data,s); };');


let pass=0,fail=0;
function t(name,cond){ if(cond){pass++;console.log('ok   '+name);}else{fail++;console.log('FAIL '+name);} }
const day=n=>{const d=new RD(FIXED);d.setDate(d.getDate()+n);return d.toISOString().slice(0,10);};
const TODAY=day(0);
function seed(customers,invoices){
  ctx.__d={customers:customers,products:[],invoices:invoices||[],payments:[],checks:[],suppliers:[],inventoryLayers:[],analysisGroups:[],paymentPromises:[],deliveryPromises:[]};
  run('seed','data = Object.assign(emptyData(), __d);');
  return vm.runInContext('data',ctx);
}
const C=(id,visits,extra)=>Object.assign({id,name:'مشتری '+id,active:true,visits:visits||[]},extra||{});
const V=(id,date,o)=>Object.assign({id,date,time:'10:00',kind:'normal',result:'x'},o||{});
const VP=()=>ctx.VisitPlan;
(async()=>{
  // ---- 1. derivation ----
  let d=seed([C('a',[V('v1',day(-1),{nextVisitDate:day(2),nextAction:'پیگیری قیمت'})]),C('b',[V('v2',day(-1))]),C('c',[])]);
  let p=VP().forCustomer('a',d);
  t('1a latest visit with nextVisitDate → plan (date, reason from nextAction)',p&&p.date===day(2)&&p.reason==='پیگیری قیمت'&&p.visitId==='v1');
  t('1b no date / no visits → no plan',VP().forCustomer('b',d)===null&&VP().forCustomer('c',d)===null&&VP().forCustomer('zzz',d)===null);
  d=seed([C('a',[V('v1',day(-1),{kind:'closed',nextVisitDate:day(1)})])]);
  t('1c closed visit → reason «فروشگاه بسته بود»',VP().forCustomer('a',d).reason==='فروشگاه بسته بود');
  d=seed([C('a',[V('v1',day(-1),{nextVisitDate:day(1)})])]);
  t('1d plain visit with a date and no action → empty reason (UI shows «مراجعه»)',VP().forCustomer('a',d).reason==='');
  d=seed([C('a',[V('v1',day(-3),{nextVisitDate:day(1)}),V('v2',day(-1))])]);
  t('1e a NEWER visit without a date clears the plan (no zombie)',VP().forCustomer('a',d)===null);
  d=seed([C('a',[V('v1',day(-3),{nextVisitDate:day(1)}),V('v2',day(-1),{nextVisitDate:day(5)})])]);
  t('1f a newer visit with its own date replaces the plan',VP().forCustomer('a',d).date===day(5));
  d=seed([C('a',[V('v1',day(-1),{time:'18:00'}),V('v2',day(-1),{time:'09:00',nextVisitDate:day(3)})])]);
  t('1g same day: later TIME wins (18:00 visit has no plan → none)',VP().forCustomer('a',d)===null);
  d=seed([C('a',[V('v1',day(-1),{nextVisitDate:day(2),nextVisitSkipped:true})]),C('b',[V('v2',day(-1),{nextVisitDate:day(2)})],{active:false})]);
  t('1h skipped / inactive customer → no plan',VP().forCustomer('a',d)===null&&VP().forCustomer('b',d)===null);

  // ---- 2. served by invoice ----
  const inv=(date)=>({id:'i'+date,customerId:'a',date:date,items:[],total:1});
  d=seed([C('a',[V('v1',day(-2),{nextVisitDate:day(1)})])],[inv(day(-3))]);
  t('2a invoice BEFORE the visit does not close the plan',!!VP().forCustomer('a',d));
  d=seed([C('a',[V('v1',day(-2),{nextVisitDate:day(1)})])],[inv(day(-2))]);
  t('2b same-day invoice (made during the visit) does not close the plan',!!VP().forCustomer('a',d));
  d=seed([C('a',[V('v1',day(-2),{nextVisitDate:day(1)})])],[inv(day(-1))]);
  t('2c invoice AFTER the visit = customer served again → plan closed',VP().forCustomer('a',d)===null);
  d=seed([C('a',[V('v1',day(-2),{nextVisitDate:day(1)})])],[Object.assign(inv(day(0)),{customerId:'other'})]);
  t('2d another customer\'s invoice is irrelevant',!!VP().forCustomer('a',d));

  // ---- 3. phases / dueList ----
  d=seed([C('over',[V('v',day(-5),{nextVisitDate:day(-2)})]),C('today',[V('v',day(-5),{nextVisitDate:day(0)})]),C('tom',[V('v',day(-5),{nextVisitDate:day(1)})]),C('later',[V('v',day(-5),{nextVisitDate:day(6)})])]);
  const all=VP().all(d);
  t('3a all(): sorted by date, 4 plans',all.length===4&&all[0].customerId==='over'&&all[3].customerId==='later');
  t('3b phases',VP().phase(all[0],TODAY).kind==='overdue'&&VP().phase(all[0],TODAY).days===2&&VP().phase(all[1],TODAY).kind==='today'&&VP().phase(all[2],TODAY).kind==='tomorrow'&&VP().phase(all[3],TODAY).kind==='upcoming');
  t('3c badges',/تأخیر/.test(VP().badge(all[0],TODAY).text)&&VP().badge(all[1],TODAY).text==='امروز'&&VP().badge(all[2],TODAY).text==='فردا'&&/روز دیگر/.test(VP().badge(all[3],TODAY).text));
  const due=VP().dueList(d,TODAY);
  t('3d dueList = overdue + today only (tomorrow/later excluded)',due.length===2&&due[0].customerId==='over'&&due[1].customerId==='today');
  t('3e dueList horizon 1 adds tomorrow',VP().dueList(d,TODAY,1).length===3);

  // ---- 4. mutations ----
  d=seed([C('a',[V('v1',day(-1),{nextVisitDate:day(1)})])]);
  t('4a reschedule: future ok, past / bad rejected, no plan rejected',VP().reschedule(d,'a',day(4),TODAY).ok&&VP().forCustomer('a',d).date===day(4)&&!VP().reschedule(d,'a',day(-1),TODAY).ok&&!VP().reschedule(d,'a','nonsense',TODAY).ok&&!VP().reschedule(d,'zzz',day(2),TODAY).ok);
  t('4b skip: plan disappears but the visit keeps its date (history intact)',VP().skip(d,'a').ok&&VP().forCustomer('a',d)===null&&d.customers[0].visits[0].nextVisitDate===day(4)&&d.customers[0].visits[0].nextVisitSkipped===true);
  t('4c skip / reschedule with no open plan are refused',!VP().skip(d,'a').ok&&!VP().reschedule(d,'a',day(5),TODAY).ok);
  d=seed([C('a',[V('v1',day(-1),{nextVisitDate:day(1)})])]);
  const s0=vm.runInContext('typeof __saves==="undefined"?0:__saves',ctx);
  run('stubs','var __saves=0; saveData=async function(){__saves++;}; restoreDataInPlace=function(s){ reconcileRestoreGraph(data,s); };');
  const r=await VP().commit(dd=>VP().reschedule(dd,'a',day(3)));
  const r2=await VP().commit(dd=>VP().reschedule(dd,'a',day(-3)));
  t('4d commit() saves once for a valid change, not for a rejected one',r.ok&&!r2.ok&&vm.runInContext('__saves',ctx)===1&&VP().forCustomer('a',vm.runInContext('data',ctx)).date===day(3));

  // ---- 5. persistence ----
  d=seed([C('a',[V('v1',day(-1),{nextVisitDate:day(2),nextVisitSkipped:true,nextAction:'تماس'})])]);
  const n=ctx.normalizeData(JSON.parse(JSON.stringify(d)));
  t('5a normalizeData keeps nextVisitDate / nextVisitSkipped on visits',n.customers[0].visits[0].nextVisitDate===day(2)&&n.customers[0].visits[0].nextVisitSkipped===true);
  const bk={products:[],customers:[{id:'c1',name:'a',visits:[V('v',day(-1),{nextVisitDate:day(2)})]}],invoices:[],payments:[],checks:[],suppliers:[],schemaVersion:3,inventoryLayers:[],regions:[],routes:[],neighborhoods:[]};
  t('5b backups with planned visits still validate',ctx.validateBackupShape(bk)===true);

  // ---- 6. html ----
  d=seed([C('a',[V('v1',day(-1),{nextVisitDate:day(2),nextAction:'پیگیری قیمت'})]),C('b',[])]);
  let h=ctx.VisitPlanUI.cardHtml('a');
  t('6a customer card: title, reason, both actions',/ویزیت بعدی/.test(h)&&/پیگیری قیمت/.test(h)&&/data-vp-reschedule/.test(h)&&/data-vp-skip/.test(h)&&ctx.VisitPlanUI.cardHtml('b')==='');
  d=seed([C('a',[V('v1',day(-1),{nextVisitDate:day(2)})])]);
  t('6b empty reason falls back to «مراجعه»',/مراجعه/.test(ctx.VisitPlanUI.cardHtml('a')));
  t('6c dashboard: nothing due → no block',ctx.VisitPlanUI.dashboardHtml()==='');
  d=seed([C('over',[V('v',day(-5),{nextVisitDate:day(-2)})]),C('today',[V('v',day(-5),{nextVisitDate:day(0)})]),C('tom',[V('v',day(-5),{nextVisitDate:day(1)})])]);
  h=ctx.VisitPlanUI.dashboardHtml();
  t('6d dashboard: overdue then today, one «ثبت ویزیت» per due row, tomorrow excluded',h.indexOf('عقب‌افتاده')<h.indexOf('امروز')&&(h.match(/data-vp-visit-quick/g)||[]).length===2&&!/مشتری tom/.test(h)&&/data-vp-open-all/.test(h));
  d=seed(Array.from({length:7},(_,i)=>C('x'+i,[V('v',day(-5),{nextVisitDate:day(0)})])));
  t('6e at most 5 dashboard rows',(ctx.VisitPlanUI.dashboardHtml().match(/data-vp-visit-quick/g)||[]).length===5);

  console.log('\n'+pass+' passed, '+fail+' failed');process.exit(fail?1:0);
})().catch(e=>{console.error(e);process.exit(1);});
